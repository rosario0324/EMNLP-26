#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from sklearn.metrics import average_precision_score, roc_auc_score


SEEDS = [7, 42, 123]
OURS_MODEL = "ours_full"
TASK_MAP = [
    ("CSEDM S19", "csedm_s19_s1_all", "all", "all"),
    ("CSEDM S19", "csedm_s19_s1_first", "first", "first"),
    ("CSEDM F19", "csedm_f19_s1_all", "all", "all"),
    ("CSEDM F19", "csedm_f19_s1_first", "first", "first"),
    ("CodeWorkout", "csedm_codeworkout_s1_all", "all", "all"),
    ("CodeWorkout", "csedm_codeworkout_s1_first", "first", "first"),
]


def metric(frame: pd.DataFrame) -> dict[str, float]:
    y = frame["target"].astype(int).to_numpy()
    pred = frame["pred"].astype(float).to_numpy()
    return {
        "roc_auc": float(roc_auc_score(y, pred)),
        "pr_auc": float(average_precision_score(y, pred)),
    }


def paired_test(values: pd.Series) -> tuple[float, float]:
    arr = values.astype(float).to_numpy()
    if np.allclose(arr, 0):
        return 0.0, 1.0
    result = wilcoxon(arr, alternative="two-sided", zero_method="wilcox")
    return float(result.statistic), float(result.pvalue)


def holm(pvalues: pd.Series) -> np.ndarray:
    values = pvalues.astype(float).to_numpy()
    order = np.argsort(values)
    adjusted = np.empty(len(values), dtype=float)
    previous = 0.0
    for rank, index in enumerate(order):
        candidate = min(1.0, (len(values) - rank) * values[index])
        previous = max(previous, candidate)
        adjusted[index] = previous
    return adjusted


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--ours-root-template",
        default="../results/ours_full/seed{seed}",
    )
    parser.add_argument(
        "--legacy-iice-fold-detail",
        type=Path,
        default=Path(
            "../results/iice_pkt/fold_detail.tsv"
        ),
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path(
            "../results/significance/ours_full_vs_iice_pkt"
        ),
    )
    args = parser.parse_args()

    legacy = pd.read_csv(args.legacy_iice_fold_detail, sep="\t")
    legacy = legacy[legacy["model"] == "iice_pkt"].copy()
    rows = []
    for dataset, ours_task_id, current_task, legacy_task in TASK_MAP:
        for seed in SEEDS:
            ours_root = Path(args.ours_root_template.format(seed=seed))
            for fold in range(1, 6):
                matched = legacy[
                    (legacy["dataset"] == dataset)
                    & (legacy["task"] == legacy_task)
                    & (legacy["seed"] == seed)
                    & (legacy["fold"] == fold)
                ]
                if len(matched) != 1:
                    raise ValueError(
                        f"Expected one IICE row: {dataset=} {legacy_task=} "
                        f"{seed=} {fold=}; found {len(matched)}"
                    )
                ours_path = (
                    ours_root / ours_task_id / f"fold_{fold}" / OURS_MODEL / "test_pred.csv"
                )
                iice_path = Path(matched.iloc[0]["pred_path"])
                ours_frame = pd.read_csv(ours_path, usecols=["target", "pred"])
                iice_frame = pd.read_csv(iice_path, usecols=["target", "pred"])
                ours_y = ours_frame["target"].astype(int).to_numpy()
                iice_y = iice_frame["target"].astype(int).to_numpy()
                if not np.array_equal(ours_y, iice_y):
                    raise ValueError(
                        f"Unmatched target vector: {dataset=} {current_task=} "
                        f"{seed=} {fold=}; ours={len(ours_y)} iice={len(iice_y)}"
                    )
                ours_metric = metric(ours_frame)
                iice_metric = metric(iice_frame)
                rows.append(
                    {
                        "seed": seed,
                        "fold": fold,
                        "dataset": dataset,
                        "task": current_task,
                        "ours_task_id": ours_task_id,
                        "legacy_iice_task": legacy_task,
                        "targets_verified_equal": True,
                        "ours_pred_path": str(ours_path),
                        "iice_pred_path": str(iice_path),
                        **{f"ours_{name}": value for name, value in ours_metric.items()},
                        **{f"iice_{name}": value for name, value in iice_metric.items()},
                        **{
                            f"diff_{name}": ours_metric[name] - iice_metric[name]
                            for name in ours_metric
                        },
                    }
                )

    detail = pd.DataFrame(rows)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    detail.to_csv(args.out_dir / "paired_fold_detail.tsv", sep="\t", index=False)

    summary_rows = []
    for (dataset, task), group in detail.groupby(["dataset", "task"], sort=False):
        for metric_name in ["roc_auc", "pr_auc"]:
            statistic, pvalue = paired_test(group[f"diff_{metric_name}"])
            summary_rows.append(
                {
                    "scope": f"{dataset} / {task}",
                    "metric": metric_name,
                    "n_pairs": len(group),
                    "ours_mean": group[f"ours_{metric_name}"].mean(),
                    "iice_mean": group[f"iice_{metric_name}"].mean(),
                    "mean_difference": group[f"diff_{metric_name}"].mean(),
                    "wilcoxon_statistic": statistic,
                    "p_value_two_sided": pvalue,
                    "significant_at_0p05": pvalue < 0.05,
                }
            )

    macro = detail.groupby(["seed", "fold"], as_index=False)[
        ["ours_roc_auc", "iice_roc_auc", "ours_pr_auc", "iice_pr_auc"]
    ].mean()
    macro["diff_roc_auc"] = macro["ours_roc_auc"] - macro["iice_roc_auc"]
    macro["diff_pr_auc"] = macro["ours_pr_auc"] - macro["iice_pr_auc"]
    macro.to_csv(args.out_dir / "paired_macro_seed_fold_values.tsv", sep="\t", index=False)
    for metric_name in ["roc_auc", "pr_auc"]:
        statistic, pvalue = paired_test(macro[f"diff_{metric_name}"])
        summary_rows.append(
            {
                "scope": "Macro across 6 dataset-task conditions",
                "metric": metric_name,
                "n_pairs": len(macro),
                "ours_mean": macro[f"ours_{metric_name}"].mean(),
                "iice_mean": macro[f"iice_{metric_name}"].mean(),
                "mean_difference": macro[f"diff_{metric_name}"].mean(),
                "wilcoxon_statistic": statistic,
                "p_value_two_sided": pvalue,
                "significant_at_0p05": pvalue < 0.05,
            }
        )

    summary = pd.DataFrame(summary_rows)
    summary.to_csv(args.out_dir / "paired_wilcoxon_summary.tsv", sep="\t", index=False)
    cells = summary[~summary["scope"].str.startswith("Macro")].copy()
    cells["p_value_holm_12_cells"] = holm(cells["p_value_two_sided"])
    cells["significant_holm_at_0p05"] = cells["p_value_holm_12_cells"] < 0.05
    cells.to_csv(args.out_dir / "paired_wilcoxon_dataset_task_with_holm.tsv", sep="\t", index=False)
    macro_summary = summary[summary["scope"].str.startswith("Macro")].copy()
    macro_summary["p_value_holm_2_metrics"] = holm(macro_summary["p_value_two_sided"])
    macro_summary["significant_holm_at_0p05"] = macro_summary["p_value_holm_2_metrics"] < 0.05
    macro_summary.to_csv(args.out_dir / "paired_wilcoxon_macro_with_holm.tsv", sep="\t", index=False)

    print(f"verified target pairs: {detail['targets_verified_equal'].sum()}/{len(detail)}")
    print(summary.to_string(index=False))
    print("\nHolm-corrected macro:")
    print(macro_summary.to_string(index=False))


if __name__ == "__main__":
    main()
