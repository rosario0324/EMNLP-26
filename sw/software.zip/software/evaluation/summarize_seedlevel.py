#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn import metrics


DEFAULT_TASKS = ",".join(
    [
        "csedm_s19_s1_all",
        "csedm_s19_s1_first",
        "csedm_f19_s1_all",
        "csedm_f19_s1_first",
        "csedm_codeworkout_s1_all",
        "csedm_codeworkout_s1_first",
    ]
)
DEFAULT_MODELS = "code_dkt,pdkt_orig,iice_pkt"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--seeds", default="7,42,123")
    p.add_argument("--tasks", default=DEFAULT_TASKS)
    p.add_argument("--models", default=DEFAULT_MODELS)
    p.add_argument(
        "--root-template",
        default="../results/seed{seed}",
    )
    p.add_argument(
        "--out-dir",
        default="../results/summary",
    )
    p.add_argument("--prefix", default="reported")
    return p.parse_args()


def parse_task(task: str) -> tuple[str, str]:
    if task.startswith("csedm_s19_s1_"):
        return "CSEDM S19", task.removeprefix("csedm_s19_s1_")
    if task.startswith("csedm_f19_s1_"):
        return "CSEDM F19", task.removeprefix("csedm_f19_s1_")
    if task.startswith("csedm_codeworkout_s1_"):
        return "CodeWorkout", task.removeprefix("csedm_codeworkout_s1_")
    return task, task


def compute_metrics(pred_path: Path) -> dict[str, float | int]:
    df = pd.read_csv(pred_path, usecols=["target", "pred"])
    y = df["target"].astype(float).to_numpy()
    p = df["pred"].astype(float).to_numpy()
    mask = np.isfinite(y) & np.isfinite(p)
    y = y[mask]
    p = p[mask]
    if len(y) == 0:
        return {"roc_auc": np.nan, "pr_auc": np.nan, "rmse": np.nan, "acc": np.nan, "n_eval": 0}
    y_bin = (y >= 0.5).astype(int)
    pred_bin = (p >= 0.5).astype(int)
    roc_auc = metrics.roc_auc_score(y_bin, p) if len(np.unique(y_bin)) > 1 else np.nan
    pr_auc = metrics.average_precision_score(y_bin, p) if y_bin.sum() > 0 else np.nan
    rmse = float(np.sqrt(np.mean((p - y) ** 2)))
    acc = float((pred_bin == y_bin).mean())
    return {"roc_auc": roc_auc, "pr_auc": pr_auc, "rmse": rmse, "acc": acc, "n_eval": int(len(y))}


def fmt(mean: float, std: float) -> str:
    if not np.isfinite(mean):
        return "NA"
    if not np.isfinite(std):
        std = 0.0
    return f"{mean:.4f}±{std:.4f}"


def main() -> None:
    args = parse_args()
    seeds = [int(x.strip()) for x in args.seeds.split(",") if x.strip()]
    tasks = [x.strip() for x in args.tasks.split(",") if x.strip()]
    models = [x.strip() for x in args.models.split(",") if x.strip()]
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    fold_rows = []
    missing = []
    for seed in seeds:
        root = Path(args.root_template.format(seed=seed))
        for task in tasks:
            dataset, split = parse_task(task)
            for fold in range(1, 6):
                for model in models:
                    pred_path = root / task / f"fold_{fold}" / model / "test_pred.csv"
                    if not pred_path.exists():
                        missing.append(str(pred_path))
                        continue
                    fold_rows.append(
                        {
                            "seed": seed,
                            "task": task,
                            "dataset": dataset,
                            "split": split,
                            "fold": fold,
                            "model": model,
                            **compute_metrics(pred_path),
                            "pred_path": str(pred_path),
                        }
                    )

    fold_df = pd.DataFrame(fold_rows)
    fold_df.to_csv(out_dir / f"{args.prefix}_fold_detail.tsv", sep="\t", index=False)
    if missing:
        (out_dir / "missing_predictions.txt").write_text("\n".join(missing), encoding="utf-8")
    if fold_df.empty:
        print({"fold_rows": 0, "missing": len(missing), "out_dir": str(out_dir)})
        return

    seed_df = (
        fold_df.groupby(["seed", "dataset", "split", "task", "model"], as_index=False)
        .agg(
            folds=("fold", "nunique"),
            roc_auc=("roc_auc", "mean"),
            pr_auc=("pr_auc", "mean"),
            rmse=("rmse", "mean"),
            acc=("acc", "mean"),
            n_eval=("n_eval", "sum"),
        )
        .sort_values(["dataset", "split", "model", "seed"])
    )
    seed_df.to_csv(out_dir / f"{args.prefix}_seed_level_summary.tsv", sep="\t", index=False)

    rows = []
    for keys, grp in seed_df.groupby(["dataset", "split", "task", "model"], sort=False):
        dataset, split, task, model = keys
        row = {
            "dataset": dataset,
            "split": split,
            "task": task,
            "model": model,
            "seeds": int(grp["seed"].nunique()),
            "folds_per_seed": ",".join(str(int(x)) for x in grp.sort_values("seed")["folds"].tolist()),
            "n_eval_total": int(grp["n_eval"].sum()),
        }
        for metric in ["roc_auc", "pr_auc", "rmse", "acc"]:
            vals = grp[metric].dropna().astype(float).to_numpy()
            row[f"{metric}_mean"] = float(np.mean(vals)) if len(vals) else np.nan
            row[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
            row[metric] = fmt(row[f"{metric}_mean"], row[f"{metric}_std"])
        rows.append(row)

    summary_df = pd.DataFrame(rows).sort_values(["dataset", "split", "model"])
    summary_df.to_csv(out_dir / f"{args.prefix}_seedmean_summary.tsv", sep="\t", index=False)
    table = summary_df[
        ["dataset", "split", "model", "roc_auc", "pr_auc", "rmse", "acc", "seeds", "folds_per_seed", "n_eval_total"]
    ].copy()
    table.to_csv(out_dir / f"{args.prefix}_seedmean_table.tsv", sep="\t", index=False)

    print({"fold_rows": len(fold_df), "seed_rows": len(seed_df), "summary_rows": len(summary_df), "missing": len(missing)})
    print(out_dir)


if __name__ == "__main__":
    main()
