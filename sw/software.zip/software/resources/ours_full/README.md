# Ours (Full): Implementation-Skill Resources

This directory records the curated implementation-skill configuration used by
`Ours (full)`.

## Selection Rule

The retained skills satisfy:

```text
minimum connected problems per skill    = 2
minimum observed extractions per skill  = 7
minimum observed extractions per edge   = 1
```

The resource contains 36 implementation skills and 294 problem-skill edges
covering all 50 CSEDM problems. Each skill contributes positive and negative
evidence channels, resulting in 72 input dimensions before learned projection.

## Files

| File or folder | Content |
| --- | --- |
| `implementation_skill/implementation_skill_catalog.tsv` | Retained canonical skills and their statistics |
| `implementation_skill/problem_skill_edges.csv` | Retained problem-skill relations and supporting observations |
| `implementation_skill/merged_concept_raw_skill_map.tsv` | Canonical-skill to raw-skill mapping |
| `implementation_skill/merged_raw_skill_membership.tsv` | Raw-skill membership details |
| `implementation_skill/rejected_raw_skills.tsv` | Filtered raw-skill audit table |
| `implementation_skill/curation_stats.json` | Summary counts and retention settings |

Tensor assets, code embeddings, trained checkpoints, and fold outputs are not
included because they are generated experiment artifacts rather than resource
definitions.
