#!/usr/bin/env bash
set -euo pipefail

SOFTWARE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PY:-python}"
PROTO_ROOT="${PROTO_ROOT:?Set PROTO_ROOT to the generated CV protocol directory.}"
BASE_ASSET_ROOT="${BASE_ASSET_ROOT:?Set BASE_ASSET_ROOT to the prepared problem and IICE code asset directory.}"
PRO_ID_DICT="${PRO_ID_DICT:?Set PRO_ID_DICT to the CSEDM problem-id mapping file.}"
OUT_ROOT="${OUT_ROOT:-${PWD}/ours_full_runs}"
GPU="${GPU:-0}"
SEEDS="${SEEDS:-7,42,123}"
CPU_THREADS="${PKT_CPU_THREADS:-1}"

TASKS=(
  "csedm_s19_s1_all"
  "csedm_s19_s1_first"
  "csedm_f19_s1_all"
  "csedm_f19_s1_first"
  "csedm_codeworkout_s1_all"
  "csedm_codeworkout_s1_first"
)
CURATED="${SOFTWARE_ROOT}/resources/ours_full/implementation_skill"
ASSET_ROOT="${OUT_ROOT}/assets"
BUILD="${SOFTWARE_ROOT}/models/ours_full/implementation_skill/build_target_skill_assets.py"
TRAIN="${SOFTWARE_ROOT}/models/ours_full/train_eval.py"
SUMMARIZE="${SOFTWARE_ROOT}/evaluation/summarize_seedlevel.py"

export CUDA_VISIBLE_DEVICES="${GPU}"
export OMP_NUM_THREADS="${CPU_THREADS}"
export MKL_NUM_THREADS="${CPU_THREADS}"
export OPENBLAS_NUM_THREADS="${CPU_THREADS}"
export NUMEXPR_NUM_THREADS="${CPU_THREADS}"
export VECLIB_MAXIMUM_THREADS="${CPU_THREADS}"
export BLIS_NUM_THREADS="${CPU_THREADS}"
export RAYON_NUM_THREADS="${CPU_THREADS}"
export TORCH_NUM_THREADS="${CPU_THREADS}"
export TORCH_NUM_INTEROP_THREADS=1
export TOKENIZERS_PARALLELISM=false
export HF_ENABLE_PARALLEL_LOADING=false

task_csv="$(IFS=,; echo "${TASKS[*]}")"
mkdir -p "${OUT_ROOT}"

"${PY}" "${BUILD}" \
  --base-asset-root "${BASE_ASSET_ROOT}" \
  --edge-csv "${CURATED}/problem_skill_edges.csv" \
  --catalog-tsv "${CURATED}/implementation_skill_catalog.tsv" \
  --pro-id-dict "${PRO_ID_DICT}" \
  --protocol-root "${PROTO_ROOT}" \
  --out-asset-root "${ASSET_ROOT}" \
  --tasks "${task_csv}"

IFS=',' read -r -a seed_array <<< "${SEEDS}"
for seed in "${seed_array[@]}"; do
  seed="$(echo "${seed}" | xargs)"
  [[ -z "${seed}" ]] && continue
  for task in "${TASKS[@]}"; do
    for fold in 1 2 3 4 5; do
      out_dir="${OUT_ROOT}/seed${seed}/${task}/fold_${fold}/ours_full"
      mkdir -p "${out_dir}"
      "${PY}" "${TRAIN}" \
        --data-csv "${PROTO_ROOT}/setting1/${task}/full_events_chunked.csv" \
        --user-split-json "${PROTO_ROOT}/setting1/${task}/fold_${fold}/user_split.json" \
        --problem-emb "${ASSET_ROOT}/${task}/fold_${fold}/assets/problem_embedding_full.pt" \
        --code-emb "${ASSET_ROOT}/${task}/assets/global/iice_fused_code.pt" \
        --code-emb-implementation "${ASSET_ROOT}/${task}/assets/global/implementation_skill_row_aligned.pt" \
        --target-skill-matrix "${ASSET_ROOT}/problem_skill_matrix.pt" \
        --target-skill-state pndiff \
        --target-skill-decay 0.8 \
        --target-skill-alpha 1.0 \
        --target-skill-beta 1.0 \
        --target-skill-neg-weight 0.5 \
        --pro-id-dict "${PRO_ID_DICT}" \
        --code-fuse-dim 256 \
        --code-fuse-hidden 256 \
        --proj-dim 256 \
        --hidden-dim 384 \
        --epochs 30 \
        --lambda-decay 0.8 \
        --lr 5e-4 \
        --seed "${seed}" \
        --device cuda:0 \
        --early-stop-metric auc \
        --early-stop-patience 5 \
        --early-stop-min-improvement 0.0005 \
        --pred-out "${out_dir}/test_pred.csv" \
        --val-pred-out "${out_dir}/val_pred.csv" \
        --ckpt-out "${out_dir}/model.ckpt" \
        --result-out "${out_dir}/result.json"
    done
  done
done

"${PY}" "${SUMMARIZE}" \
  --seeds "${SEEDS}" \
  --tasks "${task_csv}" \
  --models "ours_full" \
  --root-template "${OUT_ROOT}/seed{seed}" \
  --out-dir "${OUT_ROOT}/summary" \
  --prefix "ours_full"

echo "[done] ${OUT_ROOT}/summary"
