#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import KFold, StratifiedKFold, StratifiedShuffleSplit


ROOT = Path("../protocols")
SETTING1_ROOT = ROOT / "setting1"
SETTING2_ROOT = ROOT / "setting2"

SRC = {
    "csedm_s19_clean": Path(
        "../processed/csedm_s19/all_events.csv"
    ),
    "csedm_f19_clean": Path(
        "../processed/csedm_f19/all_events.csv"
    ),
    "csedm_codeworkout_clean": Path(
        "../processed/csedm_codeworkout/all_submissions_full.csv"
    ),
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Build reported 5-fold CSEDM protocols.")
    p.add_argument(
        "--tasks",
        default="all",
        help=(
            "comma-separated task keys or 'all'. "
            "Available: csedm_s19_s1_all, csedm_s19_s1_first, "
            "csedm_f19_s1_all, csedm_f19_s1_first, "
            "csedm_codeworkout_s1_all, csedm_codeworkout_s1_first"
        ),
    )
    p.add_argument("--k-folds", type=int, default=5)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--chunk-size", type=int, default=200)
    p.add_argument("--prefix-count", type=int, default=30)
    p.add_argument("--history-cap", type=int, default=200)
    return p.parse_args()


def load_pro_id_dict(path: Path) -> dict[int, int]:
    raw = ast.literal_eval(path.read_text(encoding="utf-8"))
    return {int(k): int(v) for k, v in raw.items()}


def load_clean_events(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["user_id"] = df["user_id"].astype(str)
    df["problem_id"] = pd.to_numeric(df["problem_id"], errors="raise").astype(int)
    df["result"] = pd.to_numeric(df["result"], errors="raise").astype(int)
    if "_source_row_idx" not in df.columns:
        df["_source_row_idx"] = np.arange(len(df), dtype=np.int64)
    return df


def get_sort_cols(df: pd.DataFrame) -> list[str]:
    if "Order" in df.columns:
        cols = ["Order"]
        if "AttemptIndex" in df.columns:
            cols.append("AttemptIndex")
        cols.append("_source_row_idx")
        return cols
    if "create_time" in df.columns:
        work = pd.to_datetime(df["create_time"], errors="coerce", utc=True)
        if work.notna().all():
            df["_sort_time"] = work.astype("int64")
            return ["_sort_time", "_source_row_idx"]
    return ["_source_row_idx"]


def sort_events(df: pd.DataFrame) -> pd.DataFrame:
    work = df.copy()
    sort_cols = ["user_id"] + get_sort_cols(work)
    return work.sort_values(sort_cols, kind="stable").reset_index(drop=True)


def build_true_first_sub(df: pd.DataFrame) -> pd.DataFrame:
    work = sort_events(df)
    work["__first_rank"] = work.groupby(["user_id", "problem_id"]).cumcount()
    first = work.loc[work["__first_rank"] == 0].copy()
    first = first.drop(columns=["__first_rank"])
    return first.reset_index(drop=True)


def build_consecutive_first_sub(df: pd.DataFrame) -> pd.DataFrame:
    work = sort_events(df)
    prev_problem = work.groupby("user_id")["problem_id"].shift()
    first = work.loc[prev_problem.isna() | (work["problem_id"] != prev_problem)].copy()
    return first.reset_index(drop=True)


def build_consecutive_drop_last_sub(df: pd.DataFrame) -> pd.DataFrame:
    work = sort_events(df)
    problem = work["problem_id"].astype(int)
    prev_problem = work.groupby("user_id")["problem_id"].shift()
    next_problem = work.groupby("user_id")["problem_id"].shift(-1)
    # Drop only the final event in a repeated consecutive run; keep singleton runs.
    is_last_in_repeated_run = (prev_problem == problem) & (next_problem.isna() | (next_problem != problem))
    return work.loc[~is_last_in_repeated_run].copy().reset_index(drop=True)


def user_stats_from_events(df: pd.DataFrame) -> pd.DataFrame:
    stats = (
        df.groupby("user_id")
        .agg(rows=("result", "size"), correct=("result", "sum"))
        .reset_index()
    )
    stats["correct_rate"] = stats["correct"] / stats["rows"]
    return stats


def make_user_strata(user_df: pd.DataFrame, max_bins: int = 10) -> pd.Series | None:
    n = len(user_df)
    if n < 2:
        return None
    rank = user_df["correct_rate"].rank(method="first")
    for bins in range(min(max_bins, n), 1, -1):
        try:
            strata = pd.qcut(rank, q=bins, labels=False, duplicates="drop")
        except ValueError:
            continue
        counts = pd.Series(strata).value_counts()
        if len(counts) >= 2 and int(counts.min()) >= 5:
            return pd.Series(strata, index=user_df.index)
    return None


def build_outer_folds(user_df: pd.DataFrame, k: int, seed: int) -> list[list[str]]:
    strata = make_user_strata(user_df)
    splitter = (
        StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
        if strata is not None
        else KFold(n_splits=k, shuffle=True, random_state=seed)
    )
    X = user_df["user_id"].astype(str).to_numpy()
    y = strata.to_numpy() if strata is not None else None
    split_iter = splitter.split(X, y) if y is not None else splitter.split(X)
    folds: list[list[str]] = []
    for _, test_idx in split_iter:
        folds.append(sorted(X[test_idx].tolist()))
    return folds


def choose_val_users(user_df: pd.DataFrame, val_frac_in_remaining: float, seed: int) -> list[str]:
    if len(user_df) <= 1:
        return []
    strata = make_user_strata(user_df)
    X = user_df["user_id"].astype(str).to_numpy()
    if strata is not None:
        splitter = StratifiedShuffleSplit(n_splits=1, test_size=val_frac_in_remaining, random_state=seed)
        _, val_idx = next(splitter.split(X, strata.to_numpy()))
    else:
        rng = np.random.default_rng(seed)
        perm = rng.permutation(len(X))
        n_val = max(1, int(round(len(X) * val_frac_in_remaining)))
        val_idx = perm[:n_val]
    return sorted(X[val_idx].tolist())


def split_stats(df: pd.DataFrame, users: list[str], user_col: str = "user_id") -> dict[str, float | int]:
    sub = df[df[user_col].astype(str).isin(set(users))].copy()
    seq_lens = sub.groupby(user_col).size()
    return {
        "users": len(users),
        "rows": int(len(sub)),
        "correct": int(sub["result"].sum()),
        "correct_rate": float(sub["result"].mean()) if len(sub) else 0.0,
        "avg_seq_len": float(seq_lens.mean()) if len(seq_lens) else 0.0,
        "median_seq_len": float(seq_lens.median()) if len(seq_lens) else 0.0,
        "max_seq_len": int(seq_lens.max()) if len(seq_lens) else 0,
    }


def build_chunked_full(df: pd.DataFrame, chunk_size: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    sorted_df = sort_events(df)
    sort_cols = get_sort_cols(sorted_df)
    parts: list[pd.DataFrame] = []
    meta_rows: list[dict[str, object]] = []
    for user_id, grp in sorted_df.groupby("user_id", sort=False):
        grp = grp.sort_values(sort_cols, kind="stable").copy()
        n = len(grp)
        num_chunks = math.ceil(n / chunk_size)
        for chunk_idx in range(num_chunks):
            start = chunk_idx * chunk_size
            end = min((chunk_idx + 1) * chunk_size, n)
            chunk = grp.iloc[start:end].copy()
            chunk_user_id = f"{user_id}__chunk{chunk_idx + 1}"
            chunk["orig_user_id"] = str(user_id)
            chunk["chunk_idx"] = int(chunk_idx + 1)
            chunk["chunk_user_id"] = chunk_user_id
            chunk["chunk_pos"] = np.arange(len(chunk), dtype=np.int64)
            chunk["user_id"] = chunk_user_id
            parts.append(chunk)
            meta_rows.append(
                {
                    "orig_user_id": str(user_id),
                    "chunk_idx": int(chunk_idx + 1),
                    "chunk_user_id": chunk_user_id,
                    "seq_len": int(len(chunk)),
                }
            )
    full_df = pd.concat(parts, ignore_index=True) if parts else sorted_df.iloc[0:0].copy()
    full_df = full_df.reset_index(drop=True)
    full_df["_aligned_row_idx"] = np.arange(len(full_df), dtype=np.int64)
    meta_df = pd.DataFrame(meta_rows)
    return full_df, meta_df


def build_seq_csv_from_full(full_df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for user_id, grp in full_df.groupby("user_id", sort=False):
        grp = grp.sort_values(["chunk_pos", "_aligned_row_idx"], kind="stable")
        rows.append(
            {
                "user": str(user_id),
                "orig_user_id": str(grp["orig_user_id"].iloc[0]),
                "chunk_idx": int(grp["chunk_idx"].iloc[0]),
                "length": int(len(grp)),
                "problem_sequence": json.dumps(grp["problem_id"].astype(int).tolist()),
                "result_sequence": json.dumps(grp["result"].astype(int).tolist()),
                "row_index_sequence": json.dumps(grp["_aligned_row_idx"].astype(int).tolist()),
            }
        )
    return pd.DataFrame(rows)


def write_split_json(path: Path, train_users: list[str], val_users: list[str], test_users: list[str], meta: dict[str, object]) -> None:
    payload = {
        "train_user_ids": train_users,
        "val_user_ids": val_users,
        "test_user_ids": test_users,
        "meta": meta,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def build_problem_rank_map(raw_problem_ids: list[int], pro_id_dict: dict[int, int]) -> dict[int, int]:
    raw_set = {int(x) for x in raw_problem_ids}
    ordered = sorted(((raw, idx) for raw, idx in pro_id_dict.items() if int(raw) in raw_set), key=lambda x: x[1])
    if len(ordered) != len(raw_set):
        missing = sorted(raw_set - {raw for raw, _ in ordered})
        raise RuntimeError(f"Problem IDs missing from pro_id_dict: {missing}")
    return {raw: idx + 1 for raw, idx in ordered}


def build_fixed_prefix_samples(
    df: pd.DataFrame,
    prefix_count: int,
    history_cap: int,
    pro_id_dict: dict[int, int],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    work = sort_events(df)
    work = work.reset_index(drop=True)
    work["_aligned_row_idx"] = np.arange(len(work), dtype=np.int64)
    rank_map = build_problem_rank_map(work["problem_id"].astype(int).unique().tolist(), pro_id_dict)
    work["problem_rank"] = work["problem_id"].astype(int).map(rank_map).astype(int)

    rows: list[dict[str, object]] = []
    sort_cols = get_sort_cols(work)
    for user_id, grp in work.groupby("user_id", sort=False):
        grp = grp.sort_values(sort_cols + ["_aligned_row_idx"], kind="stable").reset_index(drop=True)
        history = grp.loc[grp["problem_rank"] <= prefix_count].copy()
        targets = grp.loc[grp["problem_rank"] > prefix_count].copy()
        if history.empty or targets.empty:
            continue
        if history_cap and len(history) > history_cap:
            history = history.tail(history_cap).copy()
        hist_probs = history["problem_id"].astype(int).tolist()
        hist_res = history["result"].astype(int).tolist()
        hist_rows = history["_aligned_row_idx"].astype(int).tolist()
        for local_idx, (_, target_row) in enumerate(targets.iterrows(), start=1):
            seq_probs = hist_probs + [int(target_row.problem_id)]
            seq_res = hist_res + [int(target_row.result)]
            seq_rows = hist_rows + [int(target_row["_aligned_row_idx"])]
            rows.append(
                {
                    "sample_id": f"{user_id}__p{prefix_count}__{local_idx}",
                    "user": str(user_id),
                    "length": len(seq_probs),
                    "history_length": len(hist_probs),
                    "problem_sequence": json.dumps(seq_probs),
                    "result_sequence": json.dumps(seq_res),
                    "row_index_sequence": json.dumps(seq_rows),
                    "target_problem_id": int(target_row.problem_id),
                    "target_result": int(target_row.result),
                    "target_row_idx": int(target_row["_aligned_row_idx"]),
                    "target_problem_rank": int(target_row["problem_rank"]),
                }
            )
    sample_df = pd.DataFrame(rows)
    rank_df = pd.DataFrame(
        [{"problem_id": int(pid), "problem_rank": int(rank)} for pid, rank in sorted(rank_map.items(), key=lambda x: x[1])]
    )
    return work, sample_df if len(sample_df) else pd.DataFrame(columns=[
        "sample_id",
        "user",
        "length",
        "history_length",
        "problem_sequence",
        "result_sequence",
        "row_index_sequence",
        "target_problem_id",
        "target_result",
        "target_row_idx",
        "target_problem_rank",
    ]), rank_df


def build_setting1_task(task_key: str, source_df: pd.DataFrame, out_root: Path, k_folds: int, seed: int, chunk_size: int) -> None:
    task_root = out_root / task_key
    task_root.mkdir(parents=True, exist_ok=True)

    orig_df = sort_events(source_df).reset_index(drop=True)
    full_df, chunk_meta = build_chunked_full(orig_df, chunk_size)
    seq_df = build_seq_csv_from_full(full_df)

    full_df.to_csv(task_root / "full_events_chunked.csv", index=False)
    chunk_meta.to_csv(task_root / "chunk_metadata.csv", index=False)
    seq_df.to_csv(task_root / "seq_from_full.csv", index=False)

    user_df = user_stats_from_events(orig_df)
    folds = build_outer_folds(user_df, k_folds, seed)
    target_val_users = max(1, int(round(len(user_df) * 0.1)))
    orig_to_chunks = (
        full_df[["orig_user_id", "user_id"]]
        .drop_duplicates()
        .groupby("orig_user_id")["user_id"]
        .apply(lambda s: sorted(s.astype(str).tolist()))
        .to_dict()
    )

    fold_meta = []
    for fold_idx in range(k_folds):
        fold_name = f"fold_{fold_idx + 1}"
        fold_root = task_root / fold_name
        fold_root.mkdir(parents=True, exist_ok=True)

        test_orig = sorted(folds[fold_idx])
        remaining_orig = sorted({u for i, users in enumerate(folds) if i != fold_idx for u in users})
        remaining_df = user_df[user_df["user_id"].isin(remaining_orig)].reset_index(drop=True)
        val_orig = choose_val_users(
            remaining_df,
            val_frac_in_remaining=min(0.5, target_val_users / max(len(remaining_df), 1)),
            seed=seed + (fold_idx + 1) * 100,
        )
        train_orig = sorted([u for u in remaining_orig if u not in set(val_orig)])

        train_chunk = [chunk for u in train_orig for chunk in orig_to_chunks.get(u, [])]
        val_chunk = [chunk for u in val_orig for chunk in orig_to_chunks.get(u, [])]
        test_chunk = [chunk for u in test_orig for chunk in orig_to_chunks.get(u, [])]

        write_split_json(
            fold_root / "user_split.json",
            train_chunk,
            val_chunk,
            test_chunk,
            meta={
                "protocol": "pkt_cv5_setting1_chunk200_many_to_many",
                "seed": seed,
                "fold_index": fold_idx + 1,
                "k_folds": k_folds,
                "chunk_size": chunk_size,
                "train_orig_user_ids": train_orig,
                "val_orig_user_ids": val_orig,
                "test_orig_user_ids": test_orig,
            },
        )

        fold_meta.append(
            {
                "fold": fold_idx + 1,
                "train_orig": split_stats(orig_df, train_orig, user_col="user_id"),
                "val_orig": split_stats(orig_df, val_orig, user_col="user_id"),
                "test_orig": split_stats(orig_df, test_orig, user_col="user_id"),
                "train_chunk": split_stats(full_df, train_chunk, user_col="user_id"),
                "val_chunk": split_stats(full_df, val_chunk, user_col="user_id"),
                "test_chunk": split_stats(full_df, test_chunk, user_col="user_id"),
            }
        )

    stats = {
        "task_key": task_key,
        "protocol": "setting1_chunk200_many_to_many",
        "rows": int(len(orig_df)),
        "orig_users": int(orig_df["user_id"].nunique()),
        "problems": int(orig_df["problem_id"].nunique()),
        "positive_rate": float(orig_df["result"].mean()),
        "chunk_users": int(full_df["user_id"].nunique()),
        "num_chunks": int(len(chunk_meta)),
        "mean_chunk_len": float(chunk_meta["seq_len"].mean()) if len(chunk_meta) else 0.0,
        "median_chunk_len": float(chunk_meta["seq_len"].median()) if len(chunk_meta) else 0.0,
        "max_chunk_len": int(chunk_meta["seq_len"].max()) if len(chunk_meta) else 0,
        "k_folds": k_folds,
        "folds": fold_meta,
    }
    (task_root / "stats.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")


def build_setting2_task(
    task_key: str,
    source_df: pd.DataFrame,
    out_root: Path,
    k_folds: int,
    seed: int,
    prefix_count: int,
    history_cap: int,
    pro_id_dict: dict[int, int],
) -> None:
    task_root = out_root / task_key
    task_root.mkdir(parents=True, exist_ok=True)

    source_full_df, sample_df, rank_df = build_fixed_prefix_samples(source_df, prefix_count, history_cap, pro_id_dict)
    source_full_df.to_csv(task_root / "source_events_full.csv", index=False)
    sample_df.to_csv(task_root / "seq_from_samples.csv", index=False)
    rank_df.to_csv(task_root / "problem_order_map.csv", index=False)

    user_df = user_stats_from_events(source_full_df)
    folds = build_outer_folds(user_df, k_folds, seed)
    target_val_users = max(1, int(round(len(user_df) * 0.1)))

    fold_meta = []
    for fold_idx in range(k_folds):
        fold_name = f"fold_{fold_idx + 1}"
        fold_root = task_root / fold_name
        fold_root.mkdir(parents=True, exist_ok=True)

        test_users = sorted(folds[fold_idx])
        remaining_users = sorted({u for i, users in enumerate(folds) if i != fold_idx for u in users})
        remaining_df = user_df[user_df["user_id"].isin(remaining_users)].reset_index(drop=True)
        val_users = choose_val_users(
            remaining_df,
            val_frac_in_remaining=min(0.5, target_val_users / max(len(remaining_df), 1)),
            seed=seed + (fold_idx + 1) * 100,
        )
        train_users = sorted([u for u in remaining_users if u not in set(val_users)])

        write_split_json(
            fold_root / "user_split.json",
            train_users,
            val_users,
            test_users,
            meta={
                "protocol": "pkt_cv5_setting2_fixed_prefix_many_to_one",
                "seed": seed,
                "fold_index": fold_idx + 1,
                "k_folds": k_folds,
                "prefix_count": prefix_count,
                "history_cap": history_cap,
            },
        )

        fold_meta.append(
            {
                "fold": fold_idx + 1,
                "train_source": split_stats(source_full_df, train_users, user_col="user_id"),
                "val_source": split_stats(source_full_df, val_users, user_col="user_id"),
                "test_source": split_stats(source_full_df, test_users, user_col="user_id"),
                "train_samples": int(sample_df[sample_df["user"].astype(str).isin(set(train_users))].shape[0]),
                "val_samples": int(sample_df[sample_df["user"].astype(str).isin(set(val_users))].shape[0]),
                "test_samples": int(sample_df[sample_df["user"].astype(str).isin(set(test_users))].shape[0]),
            }
        )

    stats = {
        "task_key": task_key,
        "protocol": "setting2_fixed_prefix_many_to_one",
        "source_rows": int(len(source_full_df)),
        "source_users": int(source_full_df["user_id"].nunique()),
        "source_problems": int(source_full_df["problem_id"].nunique()),
        "source_positive_rate": float(source_full_df["result"].mean()) if len(source_full_df) else 0.0,
        "sample_rows": int(len(sample_df)),
        "sample_positive_rate": float(sample_df["target_result"].mean()) if len(sample_df) else 0.0,
        "mean_history_length": float(sample_df["history_length"].mean()) if len(sample_df) else 0.0,
        "max_history_length": int(sample_df["history_length"].max()) if len(sample_df) else 0,
        "prefix_count": prefix_count,
        "history_cap": history_cap,
        "k_folds": k_folds,
        "folds": fold_meta,
    }
    (task_root / "stats.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")


def resolve_tasks(task_arg: str) -> list[str]:
    all_tasks = [
        "csedm_s19_s1_all",
        "csedm_s19_s1_first",
        "csedm_f19_s1_all",
        "csedm_f19_s1_first",
        "csedm_codeworkout_s1_all",
        "csedm_codeworkout_s1_first",
    ]
    if task_arg == "all":
        return all_tasks
    return [x.strip() for x in task_arg.split(",") if x.strip()]


def main() -> None:
    args = parse_args()
    tasks = resolve_tasks(args.tasks)

    s19_clean = load_clean_events(SRC["csedm_s19_clean"])
    f19_clean = load_clean_events(SRC["csedm_f19_clean"])
    codeworkout_clean = load_clean_events(SRC["csedm_codeworkout_clean"])

    s19_first = build_true_first_sub(s19_clean)
    f19_first = build_true_first_sub(f19_clean)
    codeworkout_first = build_true_first_sub(codeworkout_clean)

    task_to_payload: dict[str, tuple[str, pd.DataFrame]] = {
        "csedm_s19_s1_all": ("setting1", s19_clean),
        "csedm_s19_s1_first": ("setting1", s19_first),
        "csedm_f19_s1_all": ("setting1", f19_clean),
        "csedm_f19_s1_first": ("setting1", f19_first),
        "csedm_codeworkout_s1_all": ("setting1", codeworkout_clean),
        "csedm_codeworkout_s1_first": ("setting1", codeworkout_first),
    }

    summary_rows: list[dict[str, object]] = []
    for task_key in tasks:
        if task_key not in task_to_payload:
            raise KeyError(f"unknown task key: {task_key}")
        _, df = task_to_payload[task_key]
        build_setting1_task(task_key, df, SETTING1_ROOT, args.k_folds, args.seed, args.chunk_size)
        stats_path = SETTING1_ROOT / task_key / "stats.json"
        stats = json.loads(stats_path.read_text(encoding="utf-8"))
        summary_rows.append(
            {
                "task_key": task_key,
                "protocol": stats["protocol"],
                "rows": stats.get("rows", stats.get("source_rows", 0)),
                "users": stats.get("orig_users", stats.get("source_users", 0)),
                "problems": stats.get("problems", stats.get("source_problems", 0)),
                "positive_rate": stats.get("positive_rate", stats.get("source_positive_rate", 0.0)),
                "sample_rows": stats.get("sample_rows", ""),
            }
        )
        print(f"[done] {task_key}")

    summary_df = pd.DataFrame(summary_rows)
    ROOT.mkdir(parents=True, exist_ok=True)
    summary_df.to_csv(ROOT / "summary.tsv", sep="\t", index=False)


if __name__ == "__main__":
    main()
