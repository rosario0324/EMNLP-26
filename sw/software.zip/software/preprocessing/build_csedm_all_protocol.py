#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


DATA_ROOT = Path("../dataset")
PROCESSED_ROOT = Path("../processed")

DATASETS: dict[str, dict[str, object]] = {
    "s19": {
        "main_paths": [
            DATA_ROOT / "CSEDM_S19_original/Data/MainTable.csv",
        ],
        "code_paths": [
            DATA_ROOT / "CSEDM_S19_original/Data/CodeStates/CodeStates.csv",
        ],
        "out_root": PROCESSED_ROOT / "csedm_s19",
        "source_scope": "source_distribution",
    },
    "f19": {
        "main_paths": [
            DATA_ROOT / "CSEDM_F19_original/Data/MainTable.csv",
        ],
        "code_paths": [
            DATA_ROOT / "CSEDM_F19_original/Data/CodeStates/CodeStates.csv",
        ],
        "out_root": PROCESSED_ROOT / "csedm_f19",
        "source_scope": "source_distribution",
    },
}


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")
    return pd.read_csv(path)


def _as_str(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    for col in cols:
        if col in df.columns:
            df[col] = df[col].astype(str)
    return df


def _ast_ok_javalang(code: str) -> bool:
    code = str(code).strip()
    if not code:
        return False
    try:
        import javalang
    except Exception as exc:
        raise RuntimeError(
            "javalang is required for strict AST filtering. Install via `pip install javalang`."
        ) from exc

    try:
        javalang.parse.parse_member(code)
        return True
    except Exception:
        pass
    try:
        javalang.parse.parse(code)
        return True
    except Exception:
        pass
    try:
        javalang.parse.parse(f"class Dummy {{\n{code}\n}}")
        return True
    except Exception:
        return False


def build_attempts(main_paths: list[Path], code_paths: list[Path]) -> pd.DataFrame:
    main = pd.concat([_read_csv(Path(p)) for p in main_paths], ignore_index=True)
    codes = pd.concat([_read_csv(Path(p)) for p in code_paths], ignore_index=True)

    main = _as_str(main, ["SubjectID", "ProblemID", "CodeStateID"])
    codes = _as_str(codes, ["CodeStateID"])

    if "EventType" in main.columns:
        main = main[main["EventType"] == "Run.Program"].copy()

    main = main.sort_values(["SubjectID", "Order"], kind="stable").reset_index(drop=True)
    main["PrevCodeStateID"] = main.groupby("SubjectID")["CodeStateID"].shift(1)
    main["is_new_attempt"] = (main["CodeStateID"] != main["PrevCodeStateID"]).fillna(True)
    main["AttemptIndex"] = main.groupby("SubjectID")["is_new_attempt"].cumsum()

    attempts = (
        main.groupby(["SubjectID", "AttemptIndex"], as_index=False)
        .agg(
            {
                "Order": "min",
                "ProblemID": "last",
                "CodeStateID": "last",
                "Score": "max",
            }
        )
        .sort_values(["SubjectID", "Order", "AttemptIndex"], kind="stable")
        .reset_index(drop=True)
    )
    attempts["Score"] = attempts["Score"].fillna(0.0)
    attempts["Correct"] = (attempts["Score"] >= 0.9999).astype(int)
    attempts = attempts.merge(codes, on="CodeStateID", how="left")
    attempts = attempts[attempts["Code"].notna()].copy()
    attempts = attempts[attempts["Code"].astype(str).str.len().gt(0)].copy()
    attempts = attempts.reset_index(drop=True)
    return attempts


def apply_strict_ast_filter(attempts: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, int]]:
    code_series = attempts["Code"].fillna("").astype(str)
    unique_codes = pd.Series(code_series.unique())
    ast_ok_map = {code: _ast_ok_javalang(code) for code in unique_codes.tolist()}
    ast_ok = code_series.map(ast_ok_map).fillna(False)
    filtered = attempts.loc[ast_ok].copy().reset_index(drop=True)
    stats = {
        "before_rows": int(len(attempts)),
        "after_rows": int(len(filtered)),
        "removed_rows": int((~ast_ok).sum()),
    }
    return filtered, stats


def exclude_final_attempts(attempts: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, float]]:
    work = attempts.sort_values(
        ["SubjectID", "ProblemID", "Order", "AttemptIndex"],
        kind="stable",
    ).copy()
    work["attempt_pos"] = work.groupby(["SubjectID", "ProblemID"]).cumcount()
    work["attempt_cnt"] = work.groupby(["SubjectID", "ProblemID"])["attempt_pos"].transform("max") + 1
    final_mask = work["attempt_pos"] == (work["attempt_cnt"] - 1)
    removed = work.loc[final_mask].copy()
    kept = work.loc[~final_mask].copy().reset_index(drop=True)
    stats = {
        "user_problem_pairs": int(work[["SubjectID", "ProblemID"]].drop_duplicates().shape[0]),
        "removed_final_rows": int(len(removed)),
        "removed_final_positive_rate": float(removed["Correct"].mean()) if len(removed) else 0.0,
        "kept_rows": int(len(kept)),
        "kept_positive_rate": float(kept["Correct"].mean()) if len(kept) else 0.0,
    }
    return kept, stats


def split_users(user_ids: list[str], seed: int) -> dict[str, list[str]]:
    rng = np.random.default_rng(seed)
    arr = np.array(sorted([str(u) for u in user_ids]), dtype=object)
    rng.shuffle(arr)
    n = len(arr)
    n_train = int(n * 0.8)
    n_val = int(n * 0.1)
    return {
        "seed": seed,
        "train_user_ids": arr[:n_train].tolist(),
        "val_user_ids": arr[n_train:n_train + n_val].tolist(),
        "test_user_ids": arr[n_train + n_val :].tolist(),
    }


def build_chunked_events(df: pd.DataFrame, chunk_size: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    parts: list[pd.DataFrame] = []
    meta_rows: list[dict[str, object]] = []
    for user_id, grp in df.groupby("user_id", sort=False):
        grp = grp.sort_values(["Order", "AttemptIndex", "_source_row_idx"], kind="stable").copy()
        n = len(grp)
        num_chunks = math.ceil(n / chunk_size)
        for chunk_idx in range(num_chunks):
            start = chunk_idx * chunk_size
            end = min((chunk_idx + 1) * chunk_size, n)
            chunk = grp.iloc[start:end].copy()
            seq_len = len(chunk)
            chunk_user_id = f"{user_id}__chunk{chunk_idx + 1}"
            chunk["orig_user_id"] = str(user_id)
            chunk["chunk_idx"] = int(chunk_idx + 1)
            chunk["chunk_user_id"] = chunk_user_id
            chunk["chunk_pos"] = np.arange(seq_len, dtype=int)
            chunk["user_id"] = chunk_user_id
            parts.append(chunk)
            meta_rows.append(
                {
                    "orig_user_id": str(user_id),
                    "chunk_idx": int(chunk_idx + 1),
                    "chunk_user_id": chunk_user_id,
                    "seq_len": int(seq_len),
                }
            )
    chunk_df = pd.concat(parts, ignore_index=True) if parts else df.iloc[0:0].copy()
    meta_df = pd.DataFrame(meta_rows)
    return chunk_df, meta_df


def build_sequence_csv(chunk_df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for user_id, grp in chunk_df.groupby("user_id", sort=False):
        grp = grp.sort_values(["chunk_pos", "_source_row_idx"], kind="stable")
        probs = grp["problem_id"].astype(int).tolist()
        res = grp["result"].astype(int).tolist()
        row_idx = grp["_source_row_idx"].astype(int).tolist()
        orig_users = grp["orig_user_id"].astype(str).unique().tolist()
        chunk_ids = grp["chunk_idx"].astype(int).unique().tolist()
        if len(orig_users) != 1 or len(chunk_ids) != 1:
            raise ValueError(f"Chunk metadata mismatch for {user_id}")
        rows.append(
            {
                "user": str(user_id),
                "orig_user_id": orig_users[0],
                "chunk_idx": int(chunk_ids[0]),
                "length": int(len(probs)),
                "problem_sequence": json.dumps(probs),
                "result_sequence": json.dumps(res),
                "row_index_sequence": json.dumps(row_idx),
            }
        )
    return pd.DataFrame(rows)


def _split_stats(events_df: pd.DataFrame, meta_df: pd.DataFrame, seq_df: pd.DataFrame, chunk_size: int) -> dict[str, object]:
    usable_seq_df = seq_df[seq_df["length"] >= 2].copy() if len(seq_df) else seq_df
    return {
        "original_users": int(events_df["orig_user_id"].nunique()) if len(events_df) else 0,
        "chunked_users": int(events_df["user_id"].nunique()) if len(events_df) else 0,
        "rows": int(len(events_df)),
        "problems": int(pd.to_numeric(events_df["problem_id"], errors="coerce").dropna().astype(int).nunique())
        if len(events_df)
        else 0,
        "positive_rate": float(pd.to_numeric(events_df["result"], errors="coerce").mean()) if len(events_df) else 0.0,
        "num_chunks": int(len(meta_df)),
        "mean_chunk_len": float(meta_df["seq_len"].mean()) if len(meta_df) else 0.0,
        "median_chunk_len": float(meta_df["seq_len"].median()) if len(meta_df) else 0.0,
        "min_chunk_len": int(meta_df["seq_len"].min()) if len(meta_df) else 0,
        "max_chunk_len": int(meta_df["seq_len"].max()) if len(meta_df) else 0,
        "full_chunks_eq_200": int((meta_df["seq_len"] == chunk_size).sum()) if len(meta_df) else 0,
        "remainder_chunks_lt20": int((meta_df["seq_len"] < 20).sum()) if len(meta_df) else 0,
        "chunks_len_lt2": int((meta_df["seq_len"] < 2).sum()) if len(meta_df) else 0,
        "usable_sequences_len_ge_2": int(len(usable_seq_df)),
    }


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def build_protocol(dataset: str, out_root: Path, chunk_size: int, seed: int) -> None:
    cfg = DATASETS[dataset]
    main_paths = [Path(p) for p in cfg["main_paths"]]  # type: ignore[index]
    code_paths = [Path(p) for p in cfg["code_paths"]]  # type: ignore[index]

    out_root.mkdir(parents=True, exist_ok=True)

    attempts = build_attempts(main_paths, code_paths)
    attempts["SubjectID"] = attempts["SubjectID"].astype(str)
    attempts["ProblemID"] = attempts["ProblemID"].astype(int)
    attempts["AttemptIndex"] = attempts["AttemptIndex"].astype(int)

    ast_filtered, ast_stats = apply_strict_ast_filter(attempts)
    no_final, final_stats = exclude_final_attempts(ast_filtered)

    clean = (
        no_final.rename(
            columns={
                "SubjectID": "user_id",
                "ProblemID": "problem_id",
                "Correct": "result",
                "Code": "code",
            }
        )
        .sort_values(["user_id", "Order", "AttemptIndex"], kind="stable")
        .reset_index(drop=True)
    )
    clean["_source_row_idx"] = np.arange(len(clean), dtype=int)
    clean_master_cols = [
        "user_id",
        "problem_id",
        "result",
        "code",
        "Order",
        "AttemptIndex",
        "_source_row_idx",
    ]
    clean_master_path = out_root / "all_events.csv"
    clean[clean_master_cols].to_csv(clean_master_path, index=False)

    orig_split = split_users(clean["user_id"].drop_duplicates().astype(str).tolist(), seed)
    _write_json(out_root / "orig_user_split_seed42.json", orig_split)

    split_sets = {
        "train": set(orig_split["train_user_ids"]),
        "val": set(orig_split["val_user_ids"]),
        "test": set(orig_split["test_user_ids"]),
    }

    chunk_parts: list[pd.DataFrame] = []
    chunk_meta_parts: list[pd.DataFrame] = []
    chunk_split_payload: dict[str, object] = {"seed": seed}
    split_stats: dict[str, object] = {}

    for split_name, users in split_sets.items():
        split_df = clean.loc[clean["user_id"].isin(users)].copy()
        chunk_df, meta_df = build_chunked_events(split_df, chunk_size)
        chunk_df = chunk_df.sort_values(["user_id", "chunk_pos", "_source_row_idx"], kind="stable").copy()
        if len(chunk_df):
            chunk_df["split"] = split_name
            meta_df["split"] = split_name
        seq_df = build_sequence_csv(chunk_df)
        usable_seq_df = seq_df[seq_df["length"] >= 2].copy()
        usable_users = usable_seq_df["user"].astype(str).tolist()

        split_chunk_path = out_root / f"{split_name}_chunked_events.csv"
        split_meta_path = out_root / f"{split_name}_chunk_metadata.csv"
        split_seq_path = out_root / f"{split_name}_seq_from_chunks.csv"
        split_seq_usable_path = out_root / f"{split_name}_seq_from_chunks_len_ge_2.csv"
        chunk_df.to_csv(split_chunk_path, index=False)
        meta_df.to_csv(split_meta_path, index=False)
        seq_df.to_csv(split_seq_path, index=False)
        usable_seq_df.to_csv(split_seq_usable_path, index=False)

        if len(usable_users):
            chunk_parts.append(chunk_df.loc[chunk_df["user_id"].isin(usable_users)].copy())
            chunk_meta_parts.append(meta_df.loc[meta_df["chunk_user_id"].isin(usable_users)].copy())
        else:
            chunk_parts.append(chunk_df.iloc[0:0].copy())
            chunk_meta_parts.append(meta_df.iloc[0:0].copy())

        chunk_split_payload[f"{split_name}_user_ids"] = usable_users
        split_stats[split_name] = _split_stats(chunk_df, meta_df, seq_df, chunk_size)

    full_chunk_df = pd.concat(chunk_parts, ignore_index=True) if chunk_parts else clean.iloc[0:0].copy()
    full_meta_df = pd.concat(chunk_meta_parts, ignore_index=True) if chunk_meta_parts else pd.DataFrame()
    full_seq_df = build_sequence_csv(full_chunk_df) if len(full_chunk_df) else pd.DataFrame(
        columns=["user", "orig_user_id", "chunk_idx", "length", "problem_sequence", "result_sequence", "row_index_sequence"]
    )
    full_seq_usable_df = full_seq_df[full_seq_df["length"] >= 2].copy() if len(full_seq_df) else full_seq_df

    full_cols = [
        "user_id",
        "orig_user_id",
        "chunk_idx",
        "chunk_user_id",
        "chunk_pos",
        "split",
        "problem_id",
        "result",
        "code",
        "Order",
        "AttemptIndex",
        "_source_row_idx",
    ]
    full_chunk_df[full_cols].to_csv(out_root / "all_submissions_full.csv", index=False)
    full_meta_df.to_csv(out_root / "all_chunk_metadata.csv", index=False)
    full_seq_df.to_csv(out_root / "seq_from_full.csv", index=False)
    full_seq_usable_df.to_csv(out_root / "seq_from_full_len_ge_2.csv", index=False)
    _write_json(out_root / "user_split_seed42.json", chunk_split_payload)

    stats = {
        "dataset": dataset,
        "root": str(out_root),
        "policy": {
            "ast_filter": "strict_javalang_only",
            "exclude_final_submission_per_user_problem": True,
            "split_order": "after_ast_filter_and_final_removal",
            "split_users_train_val_test": [0.8, 0.1, 0.1],
            "split_seed": seed,
            "chunking": f"split-internal non-overlapping consecutive chunks of size <= {chunk_size}",
            "drop_chunk_len_lt_2_for_training": True,
            "evaluation_metrics_from_test_split_only": True,
        },
        "sources": {
            "main_paths": [str(p) for p in main_paths],
            "code_paths": [str(p) for p in code_paths],
            "source_scope": str(cfg.get("source_scope", "custom")),
        },
        "raw_run_program_attempts": {
            "rows": int(len(attempts)),
            "users": int(attempts["SubjectID"].nunique()),
            "problems": int(attempts["ProblemID"].nunique()),
            "positive_rate": float(attempts["Correct"].mean()) if len(attempts) else 0.0,
        },
        "strict_ast_filter": ast_stats,
        "final_submission_exclusion": final_stats,
        "reported_all_after_final_submission_removal": {
            "rows": int(len(clean)),
            "users": int(clean["user_id"].nunique()),
            "problems": int(clean["problem_id"].nunique()),
            "positive_rate": float(clean["result"].mean()) if len(clean) else 0.0,
            "mean_user_len": float(clean["user_id"].value_counts().mean()) if len(clean) else 0.0,
            "median_user_len": float(clean["user_id"].value_counts().median()) if len(clean) else 0.0,
            "min_user_len": int(clean["user_id"].value_counts().min()) if len(clean) else 0,
            "max_user_len": int(clean["user_id"].value_counts().max()) if len(clean) else 0,
        },
        "orig_split_users": {
            "train": len(orig_split["train_user_ids"]),
            "val": len(orig_split["val_user_ids"]),
            "test": len(orig_split["test_user_ids"]),
        },
        "chunk_split_users_len_ge_2": {
            "train": len(chunk_split_payload.get("train_user_ids", [])),
            "val": len(chunk_split_payload.get("val_user_ids", [])),
            "test": len(chunk_split_payload.get("test_user_ids", [])),
        },
        "splits": split_stats,
        "global_chunked_full_len_ge_2": {
            "rows": int(len(full_chunk_df)),
            "chunked_users": int(full_chunk_df["user_id"].nunique()) if len(full_chunk_df) else 0,
            "orig_users": int(full_chunk_df["orig_user_id"].nunique()) if len(full_chunk_df) else 0,
            "problems": int(full_chunk_df["problem_id"].nunique()) if len(full_chunk_df) else 0,
            "positive_rate": float(full_chunk_df["result"].mean()) if len(full_chunk_df) else 0.0,
            "num_chunks": int(len(full_meta_df)),
            "mean_chunk_len": float(full_meta_df["seq_len"].mean()) if len(full_meta_df) else 0.0,
            "median_chunk_len": float(full_meta_df["seq_len"].median()) if len(full_meta_df) else 0.0,
            "min_chunk_len": int(full_meta_df["seq_len"].min()) if len(full_meta_df) else 0,
            "max_chunk_len": int(full_meta_df["seq_len"].max()) if len(full_meta_df) else 0,
        },
    }
    _write_json(out_root / "stats.json", stats)

    readme = "\n".join(
        [
            f"# CSEDM {dataset.upper()} reported task preprocessing",
            "",
            "Protocol:",
            "1. Keep only `Run.Program` events and collapse consecutive identical `CodeStateID` values into attempts.",
            "2. Exclude attempts whose code fails strict AST parsing with `javalang`.",
            "3. Exclude the final remaining submission for each `(student, problem)` pair; this result is the reported `all` task.",
            "4. Split remaining students 8:1:1 into train/val/test.",
            "5. Within each split, chunk each student history into non-overlapping consecutive segments of size <= 200.",
            "6. Drop chunk sequences of length < 2 from trainable/evaluable sequence assets.",
            "",
            "Key files:",
            "- `all_events.csv`: filtered, final-submission-removed unchunked event table for the reported `all` task",
            "- `orig_user_split_seed42.json`: student-level split before chunking",
            "- `all_submissions_full.csv`: global chunked event table with pseudo-user ids",
            "- `user_split_seed42.json`: chunk-user split for training/evaluation",
            "- `seq_from_full.csv`: chunked sequence CSV",
            "- `stats.json`: summary statistics",
        ]
    )
    (out_root / "README.md").write_text(readme, encoding="utf-8")

    print(json.dumps(stats, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Build corrected CSEDM chunk200 protocol from raw data.")
    parser.add_argument("--dataset", choices=sorted(DATASETS.keys()), required=True)
    parser.add_argument("--out-root", default=None)
    parser.add_argument("--chunk-size", type=int, default=200)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    default_out = Path(DATASETS[args.dataset]["out_root"])  # type: ignore[index]
    out_root = Path(args.out_root) if args.out_root else default_out
    build_protocol(args.dataset, out_root, args.chunk_size, args.seed)


if __name__ == "__main__":
    main()
