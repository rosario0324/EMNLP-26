#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")
    return pd.read_csv(path)


def _as_str(df: pd.DataFrame, cols):
    for col in cols:
        if col in df.columns:
            df[col] = df[col].astype(str)
    return df


def _balanced_braces(code: str) -> bool:
    code = str(code).strip()
    if not code:
        return False
    stack = 0
    for ch in code:
        if ch == "{":
            stack += 1
        elif ch == "}":
            stack -= 1
            if stack < 0:
                return False
    return stack == 0


def _ast_ok_javalang(code: str) -> bool:
    code = str(code).strip()
    if not code:
        return False
    try:
        import javalang
    except Exception as exc:
        raise RuntimeError(
            "javalang is required for AST filtering. Install via `pip install javalang`."
        ) from exc

    try:
        javalang.parse.parse_member(code)
        return True
    except Exception:
        pass
    try:
        javalang.parse.parse(code)
        return True
    except Exception:
        pass
    try:
        javalang.parse.parse(f"class Dummy {{\n{code}\n}}")
        return True
    except Exception:
        return False


def apply_ast_filter(attempts: pd.DataFrame, mode: str) -> pd.DataFrame:
    if mode == "none":
        return attempts

    code_series = attempts["Code"].fillna("").astype(str)
    ast_ok = code_series.map(_ast_ok_javalang)

    if mode == "javalang":
        filtered = attempts[ast_ok].copy()
        print(f"[ast-filter=javalang] kept {len(filtered)} / {len(attempts)}")
        return filtered

    if mode == "heuristic_39796":
        lengths = code_series.map(len)
        line_counts = code_series.map(lambda s: s.count("\n") + 1 if s else 0)
        extra = (~ast_ok) & code_series.map(_balanced_braces) & (lengths >= 551) & (line_counts >= 19)
        kept = ast_ok | extra
        filtered = attempts[kept].copy()
        print(
            "[ast-filter=heuristic_39796] "
            f"kept {len(filtered)} / {len(attempts)} "
            f"(ast_ok={int(ast_ok.sum())}, extra={int(extra.sum())})"
        )
        return filtered

    raise ValueError(f"Unknown ast filter mode: {mode}")


def _detect_compile_error(main: pd.DataFrame) -> pd.Series:
    result = main.get("Compile.Result")
    msg_type = main.get("CompileMessageType")
    msg_data = main.get("CompileMessageData")
    if result is None:
        result = ""
    if msg_type is None:
        msg_type = ""
    if msg_data is None:
        msg_data = ""
    err = (
        result.fillna("").astype(str).str.lower().eq("error")
        | msg_type.fillna("").astype(str).str.len().gt(0)
        | msg_data.fillna("").astype(str).str.len().gt(0)
    )
    return err


def build_attempts(
    main_paths,
    code_paths,
    drop_compile_errors: bool,
    drop_empty_code: bool,
):
    main = pd.concat([_read_csv(Path(p)) for p in main_paths], ignore_index=True)
    codes = pd.concat([_read_csv(Path(p)) for p in code_paths], ignore_index=True)

    main = _as_str(main, ["SubjectID", "ProblemID", "CodeStateID"])
    codes = _as_str(codes, ["CodeStateID"])

    # Use only run events (submission attempts)
    if "EventType" in main.columns:
        main = main[main["EventType"] == "Run.Program"].copy()

    main["CompileError"] = _detect_compile_error(main)
    compile_error_map = main.groupby("CodeStateID")["CompileError"].any()

    main = main.sort_values(["SubjectID", "Order"]).reset_index(drop=True)
    main["PrevCodeStateID"] = main.groupby("SubjectID")["CodeStateID"].shift(1)
    main["is_new_attempt"] = (main["CodeStateID"] != main["PrevCodeStateID"]).fillna(True)
    main["AttemptIndex"] = main.groupby("SubjectID")["is_new_attempt"].cumsum()

    attempts = (
        main.groupby(["SubjectID", "AttemptIndex"], as_index=False)
        .agg(
            {
                "Order": "min",
                "ProblemID": "last",
                "CodeStateID": "last",
                "Score": "max",
            }
        )
    )
    attempts["Score"] = attempts["Score"].fillna(0.0)
    attempts["Correct"] = (attempts["Score"] >= 0.9999).astype(int)
    attempts["CompileError"] = attempts["CodeStateID"].map(compile_error_map).fillna(False)
    attempts = attempts.merge(codes, on="CodeStateID", how="left")
    attempts = attempts.sort_values(["SubjectID", "Order", "AttemptIndex"]).reset_index(drop=True)

    if drop_compile_errors:
        attempts = attempts[~attempts["CompileError"]].copy()
    if drop_empty_code:
        attempts = attempts[attempts["Code"].notna()].copy()
        attempts = attempts[attempts["Code"].astype(str).str.len().gt(0)].copy()

    return attempts


def exclude_final_attempts(attempts: pd.DataFrame) -> pd.DataFrame:
    attempts = attempts.sort_values(["SubjectID", "ProblemID", "Order", "AttemptIndex"]).copy()
    attempts["attempt_pos"] = attempts.groupby(["SubjectID", "ProblemID"]).cumcount()
    attempts["attempt_cnt"] = attempts.groupby(["SubjectID", "ProblemID"])["attempt_pos"].transform("max") + 1
    return attempts[attempts["attempt_pos"] < attempts["attempt_cnt"] - 1].copy()


def select_first_attempts(attempts: pd.DataFrame) -> pd.DataFrame:
    attempts = attempts.sort_values(["SubjectID", "ProblemID", "Order", "AttemptIndex"]).copy()
    return attempts.groupby(["SubjectID", "ProblemID"], as_index=False).first()


def cap_sequence_length(df: pd.DataFrame, max_len: int) -> pd.DataFrame:
    if max_len <= 0:
        return df
    df = df.sort_values(["SubjectID", "Order", "AttemptIndex"]).copy()
    return df.groupby("SubjectID", as_index=False, group_keys=False).tail(max_len)


def split_users(user_ids, ratios, seed):
    rng = np.random.default_rng(seed)
    user_ids = np.array(list(user_ids))
    rng.shuffle(user_ids)
    n = len(user_ids)
    n_train = int(n * ratios[0])
    n_val = int(n * ratios[1])
    train = user_ids[:n_train]
    val = user_ids[n_train : n_train + n_val]
    test = user_ids[n_train + n_val :]
    return train.tolist(), val.tolist(), test.tolist()


def write_outputs(df: pd.DataFrame, out_dir: Path, prefix: str, ratios, seed):
    out_dir.mkdir(parents=True, exist_ok=True)

    df_out = df.rename(
        columns={
            "SubjectID": "user_id",
            "ProblemID": "problem_id",
            "Correct": "result",
            "Code": "code",
        }
    )
    df_out = df_out[["user_id", "problem_id", "result", "code", "Order"]]

    full_path = out_dir / f"{prefix}_full.csv"
    df_out.to_csv(full_path, index=False)

    users = df_out["user_id"].unique()
    train_users, val_users, test_users = split_users(users, ratios, seed)
    (out_dir / f"{prefix}_users_train.json").write_text(json.dumps(train_users))
    (out_dir / f"{prefix}_users_val.json").write_text(json.dumps(val_users))
    (out_dir / f"{prefix}_users_test.json").write_text(json.dumps(test_users))

    train_df = df_out[df_out["user_id"].isin(train_users)]
    val_df = df_out[df_out["user_id"].isin(val_users)]
    test_df = df_out[df_out["user_id"].isin(test_users)]

    train_df.to_csv(out_dir / f"{prefix}_train.csv", index=False)
    val_df.to_csv(out_dir / f"{prefix}_val.csv", index=False)
    test_df.to_csv(out_dir / f"{prefix}_test.csv", index=False)

    stats = {
        "prefix": prefix,
        "num_users": len(users),
        "num_rows": len(df_out),
        "train_rows": len(train_df),
        "val_rows": len(val_df),
        "test_rows": len(test_df),
    }
    (out_dir / f"{prefix}_stats.json").write_text(json.dumps(stats, indent=2))
    print(f"[{prefix}] rows={len(df_out)} users={len(users)} -> {out_dir}")


def main():
    parser = argparse.ArgumentParser(description="Build CSEDM baseline sequences for PDKT.")
    parser.add_argument("--train-main", default="../dataset/CSEDM_CodeWorkout_original/MainTable.csv")
    parser.add_argument("--test-main", default="../dataset/CSEDM_CodeWorkout_original/MainTable.csv")
    parser.add_argument("--train-codes", default="../dataset/CSEDM_CodeWorkout_original/LinkTables/CodeStates.csv")
    parser.add_argument("--test-codes", default="../dataset/CSEDM_CodeWorkout_original/LinkTables/CodeStates.csv")
    parser.add_argument("--out-dir", default="../processed/csedm_codeworkout")
    parser.add_argument("--max-seq-len", type=int, default=200)
    parser.add_argument("--drop-compile-errors", action="store_true")
    parser.add_argument("--drop-empty-code", action="store_true")
    parser.add_argument(
        "--ast-filter",
        choices=["none", "javalang", "heuristic_39796"],
        default="none",
        help="AST filtering mode (heuristic_39796 matches 39,796 in S19_Release Train Run.Program).",
    )
    parser.add_argument("--task", choices=["all", "first", "both"], default="both")
    parser.add_argument("--use-part", choices=["train", "test", "both"], default="train")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--split", default="0.8,0.1,0.1")
    args = parser.parse_args()

    ratios = [float(x) for x in args.split.split(",")]
    if len(ratios) != 3 or abs(sum(ratios) - 1.0) > 1e-6:
        raise ValueError("--split must be three ratios summing to 1.0 (e.g., 0.8,0.1,0.1)")

    if args.use_part == "train":
        main_paths = [args.train_main]
        code_paths = [args.train_codes]
    elif args.use_part == "test":
        main_paths = [args.test_main]
        code_paths = [args.test_codes]
    else:
        main_paths = [args.train_main, args.test_main]
        code_paths = [args.train_codes, args.test_codes]

    attempts = build_attempts(
        main_paths,
        code_paths,
        drop_compile_errors=args.drop_compile_errors,
        drop_empty_code=args.drop_empty_code,
    )

    attempts = apply_ast_filter(attempts, args.ast_filter)
    attempts = exclude_final_attempts(attempts)
    attempts = cap_sequence_length(attempts, args.max_seq_len)

    out_dir = Path(args.out_dir)

    if args.task in ("all", "both"):
        write_outputs(attempts, out_dir, "all_submissions", ratios, args.seed)

    if args.task in ("first", "both"):
        first_df = select_first_attempts(attempts)
        first_df = cap_sequence_length(first_df, args.max_seq_len)
        write_outputs(first_df, out_dir, "first_submission", ratios, args.seed)


if __name__ == "__main__":
    main()
