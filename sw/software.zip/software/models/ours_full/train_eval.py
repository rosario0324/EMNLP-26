#!/usr/bin/env python3
import argparse
import json
import os
import random
from pathlib import Path
from typing import Dict, List, Optional

for _thread_key in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "BLIS_NUM_THREADS",
):
    os.environ.setdefault(_thread_key, "1")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import f1_score, precision_recall_fscore_support, precision_recall_curve, roc_auc_score
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader, Dataset, Sampler
from tqdm import tqdm


def configure_cpu_threads() -> None:
    threads = int(os.environ.get("TORCH_NUM_THREADS", os.environ.get("OMP_NUM_THREADS", "1")))
    interop = int(os.environ.get("TORCH_NUM_INTEROP_THREADS", "1"))
    torch.set_num_threads(threads)
    try:
        torch.set_num_interop_threads(interop)
    except RuntimeError:
        pass


configure_cpu_threads()


def load_pro_id_dict(path: Path) -> Dict[int, int]:
    text = path.read_text().strip()
    if not text:
        return {}
    return {int(k): int(v) for k, v in eval(text).items()}


def _load_optional_embedding(path: Optional[Path], label: str) -> Optional[torch.Tensor]:
    if not path:
        return None
    emb = torch.load(path, map_location="cpu")
    if not isinstance(emb, torch.Tensor):
        raise TypeError(f"{label} embedding is not a torch.Tensor: {path}")
    return emb


class BucketBatchSampler(Sampler[List[int]]):
    def __init__(self, lengths: List[int], batch_size: int, shuffle: bool, drop_last: bool):
        self.lengths = lengths
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.drop_last = drop_last
        self.indices = list(range(len(lengths)))

    def __iter__(self):
        indices = sorted(self.indices, key=lambda i: self.lengths[i])
        batches = [indices[i : i + self.batch_size] for i in range(0, len(indices), self.batch_size)]
        if self.drop_last and batches and len(batches[-1]) < self.batch_size:
            batches = batches[:-1]
        if self.shuffle:
            np.random.shuffle(batches)
        for batch in batches:
            yield batch

    def __len__(self):
        if self.drop_last:
            return len(self.indices) // self.batch_size
        return (len(self.indices) + self.batch_size - 1) // self.batch_size


class CodePNNFusion(nn.Module):
    def __init__(self, input_dims: List[int], fuse_dim: int, hidden_dim: int, dropout: float = 0.1):
        super().__init__()
        self.input_dims = input_dims
        self.fuse_dim = fuse_dim
        self.num_inputs = len(input_dims)
        self.num_pairs = self.num_inputs * (self.num_inputs - 1) // 2
        self.proj = nn.ModuleList([nn.Linear(dim, fuse_dim) for dim in input_dims])
        self.fc1 = nn.Linear(self.num_inputs * fuse_dim + self.num_pairs, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.fc2 = nn.Linear(hidden_dim, fuse_dim)

    def forward(self, inputs: List[torch.Tensor]) -> torch.Tensor:
        proj = [F.relu(layer(x)) for layer, x in zip(self.proj, inputs)]
        stacked = torch.stack(proj, dim=2)
        pairwise = []
        for i in range(self.num_inputs):
            for j in range(i + 1, self.num_inputs):
                pairwise.append((stacked[:, :, i, :] * stacked[:, :, j, :]).sum(dim=-1, keepdim=True))
        ip = torch.cat(pairwise, dim=-1) if pairwise else None
        linear = torch.cat(proj, dim=-1)
        features = torch.cat([linear, ip], dim=-1) if ip is not None else linear
        h = F.relu(self.fc1(features))
        h = self.dropout(h)
        return self.fc2(h)


class PDKTModel(nn.Module):
    def __init__(
        self,
        pretrained_prob_emb: torch.Tensor,
        pretrained_prob_emb_secondary: Optional[torch.Tensor],
        hidden_dim: int,
        code_dim: int,
        lambda_decay: float,
        rnn_type: str = "rnn",
        proj_dim: Optional[int] = None,
        code_proj_dim: Optional[int] = None,
        code_input_keys: Optional[List[str]] = None,
        code_input_dims: Optional[List[int]] = None,
        code_fuse_dim: Optional[int] = None,
        code_fuse_hidden: Optional[int] = None,
        code_fuse_dropout: float = 0.1,
        use_rasch: bool = False,
        rasch_l2: float = 0.0,
        rasch_response_diff: bool = False,
        rasch_qa_diff: bool = False,
        problem_fusion: str = "none",
        problem_gate_hidden: Optional[int] = None,
        code_problem_fusion: str = "none",
        code_problem_alpha: float = 1.0,
        code_problem_gate_hidden: Optional[int] = None,
        error_input_key: Optional[str] = None,
        error_input_dim: Optional[int] = None,
        channel_fusion: str = "concat",
        channel_gate_kc_bias: float = 1.0,
        skill_aux_dim: Optional[int] = None,
        explicit_response_input: str = "none",
        code_bottleneck_key: Optional[str] = None,
        code_bottleneck_dim: Optional[int] = None,
        target_skill_matrix: Optional[torch.Tensor] = None,
        target_skill_state: str = "none",
        target_skill_decay: float = 0.8,
        target_skill_alpha: float = 1.0,
        target_skill_beta: float = 1.0,
        target_skill_neg_weight: float = 1.0,
        target_skill_exclude_same_problem_history: bool = False,
    ):
        super().__init__()
        p_dim = pretrained_prob_emb.size(1)
        self.hidden_dim = hidden_dim
        self.lambda_decay = lambda_decay
        self.proj_dim = proj_dim
        self.code_proj_dim = code_proj_dim
        self.use_rasch = use_rasch
        self.rasch_l2 = rasch_l2
        p_feat_dim = proj_dim or p_dim
        self.rnn_type = rnn_type
        self.problem_fusion = problem_fusion
        self.code_problem_fusion = code_problem_fusion
        self.code_problem_alpha = code_problem_alpha
        self.error_input_key = error_input_key
        self.channel_fusion = channel_fusion
        self.skill_aux_head = None
        if explicit_response_input not in {"none", "problem", "code", "both"}:
            raise ValueError(f"Unsupported explicit_response_input: {explicit_response_input}")
        self.explicit_response_problem = explicit_response_input in {"problem", "both"}
        self.explicit_response_code = explicit_response_input in {"code", "both"}

        self.prob_emb = nn.Embedding.from_pretrained(pretrained_prob_emb, freeze=True)
        self.prob_emb_secondary = None
        self.problem_gate = None
        if pretrained_prob_emb_secondary is not None:
            if pretrained_prob_emb_secondary.size(1) != p_dim:
                raise ValueError(
                    "Primary/secondary problem embeddings must have the same width: "
                    f"{p_dim} vs {pretrained_prob_emb_secondary.size(1)}"
                )
            self.prob_emb_secondary = nn.Embedding.from_pretrained(
                pretrained_prob_emb_secondary, freeze=True
            )
            if self.problem_fusion == "gated_scalar":
                gate_hidden = problem_gate_hidden or p_dim
                self.problem_gate = nn.Sequential(
                    nn.Linear(p_dim * 2, gate_hidden),
                    nn.ReLU(),
                    nn.Linear(gate_hidden, 1),
                )
            elif self.problem_fusion not in {"avg", "none"}:
                raise ValueError(f"Unsupported problem_fusion: {self.problem_fusion}")
        # Use projected dim for response embedding when projection is enabled.
        self.res_emb = nn.Embedding(3, p_feat_dim)
        self.p_proj = nn.Linear(p_dim, p_feat_dim) if p_feat_dim != p_dim else None
        self.p2h = nn.Linear(p_feat_dim, hidden_dim)
        self.difficult_param = None
        self.p_embed_diff = None
        self.r_embed_diff = None
        self.qa_embed_diff = None
        if use_rasch:
            n_problem = pretrained_prob_emb.size(0)
            self.difficult_param = nn.Embedding(n_problem, 1)
            self.p_embed_diff = nn.Embedding(n_problem, p_feat_dim)
            if rasch_response_diff:
                self.r_embed_diff = nn.Embedding(3, p_feat_dim)
            if rasch_qa_diff:
                self.qa_embed_diff = nn.Embedding(n_problem * 3, p_feat_dim)
            nn.init.zeros_(self.difficult_param.weight)
            nn.init.zeros_(self.p_embed_diff.weight)
            if self.r_embed_diff is not None:
                nn.init.zeros_(self.r_embed_diff.weight)
            if self.qa_embed_diff is not None:
                nn.init.zeros_(self.qa_embed_diff.weight)

        self.code_input_keys = code_input_keys or ["base"]
        self.final_code_input_keys = list(self.code_input_keys)
        self.target_skill_state = target_skill_state
        self.target_skill_decay = float(target_skill_decay)
        self.target_skill_alpha = float(target_skill_alpha)
        self.target_skill_beta = float(target_skill_beta)
        self.target_skill_neg_weight = float(target_skill_neg_weight)
        self.target_skill_exclude_same_problem_history = bool(
            target_skill_exclude_same_problem_history
        )
        self.target_skill_proj = None
        self.target_skill_dim = 0
        if self.target_skill_state not in {"none", "deficit", "mastery_deficit", "pndiff"}:
            raise ValueError(f"Unsupported target_skill_state: {self.target_skill_state}")
        if self.target_skill_state != "none":
            if target_skill_matrix is None:
                raise ValueError("target_skill_matrix is required when target_skill_state is enabled")
            target_skill_matrix = target_skill_matrix.float()
            self.register_buffer("target_skill_matrix", target_skill_matrix)
            base_skill_dim = int(target_skill_matrix.size(1))
            if self.target_skill_state == "deficit":
                self.target_skill_dim = base_skill_dim
            elif self.target_skill_state == "mastery_deficit":
                self.target_skill_dim = base_skill_dim * 2
            else:
                self.target_skill_dim = base_skill_dim * 3
            self.target_skill_proj = nn.Linear(self.target_skill_dim, hidden_dim)
        else:
            self.register_buffer("target_skill_matrix", torch.zeros(0, 0))
        self.code_input_bottlenecks = nn.ModuleDict()
        adjusted_code_input_dims = list(code_input_dims) if code_input_dims else None
        if (
            adjusted_code_input_dims is not None
            and code_bottleneck_key
            and code_bottleneck_dim is not None
            and int(code_bottleneck_dim) > 0
        ):
            for idx, key in enumerate(self.code_input_keys):
                if key == code_bottleneck_key:
                    bottleneck_dim = int(code_bottleneck_dim)
                    self.code_input_bottlenecks[key] = nn.Sequential(
                        nn.Linear(adjusted_code_input_dims[idx], bottleneck_dim),
                        nn.ReLU(),
                    )
                    adjusted_code_input_dims[idx] = bottleneck_dim
        self.code_fusion = None
        if adjusted_code_input_dims and len(adjusted_code_input_dims) > 1:
            fuse_dim = code_fuse_dim or adjusted_code_input_dims[0]
            fuse_hidden = code_fuse_hidden or fuse_dim
            self.code_fusion = CodePNNFusion(
                adjusted_code_input_dims, fuse_dim, fuse_hidden, dropout=code_fuse_dropout
            )
            code_dim = fuse_dim
        code_feat_dim = code_proj_dim or proj_dim or code_dim
        self.c_proj = nn.Linear(code_dim, code_feat_dim) if code_feat_dim != code_dim else None
        self.code_problem_proj = None
        self.code_problem_gate = None
        self.code_problem_film = None
        if self.code_problem_fusion != "none":
            self.code_problem_proj = nn.Linear(p_feat_dim, code_feat_dim)
            if self.code_problem_fusion == "gated_residual":
                gate_hidden = code_problem_gate_hidden or code_feat_dim
                self.code_problem_gate = nn.Sequential(
                    nn.Linear(code_feat_dim * 2, gate_hidden),
                    nn.ReLU(),
                    nn.Linear(gate_hidden, 1),
                )
            elif self.code_problem_fusion == "film":
                self.code_problem_film = nn.Linear(p_feat_dim, code_feat_dim * 2)
            elif self.code_problem_fusion != "residual":
                raise ValueError(f"Unsupported code_problem_fusion: {self.code_problem_fusion}")

        problem_rnn_input_dim = p_feat_dim + (1 if self.explicit_response_problem else 0)
        code_rnn_input_dim = code_feat_dim + (1 if self.explicit_response_code else 0)
        self.rnn_p = self._build_recurrent(problem_rnn_input_dim)
        self.rnn_c = self._build_recurrent(code_rnn_input_dim)
        if skill_aux_dim is not None and skill_aux_dim > 0:
            self.skill_aux_head = nn.Linear(self.hidden_dim, int(skill_aux_dim))
        self.error_proj = None
        self.rnn_error = None
        self.fc_error = None
        self.channel_gate = None
        if self.error_input_key is not None:
            if error_input_dim is None:
                raise ValueError("error_input_dim is required when error_input_key is set")
            self.error_proj = nn.Linear(error_input_dim, code_feat_dim)
            self.rnn_error = self._build_recurrent(code_feat_dim)
            self.fc_error = nn.Linear(self.hidden_dim + p_feat_dim, self.hidden_dim)
            if self.channel_fusion == "gated_attention":
                self.channel_gate = nn.Linear(self.hidden_dim * 3, 3)
                nn.init.zeros_(self.channel_gate.weight)
                with torch.no_grad():
                    self.channel_gate.bias.copy_(
                        torch.tensor([channel_gate_kc_bias, 0.0, 0.0], dtype=self.channel_gate.bias.dtype)
                    )
            elif self.channel_fusion != "concat":
                raise ValueError(f"Unsupported channel_fusion: {self.channel_fusion}")
        elif self.channel_fusion not in {"concat", "none"}:
            raise ValueError("channel_fusion other than concat/none requires error_input_key")

        self.fc_g = nn.Linear(self.hidden_dim + p_feat_dim, self.hidden_dim)
        self.fc_h = nn.Linear(self.hidden_dim + p_feat_dim, self.hidden_dim)
        if self.error_input_key is None:
            out_dim = self.hidden_dim * 2
        elif self.channel_fusion == "gated_attention":
            out_dim = self.hidden_dim
        else:
            out_dim = self.hidden_dim * 3
        if self.target_skill_proj is not None:
            out_dim += self.hidden_dim
        self.out = nn.Linear(out_dim, 1)

    def _build_recurrent(self, input_dim: int) -> nn.Module:
        if self.rnn_type == "rnn":
            return nn.RNN(input_dim, self.hidden_dim, batch_first=True)
        if self.rnn_type == "gru":
            return nn.GRU(input_dim, self.hidden_dim, batch_first=True)
        if self.rnn_type == "lstm":
            return nn.LSTM(input_dim, self.hidden_dim, batch_first=True)
        raise ValueError(f"Unsupported rnn_type: {self.rnn_type}")

    def exponential_decay_attention(self, history, target):
        scores = torch.bmm(history, target.transpose(1, 2)).squeeze(-1)
        seq_len = history.size(1)
        steps = torch.arange(seq_len, 0, -1).float().to(history.device)
        decay = torch.exp(-self.lambda_decay * steps)
        attn = F.softmax(scores * decay, dim=-1)
        context = torch.bmm(attn.unsqueeze(1), history).squeeze(1)
        return context

    def all_step_exponential_decay_attention(self, history, targets):
        # history: [B, L, H], targets: [B, L-1, H].
        # Step t attends to history positions 0..t with the same decay as the scalar path.
        bsz, seq_len, _ = history.shape
        out_len = targets.size(1)
        scores = torch.bmm(history, targets.transpose(1, 2))  # [B, L, L-1]
        hist_pos = torch.arange(seq_len, device=history.device).view(seq_len, 1)
        pred_pos = torch.arange(out_len, device=history.device).view(1, out_len)
        valid = hist_pos <= pred_pos
        distance = (pred_pos + 1 - hist_pos).clamp_min(1).to(history.dtype)
        decay = torch.exp(-self.lambda_decay * distance)
        scores = scores * decay.unsqueeze(0)
        scores = scores.masked_fill(~valid.unsqueeze(0), torch.finfo(scores.dtype).min)
        attn = F.softmax(scores, dim=1)
        return torch.einsum("blt,blh->bth", attn, history)

    def target_skill_state_features(self, p_ids, raw_r_ids):
        # For the prediction at t+1, summarize the student's decayed
        # success/failure evidence through t and keep only skills connected to
        # the target problem q_{t+1}.
        if self.target_skill_proj is None:
            return None
        bsz, seq_len = p_ids.shape
        if seq_len < 2:
            return p_ids.new_zeros((bsz, 0, self.hidden_dim), dtype=torch.float32)
        skill = self.target_skill_matrix[p_ids.clamp(min=0)]
        valid = (raw_r_ids >= 0).to(dtype=skill.dtype).unsqueeze(-1)
        response = (raw_r_ids == 1).to(dtype=skill.dtype).unsqueeze(-1)
        pos_event = skill * response * valid
        neg_event = skill * (1.0 - response) * valid * self.target_skill_neg_weight

        pos_state = skill.new_zeros((bsz, skill.size(-1)))
        neg_state = skill.new_zeros((bsz, skill.size(-1)))
        if self.target_skill_exclude_same_problem_history:
            n_problem = int(self.target_skill_matrix.size(0))
            pos_by_problem = skill.new_zeros((bsz, n_problem, skill.size(-1)))
            neg_by_problem = skill.new_zeros((bsz, n_problem, skill.size(-1)))
        pos_hist = []
        neg_hist = []
        for step in range(seq_len - 1):
            pos_state = self.target_skill_decay * pos_state + pos_event[:, step, :]
            neg_state = self.target_skill_decay * neg_state + neg_event[:, step, :]
            if self.target_skill_exclude_same_problem_history:
                hist_problem = (
                    p_ids[:, step]
                    .clamp(min=0, max=n_problem - 1)
                    .view(bsz, 1, 1)
                    .expand(-1, 1, skill.size(-1))
                )
                pos_by_problem = self.target_skill_decay * pos_by_problem
                neg_by_problem = self.target_skill_decay * neg_by_problem
                pos_by_problem = pos_by_problem.scatter_add(
                    1, hist_problem, pos_event[:, step, :].unsqueeze(1)
                )
                neg_by_problem = neg_by_problem.scatter_add(
                    1, hist_problem, neg_event[:, step, :].unsqueeze(1)
                )
                target_problem = (
                    p_ids[:, step + 1]
                    .clamp(min=0, max=n_problem - 1)
                    .view(bsz, 1, 1)
                    .expand(-1, 1, skill.size(-1))
                )
                same_pos = pos_by_problem.gather(1, target_problem).squeeze(1)
                same_neg = neg_by_problem.gather(1, target_problem).squeeze(1)
                pos_hist.append(pos_state - same_pos)
                neg_hist.append(neg_state - same_neg)
            else:
                pos_hist.append(pos_state)
                neg_hist.append(neg_state)
        pos_hist = torch.stack(pos_hist, dim=1)
        neg_hist = torch.stack(neg_hist, dim=1)

        target_skill = skill[:, 1:, :]
        target_valid = (raw_r_ids[:, 1:] >= 0).to(dtype=skill.dtype).unsqueeze(-1)
        target_skill = target_skill * target_valid
        denom = self.target_skill_alpha + self.target_skill_beta + pos_hist + neg_hist
        mastery = (self.target_skill_alpha + pos_hist) / denom.clamp_min(1e-8)
        deficit = (self.target_skill_beta + neg_hist) / denom.clamp_min(1e-8)
        if self.target_skill_state == "deficit":
            feat = target_skill * deficit
        elif self.target_skill_state == "mastery_deficit":
            feat = torch.cat([target_skill * mastery, target_skill * deficit], dim=-1)
        else:
            balance = (pos_hist - neg_hist) / (pos_hist + neg_hist + 1e-8)
            feat = torch.cat(
                [target_skill * mastery, target_skill * deficit, target_skill * balance],
                dim=-1,
            )
        return F.relu(self.target_skill_proj(feat))

    def forward(self, p_ids, r_ids, c_vecs, return_aux: bool = False):
        raw_r_ids = r_ids
        p_emb = self.prob_emb(p_ids)
        if self.prob_emb_secondary is not None:
            p_emb_secondary = self.prob_emb_secondary(p_ids)
            if self.problem_fusion == "avg":
                p_emb = 0.5 * (p_emb + p_emb_secondary)
            elif self.problem_fusion == "gated_scalar":
                gate = torch.sigmoid(self.problem_gate(torch.cat([p_emb, p_emb_secondary], dim=-1)))
                p_emb = gate * p_emb + (1.0 - gate) * p_emb_secondary
        # Use only problem embedding as "current problem" feature.
        p_only = self.p_proj(p_emb) if self.p_proj is not None else p_emb
        if self.use_rasch:
            rasch_diff = self.difficult_param(p_ids)
            p_only = p_only + rasch_diff * self.p_embed_diff(p_ids)
        else:
            rasch_diff = None
        # Standard KT: use (q_t, r_t) to predict r_{t+1}.
        r_ids = r_ids.clamp(min=-1, max=1) + 1
        response_scalar = (r_ids == 2).to(dtype=p_only.dtype).unsqueeze(-1)
        r_emb = self.res_emb(r_ids)
        p_feat = p_only + r_emb
        if rasch_diff is not None and self.r_embed_diff is not None:
            p_feat = p_feat + rasch_diff * self.r_embed_diff(r_ids)
        if rasch_diff is not None and self.qa_embed_diff is not None:
            qa_ids = p_ids * 3 + r_ids
            p_feat = p_feat + rasch_diff * self.qa_embed_diff(qa_ids)
        error_vecs = None
        if isinstance(c_vecs, dict):
            if self.error_input_key is not None:
                if self.error_input_key not in c_vecs:
                    raise KeyError(f"Missing error channel key in c_vecs: {self.error_input_key}")
                error_vecs = c_vecs[self.error_input_key]
            materialized = {}
            for key in self.code_input_keys:
                if key not in c_vecs:
                    continue
                x = c_vecs[key]
                if key in self.code_input_bottlenecks:
                    x = self.code_input_bottlenecks[key](x)
                materialized[key] = x
            inputs = [materialized[key] for key in self.final_code_input_keys if key in materialized]
            if not inputs:
                raise RuntimeError("No code inputs available for fusion")
            if self.code_fusion and len(inputs) > 1:
                c_vecs = self.code_fusion(inputs)
            else:
                c_vecs = inputs[0]
        if self.c_proj is not None:
            c_vecs = self.c_proj(c_vecs)
        if self.code_problem_fusion != "none":
            p_code = self.code_problem_proj(p_only)
            if self.code_problem_fusion == "residual":
                c_vecs = c_vecs + self.code_problem_alpha * p_code
            elif self.code_problem_fusion == "gated_residual":
                gate = torch.sigmoid(self.code_problem_gate(torch.cat([c_vecs, p_code], dim=-1)))
                c_vecs = c_vecs + self.code_problem_alpha * gate * p_code
            elif self.code_problem_fusion == "film":
                gamma, beta = self.code_problem_film(p_only).chunk(2, dim=-1)
                c_vecs = c_vecs * (1.0 + self.code_problem_alpha * torch.tanh(gamma)) + self.code_problem_alpha * beta
        p_rnn_input = (
            torch.cat([p_feat, response_scalar], dim=-1)
            if self.explicit_response_problem
            else p_feat
        )
        c_rnn_input = (
            torch.cat([c_vecs, response_scalar], dim=-1)
            if self.explicit_response_code
            else c_vecs
        )
        g_out, _ = self.rnn_p(p_rnn_input)
        h_out, _ = self.rnn_c(c_rnn_input)
        e_out = None
        if self.error_input_key is not None:
            if error_vecs is None:
                raise RuntimeError("error_vecs is not available for the configured error channel")
            error_vecs = self.error_proj(error_vecs)
            e_out, _ = self.rnn_error(error_vecs)

        if p_feat.size(1) < 2:
            # No next-step target available; return empty predictions.
            empty = torch.zeros((p_feat.size(0), 0), device=p_feat.device)
            if return_aux and self.skill_aux_head is not None:
                return empty, self.skill_aux_head(h_out)
            return empty

        # Predict all r_{t+1} values in one batched GPU operation instead of
        # launching one small attention graph per timestep from Python.
        curr_p = p_only[:, 1:, :]
        curr_p_h = self.p2h(curr_p)
        ctx_g = self.all_step_exponential_decay_attention(g_out, curr_p_h)
        ctx_h = self.all_step_exponential_decay_attention(h_out, curr_p_h)
        logit_g = F.relu(self.fc_g(torch.cat([ctx_g, curr_p], -1)))
        logit_h = F.relu(self.fc_h(torch.cat([ctx_h, curr_p], -1)))
        if e_out is None:
            final = torch.cat([logit_g, logit_h], -1)
        else:
            ctx_e = self.all_step_exponential_decay_attention(e_out, curr_p_h)
            logit_e = F.relu(self.fc_error(torch.cat([ctx_e, curr_p], -1)))
            if self.channel_fusion == "gated_attention":
                gate_logits = self.channel_gate(torch.cat([logit_g, logit_h, logit_e], -1))
                gate = F.softmax(gate_logits, dim=-1).unsqueeze(-1)
                channels = torch.stack([logit_g, logit_h, logit_e], dim=-2)
                final = (gate * channels).sum(dim=-2)
            else:
                final = torch.cat([logit_g, logit_h, logit_e], -1)
        target_skill = self.target_skill_state_features(p_ids, raw_r_ids)
        if target_skill is not None:
            final = torch.cat([final, target_skill], -1)
        preds = torch.sigmoid(self.out(final)).squeeze(-1)
        if return_aux and self.skill_aux_head is not None:
            return preds, self.skill_aux_head(h_out)
        return preds

    def rasch_regularization(self, p_ids):
        if not self.use_rasch or self.rasch_l2 <= 0 or self.difficult_param is None:
            return p_ids.new_zeros((), dtype=torch.float32)
        rasch_diff = self.difficult_param(p_ids)
        return rasch_diff.pow(2).mean() * self.rasch_l2


class CSVPDKTDataset(Dataset):
    def __init__(
        self,
        df: pd.DataFrame,
        code_embeddings: torch.Tensor,
        code_extra: Dict[str, torch.Tensor],
        indices: List[int],
        max_seq_len: int,
    ):
        self.df = df
        self.code_embeddings = code_embeddings
        self.code_extra = code_extra or {}
        self.user_groups = list(df.groupby("user_id", sort=False))
        self.selected_users = [self.user_groups[i] for i in indices]
        self.max_seq_len = max_seq_len
        self.lengths = []
        for _, group in self.selected_users:
            seq_len = len(group)
            if seq_len > max_seq_len:
                seq_len = max_seq_len
            self.lengths.append(seq_len)

    def __len__(self):
        return len(self.selected_users)

    def __getitem__(self, idx):
        _, group = self.selected_users[idx]
        problem_ids = group["problem_id"].to_numpy(dtype=np.int64, copy=False)
        results = group["result"].to_numpy(dtype=np.int64, copy=False)
        row_idx = group["row_idx"].to_numpy(dtype=np.int64, copy=False)
        event_idx = np.arange(len(group), dtype=np.int64)

        if len(problem_ids) > self.max_seq_len:
            problem_ids = problem_ids[-self.max_seq_len :]
            results = results[-self.max_seq_len :]
            row_idx = row_idx[-self.max_seq_len :]
            event_idx = event_idx[-self.max_seq_len :]

        p_ids = torch.from_numpy(problem_ids).long()
        row_idx = torch.from_numpy(row_idx).long()
        event_idx = torch.from_numpy(event_idx).long()
        base_vecs = self.code_embeddings.index_select(0, row_idx)
        if self.code_extra:
            c_vecs = {"base": base_vecs}
            for name, emb in self.code_extra.items():
                c_vecs[name] = emb.index_select(0, row_idx)
        else:
            c_vecs = base_vecs

        return {
            "user_id": str(group["user_id"].iloc[0]),
            "p_ids": p_ids,
            "r_ids": torch.from_numpy(results).long(),
            "c_vecs": c_vecs,
            "labels": torch.from_numpy(results).float(),
            "row_idx": row_idx,
            "event_idx": event_idx,
        }


def collate_fn(batch):
    p_ids = pad_sequence([b["p_ids"] for b in batch], batch_first=True, padding_value=0)
    r_ids = pad_sequence([b["r_ids"] for b in batch], batch_first=True, padding_value=-1)
    sample_c = batch[0]["c_vecs"]
    if isinstance(sample_c, dict):
        c_vecs = {
            key: pad_sequence([b["c_vecs"][key] for b in batch], batch_first=True, padding_value=0)
            for key in sample_c.keys()
        }
    else:
        c_vecs = pad_sequence([b["c_vecs"] for b in batch], batch_first=True, padding_value=0)
    labels = pad_sequence([b["labels"] for b in batch], batch_first=True, padding_value=-1)
    row_idx = pad_sequence([b["row_idx"] for b in batch], batch_first=True, padding_value=-1)
    event_idx = pad_sequence([b["event_idx"] for b in batch], batch_first=True, padding_value=-1)
    user_ids = [b["user_id"] for b in batch]
    return p_ids, r_ids, c_vecs, labels, row_idx, event_idx, user_ids


def _stratified_user_split(df, seed: int, bins: int):
    # Stratify by per-user correctness rate to balance difficulty across splits.
    user_stats = df.groupby("user_id")["result"].mean().rename("correct_rate").reset_index()
    # Quantile bins; drop duplicates if not enough unique values.
    try:
        user_stats["bin"] = pd.qcut(user_stats["correct_rate"], q=bins, duplicates="drop")
    except ValueError:
        user_stats["bin"] = 0
    rng = np.random.default_rng(seed)
    train_users, val_users, test_users = [], [], []
    for _, grp in user_stats.groupby("bin"):
        users = grp["user_id"].to_numpy()
        rng.shuffle(users)
        n = len(users)
        n_train = int(n * 0.8)
        n_val = int(n * 0.1)
        train_users.extend(users[:n_train])
        val_users.extend(users[n_train : n_train + n_val])
        test_users.extend(users[n_train + n_val :])
    return [str(u) for u in train_users], [str(u) for u in val_users], [str(u) for u in test_users]


def _split_stats(df: pd.DataFrame, user_set: set):
    user_keys = {str(u) for u in user_set}
    sub = df[df["user_id"].astype(str).isin(user_keys)]
    seq_lens = sub.groupby("user_id").size()
    return {
        "users": len(user_set),
        "rows": len(sub),
        "avg_seq_len": float(seq_lens.mean()) if len(seq_lens) else 0.0,
        "median_seq_len": float(seq_lens.median()) if len(seq_lens) else 0.0,
        "min_seq_len": int(seq_lens.min()) if len(seq_lens) else 0,
        "max_seq_len": int(seq_lens.max()) if len(seq_lens) else 0,
        "correct_rate": float(sub["result"].mean()) if len(sub) else 0.0,
    }


def _load_user_split(path: Path):
    payload = json.loads(path.read_text(encoding="utf-8"))
    return {
        "train_user_ids": [str(u) for u in payload["train_user_ids"]],
        "val_user_ids": [str(u) for u in payload["val_user_ids"]],
        "test_user_ids": [str(u) for u in payload["test_user_ids"]],
        "meta": payload.get("meta", {}),
    }


def build_loaders(
    df,
    code_emb,
    code_extra,
    max_seq_len,
    batch_size,
    seed,
    stratify_users: bool,
    stratify_bins: int,
    print_split_stats: bool,
    split_json: Optional[Path] = None,
):
    if split_json is not None:
        split_payload = _load_user_split(split_json)
        # Preserve the explicit user order from split_json. Converting these to
        # sets makes the dataset order depend on Python hash randomization,
        # which breaks run-to-run reproducibility across processes.
        train_users = list(split_payload["train_user_ids"])
        val_users = list(split_payload["val_user_ids"])
        test_users = list(split_payload["test_user_ids"])
    else:
        users = df["user_id"].astype(str).unique()
        if stratify_users:
            train_users, val_users, test_users = _stratified_user_split(df, seed, stratify_bins)
        else:
            rng = np.random.default_rng(seed)
            rng.shuffle(users)
            n = len(users)
            n_train = int(n * 0.8)
            n_val = int(n * 0.1)
            train_users = list(users[:n_train])
            val_users = list(users[n_train : n_train + n_val])
            test_users = list(users[n_train + n_val :])
        split_payload = {
            "train_user_ids": [str(u) for u in train_users],
            "val_user_ids": [str(u) for u in val_users],
            "test_user_ids": [str(u) for u in test_users],
            "meta": {
                "seed": seed,
                "stratify_users": stratify_users,
                "stratify_bins": stratify_bins,
            },
        }

    if print_split_stats:
        train_user_set = set(train_users)
        val_user_set = set(val_users)
        test_user_set = set(test_users)
        overlap = (train_user_set & val_user_set) | (train_user_set & test_user_set) | (val_user_set & test_user_set)
        if overlap:
            print(f"[Warn] split overlap detected: {len(overlap)} users")
        print("[Split stats] train", _split_stats(df, train_users))
        print("[Split stats] val  ", _split_stats(df, val_users))
        print("[Split stats] test ", _split_stats(df, test_users))

    # Compute pos_weight from train split for class-imbalance handling.
    train_sub = df[df["user_id"].astype(str).isin(train_users)]
    pos = int((train_sub["result"] == 1).sum())
    neg = int((train_sub["result"] == 0).sum())
    pos_weight = (neg / max(pos, 1)) if (pos + neg) > 0 else 1.0

    user_to_idx = {str(uid): i for i, (uid, _) in enumerate(df.groupby("user_id", sort=False))}
    train_idx = [user_to_idx[u] for u in train_users if u in user_to_idx]
    val_idx = [user_to_idx[u] for u in val_users if u in user_to_idx]
    test_idx = [user_to_idx[u] for u in test_users if u in user_to_idx]

    train_ds = CSVPDKTDataset(df, code_emb, code_extra, train_idx, max_seq_len)
    val_ds = CSVPDKTDataset(df, code_emb, code_extra, val_idx, max_seq_len)
    test_ds = CSVPDKTDataset(df, code_emb, code_extra, test_idx, max_seq_len)

    train_loader = DataLoader(
        train_ds,
        batch_sampler=BucketBatchSampler(train_ds.lengths, batch_size, True, False),
        collate_fn=collate_fn,
        num_workers=0,
    )
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, collate_fn=collate_fn)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, collate_fn=collate_fn)
    return train_loader, val_loader, test_loader, pos_weight, split_payload


def compute_loss(preds, targets, pos_weight: Optional[float], focal_gamma: float, focal_alpha: float):
    eps = 1e-7
    preds = preds.clamp(eps, 1.0 - eps)
    if focal_gamma and focal_gamma > 0:
        pt = torch.where(targets == 1, preds, 1.0 - preds)
        alpha = torch.where(targets == 1, focal_alpha, 1.0 - focal_alpha)
        loss = -alpha * (1.0 - pt) ** focal_gamma * torch.log(pt)
    else:
        if pos_weight is not None:
            loss = -(
                pos_weight * targets * torch.log(preds)
                + (1.0 - targets) * torch.log(1.0 - preds)
            )
        else:
            loss = -(
                targets * torch.log(preds)
                + (1.0 - targets) * torch.log(1.0 - preds)
            )
    return loss


def select_best_f1_threshold(targets: np.ndarray, preds: np.ndarray) -> tuple[float, float]:
    precision, recall, thresholds = precision_recall_curve(targets.astype(np.int64), preds)
    if thresholds.size == 0:
        thr = 0.5
        pred_labels = (preds >= thr).astype(np.int64)
        f1 = float(f1_score(targets.astype(np.int64), pred_labels, zero_division=0))
        return thr, f1
    f1_scores = 2 * precision[:-1] * recall[:-1] / np.clip(precision[:-1] + recall[:-1], 1e-12, None)
    best_idx = int(np.nanargmax(f1_scores))
    return float(thresholds[best_idx]), float(f1_scores[best_idx])


def evaluate(model, loader, device, collect_predictions: bool = False, threshold: float = 0.5):
    model.eval()
    all_preds, all_targets = [], []
    records = []
    with torch.no_grad():
        for p_ids, r_ids, c_vecs, labels, row_idx, event_idx, user_ids in loader:
            p_ids, r_ids, labels = p_ids.to(device), r_ids.to(device), labels.to(device)
            if isinstance(c_vecs, dict):
                c_vecs = {k: v.to(device) for k, v in c_vecs.items()}
            else:
                c_vecs = c_vecs.to(device)
            preds = model(p_ids, r_ids, c_vecs)
            targets = labels[:, 1:]
            target_rows = row_idx[:, 1:]
            target_events = event_idx[:, 1:]
            mask = targets != -1
            if mask.sum() == 0:
                continue
            all_preds.extend(preds[mask].cpu().numpy())
            all_targets.extend(targets[mask].cpu().numpy())
            if collect_predictions:
                preds_cpu = preds.cpu()
                targets_cpu = targets.cpu()
                rows_cpu = target_rows.cpu()
                events_cpu = target_events.cpu()
                for i, user_id in enumerate(user_ids):
                    valid = targets_cpu[i] != -1
                    pred_vals = preds_cpu[i][valid].tolist()
                    target_vals = targets_cpu[i][valid].tolist()
                    row_vals = rows_cpu[i][valid].tolist()
                    event_vals = events_cpu[i][valid].tolist()
                    for row_val, event_val, target_val, pred_val in zip(row_vals, event_vals, target_vals, pred_vals):
                        records.append(
                            {
                                "user_id": user_id,
                                "row_idx": int(row_val),
                                "event_idx": int(event_val),
                                "target": float(target_val),
                                "pred": float(pred_val),
                            }
                        )
    auc = roc_auc_score(all_targets, all_preds)
    preds_np = np.array(all_preds)
    targets_np = np.array(all_targets)
    rmse = float(np.sqrt(np.mean((preds_np - targets_np) ** 2)))
    pred_labels = (preds_np >= threshold).astype(np.int64)
    precision, recall, f1, _ = precision_recall_fscore_support(
        targets_np.astype(np.int64), pred_labels, average="binary", zero_division=0
    )
    return auc, rmse, float(precision), float(recall), float(f1), records


def main():
    parser = argparse.ArgumentParser(description="Run PDKT-PEBG model on CSV sequences.")
    parser.add_argument("--data-csv", required=True, help="CSV with user_id, problem_id, result, (optional) Order")
    parser.add_argument("--problem-emb", required=True)
    parser.add_argument("--problem-emb-secondary", default=None, help="Optional second problem embedding for coarse/fine fusion")
    parser.add_argument(
        "--problem-emb-fusion",
        choices=["none", "avg", "gated_scalar"],
        default="none",
        help="How to fuse primary/secondary problem embeddings when both are provided",
    )
    parser.add_argument("--problem-gate-hidden", type=int, default=None, help="Hidden dim for learnable problem gate")
    parser.add_argument(
        "--code-problem-fusion",
        choices=["none", "residual", "gated_residual", "film"],
        default="none",
        help="Condition code branch on problem embeddings before the code RNN",
    )
    parser.add_argument(
        "--code-problem-alpha",
        type=float,
        default=1.0,
        help="Scale applied to problem-conditioned update on the code branch",
    )
    parser.add_argument(
        "--code-problem-gate-hidden",
        type=int,
        default=None,
        help="Hidden dim for gated_residual code-problem fusion",
    )
    parser.add_argument("--pro-id-dict", default=None)
    parser.add_argument("--no-pro-id-map", action="store_true", help="Use problem_id as-is (no mapping).")
    parser.add_argument("--code-emb", required=True)
    parser.add_argument("--code-emb-sum", default=None)
    parser.add_argument("--code-emb-implementation", default=None)
    parser.add_argument("--code-emb-iice", default=None)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--max-seq-len", type=int, default=200)
    parser.add_argument("--hidden-dim", type=int, default=None, help="RNN hidden dim (default: problem emb dim)")
    parser.add_argument("--rnn-type", choices=["rnn", "gru", "lstm"], default="rnn")
    parser.add_argument("--proj-dim", type=int, default=None, help="Project problem/code embeddings to this dim")
    parser.add_argument("--code-proj-dim", type=int, default=None, help="Project only code embeddings to this dim")
    parser.add_argument("--lambda-decay", type=float, default=0.6)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--split-seed", type=int, default=None, help="Seed used only for train/val/test split")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--normalize-prob-emb", action="store_true", help="L2-normalize problem embeddings")
    parser.add_argument("--normalize-code-emb", action="store_true", help="L2-normalize code embeddings (base/extra)")
    parser.add_argument("--stratify-users", action="store_true", help="Stratify train/val/test by user correct rate")
    parser.add_argument("--stratify-bins", type=int, default=5, help="Number of quantile bins for stratification")
    parser.add_argument("--print-split-stats", action="store_true", help="Print split statistics (user/rows/accuracy)")
    parser.add_argument("--code-fuse-dim", type=int, default=None)
    parser.add_argument("--code-fuse-hidden", type=int, default=None)
    parser.add_argument("--code-fuse-dropout", type=float, default=0.1)
    parser.add_argument(
        "--error-channel-key",
        default=None,
        help="Use one additional code tensor, e.g. implementation, as a separate channel.",
    )
    parser.add_argument(
        "--channel-fusion",
        choices=["concat", "gated_attention"],
        default="concat",
        help="How to combine problem/code/error heads when an error channel is enabled.",
    )
    parser.add_argument(
        "--channel-gate-kc-bias",
        type=float,
        default=1.0,
        help="Initial softmax-gate bias for the problem/KC head in gated_attention fusion.",
    )
    parser.add_argument("--pos-weight", type=float, default=None, help="Positive class weight for BCE")
    parser.add_argument("--auto-pos-weight", action="store_true", help="Use train-split pos_weight automatically")
    parser.add_argument("--focal-gamma", type=float, default=0.0, help="Focal loss gamma (0 disables)")
    parser.add_argument("--focal-alpha", type=float, default=0.25, help="Focal loss alpha")
    parser.add_argument(
        "--skill-aux-key",
        default=None,
        help="Optional additional code key used as an auxiliary implementation-skill target.",
    )
    parser.add_argument(
        "--skill-aux-weight",
        type=float,
        default=0.0,
        help="Weight for auxiliary implementation-skill BCE loss.",
    )
    parser.add_argument(
        "--explicit-response-input",
        choices=["none", "problem", "code", "both"],
        default="none",
        help="Append an explicit 0/1 correctness scalar to problem/code RNN inputs.",
    )
    parser.add_argument(
        "--code-bottleneck-key",
        default=None,
        help="Apply a learned bottleneck projection to one additional code input before PNN fusion.",
    )
    parser.add_argument(
        "--code-bottleneck-dim",
        type=int,
        default=None,
        help="Output dim for --code-bottleneck-key before PNN fusion.",
    )
    parser.add_argument(
        "--target-skill-matrix",
        default=None,
        help="Problem-by-implementation-skill matrix for target-aware skill-state decoding.",
    )
    parser.add_argument(
        "--target-skill-state",
        choices=["none", "deficit", "mastery_deficit", "pndiff"],
        default="none",
        help="Append target-aware implementation-skill state features to the decoder.",
    )
    parser.add_argument("--target-skill-decay", type=float, default=0.8)
    parser.add_argument("--target-skill-alpha", type=float, default=1.0)
    parser.add_argument("--target-skill-beta", type=float, default=1.0)
    parser.add_argument("--target-skill-neg-weight", type=float, default=1.0)
    parser.add_argument(
        "--target-skill-exclude-same-problem-history",
        action="store_true",
        help=(
            "For each target prediction, exclude accumulated implementation-skill "
            "evidence from prior interactions on that exact problem."
        ),
    )
    parser.add_argument("--early-stop-metric", choices=["auc", "rmse", "f1"], default=None)
    parser.add_argument("--early-stop-patience", type=int, default=3)
    parser.add_argument("--early-stop-min-improvement", type=float, default=0.0)
    parser.add_argument("--early-stop-threshold", type=float, default=0.5)
    parser.add_argument("--early-stop-threshold-mode", choices=["fixed", "val_best"], default="fixed")
    parser.add_argument("--user-split-json", default=None, help="Load fixed user split from JSON")
    parser.add_argument("--save-split-json", default=None, help="Save resolved user split to JSON")
    parser.add_argument("--pred-out", default=None, help="Write test-set event predictions to CSV")
    parser.add_argument("--val-pred-out", default=None, help="Write validation-set event predictions to CSV")
    parser.add_argument("--ckpt-out", default=None, help="Save best model checkpoint to this path")
    parser.add_argument("--result-out", default=None, help="Write val/test summary metrics to JSON")
    parser.add_argument("--use-rasch", action="store_true", help="Add AKT-style item difficulty correction.")
    parser.add_argument("--rasch-l2", type=float, default=0.0, help="L2 penalty for Rasch difficulty scalar.")
    parser.add_argument(
        "--rasch-response-diff",
        action="store_true",
        help="Also modulate response embedding with the Rasch difficulty scalar.",
    )
    parser.add_argument(
        "--rasch-qa-diff",
        action="store_true",
        help="Also modulate interaction features with a question-response specific Rasch diff vector.",
    )
    args = parser.parse_args()

    # Make training as deterministic as possible for a given --seed.
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        if hasattr(torch.backends.cudnn, "allow_tf32"):
            torch.backends.cudnn.allow_tf32 = False
    if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
        torch.backends.cuda.matmul.allow_tf32 = False
    if hasattr(torch, "use_deterministic_algorithms"):
        torch.use_deterministic_algorithms(True)

    df = pd.read_csv(args.data_csv)
    df = df.reset_index().rename(columns={"index": "row_idx"})

    if args.no_pro_id_map:
        # Keep problem_id as-is.
        if df["problem_id"].isna().any():
            df = df[df["problem_id"].notna()].copy()
        df["problem_id"] = df["problem_id"].astype(int)
    else:
        if not args.pro_id_dict:
            raise ValueError("--pro-id-dict is required unless --no-pro-id-map is set")
        pro_map = load_pro_id_dict(Path(args.pro_id_dict))
        df["problem_id"] = df["problem_id"].map(pro_map)
        df = df[df["problem_id"].notna()].copy()
        df["problem_id"] = df["problem_id"].astype(int)
    if "Order" in df.columns:
        df = df.sort_values(["user_id", "Order", "row_idx"]).reset_index(drop=True)
    else:
        df = df.sort_values(["user_id", "row_idx"]).reset_index(drop=True)

    prob_emb = torch.load(args.problem_emb, map_location="cpu").float()
    prob_emb_secondary = None
    if args.problem_emb_secondary:
        prob_emb_secondary = torch.load(args.problem_emb_secondary, map_location="cpu").float()
    code_emb = torch.load(args.code_emb, map_location="cpu").float()
    if args.normalize_prob_emb:
        prob_emb = F.normalize(prob_emb, p=2, dim=1)
        if prob_emb_secondary is not None:
            prob_emb_secondary = F.normalize(prob_emb_secondary, p=2, dim=1)
    if args.normalize_code_emb:
        code_emb = F.normalize(code_emb, p=2, dim=1)
    target_skill_matrix = None
    if args.target_skill_matrix:
        target_skill_matrix = torch.load(args.target_skill_matrix, map_location="cpu").float()
    code_extra: Dict[str, torch.Tensor] = {}
    sum_emb = _load_optional_embedding(Path(args.code_emb_sum) if args.code_emb_sum else None, "summary")
    if sum_emb is not None:
        code_extra["summary"] = F.normalize(sum_emb, p=2, dim=1) if args.normalize_code_emb else sum_emb
    implementation_emb = _load_optional_embedding(
        Path(args.code_emb_implementation) if args.code_emb_implementation else None,
        "implementation",
    )
    if implementation_emb is not None:
        code_extra["implementation"] = (
            F.normalize(implementation_emb, p=2, dim=1)
            if args.normalize_code_emb
            else implementation_emb
        )
    iice_emb = _load_optional_embedding(Path(args.code_emb_iice) if args.code_emb_iice else None, "iice")
    if iice_emb is not None:
        code_extra["iice"] = F.normalize(iice_emb, p=2, dim=1) if args.normalize_code_emb else iice_emb

    if code_emb.size(0) != len(df):
        raise ValueError(f"Row-aligned code_emb size mismatch: {code_emb.size(0)} vs df {len(df)}")
    for name, emb in code_extra.items():
        if emb.size(0) != len(df):
            raise ValueError(f"Row-aligned {name} emb size mismatch: {emb.size(0)} vs df {len(df)}")

    if str(args.device).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(f"Requested CUDA device {args.device}, but CUDA is not available")
    device = args.device if str(args.device).startswith("cuda") else "cpu"
    print(f"[device] {device}", flush=True)
    split_seed = args.split_seed if args.split_seed is not None else args.seed
    train_loader, val_loader, test_loader, train_pos_weight, split_payload = build_loaders(
        df,
        code_emb,
        code_extra,
        args.max_seq_len,
        args.batch_size,
        split_seed,
        args.stratify_users,
        args.stratify_bins,
        args.print_split_stats,
        Path(args.user_split_json) if args.user_split_json else None,
    )
    if args.save_split_json:
        out_path = Path(args.save_split_json)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(split_payload, indent=2), encoding="utf-8")
        print(f"[Split] saved {out_path}")

    if args.error_channel_key is not None and args.error_channel_key not in code_extra:
        raise ValueError(
            f"--error-channel-key={args.error_channel_key} was requested, "
            f"but available extra keys are {sorted(code_extra.keys())}"
        )
    if args.skill_aux_weight > 0:
        if args.skill_aux_key is None:
            raise ValueError("--skill-aux-key is required when --skill-aux-weight > 0")
        if args.skill_aux_key not in code_extra:
            raise ValueError(
                f"--skill-aux-key={args.skill_aux_key} was requested, "
                f"but available extra keys are {sorted(code_extra.keys())}"
            )
    code_extra_for_fusion = [k for k in code_extra.keys() if k != args.error_channel_key]
    code_input_keys = ["base"] + code_extra_for_fusion
    code_input_dims = None
    if code_extra_for_fusion:
        code_input_dims = [code_emb.size(1)] + [code_extra[k].size(1) for k in code_extra_for_fusion]
    error_input_dim = code_extra[args.error_channel_key].size(1) if args.error_channel_key is not None else None
    skill_aux_dim = code_extra[args.skill_aux_key].size(1) if args.skill_aux_weight > 0 else None
    proj_dim = args.proj_dim
    hidden_dim = args.hidden_dim or (proj_dim if proj_dim is not None else prob_emb.size(1))
    model = PDKTModel(
        prob_emb,
        pretrained_prob_emb_secondary=prob_emb_secondary,
        hidden_dim=hidden_dim,
        code_dim=code_emb.size(1),
        lambda_decay=args.lambda_decay,
        rnn_type=args.rnn_type,
        proj_dim=proj_dim,
        code_proj_dim=args.code_proj_dim,
        code_input_keys=code_input_keys,
        code_input_dims=code_input_dims,
        code_fuse_dim=args.code_fuse_dim,
        code_fuse_hidden=args.code_fuse_hidden,
        code_fuse_dropout=args.code_fuse_dropout,
        use_rasch=args.use_rasch,
        rasch_l2=args.rasch_l2,
        rasch_response_diff=args.rasch_response_diff,
        rasch_qa_diff=args.rasch_qa_diff,
        problem_fusion=args.problem_emb_fusion,
        problem_gate_hidden=args.problem_gate_hidden,
        code_problem_fusion=args.code_problem_fusion,
        code_problem_alpha=args.code_problem_alpha,
        code_problem_gate_hidden=args.code_problem_gate_hidden,
        error_input_key=args.error_channel_key,
        error_input_dim=error_input_dim,
        channel_fusion=args.channel_fusion,
        channel_gate_kc_bias=args.channel_gate_kc_bias,
        skill_aux_dim=skill_aux_dim,
        explicit_response_input=args.explicit_response_input,
        code_bottleneck_key=args.code_bottleneck_key,
        code_bottleneck_dim=args.code_bottleneck_dim,
        target_skill_matrix=target_skill_matrix,
        target_skill_state=args.target_skill_state,
        target_skill_decay=args.target_skill_decay,
        target_skill_alpha=args.target_skill_alpha,
        target_skill_beta=args.target_skill_beta,
        target_skill_neg_weight=args.target_skill_neg_weight,
        target_skill_exclude_same_problem_history=args.target_skill_exclude_same_problem_history,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    pos_weight = args.pos_weight
    if pos_weight is None and args.auto_pos_weight:
        pos_weight = train_pos_weight

    best_metric = None
    best_state = None
    best_epoch = None
    best_val_auc = None
    best_val_rmse = None
    best_val_f1 = None
    best_val_precision = None
    best_val_recall = None
    best_threshold = args.early_stop_threshold
    patience = 0

    for epoch in range(args.epochs):
        model.train()
        losses = []
        for p_ids, r_ids, c_vecs, labels, row_idx, event_idx, user_ids in tqdm(train_loader, desc=f"Epoch {epoch+1}"):
            p_ids, r_ids, labels = p_ids.to(device), r_ids.to(device), labels.to(device)
            if isinstance(c_vecs, dict):
                c_vecs = {k: v.to(device) for k, v in c_vecs.items()}
            else:
                c_vecs = c_vecs.to(device)
            optimizer.zero_grad()
            if args.skill_aux_weight > 0:
                preds, skill_aux_logits = model(p_ids, r_ids, c_vecs, return_aux=True)
            else:
                preds = model(p_ids, r_ids, c_vecs)
                skill_aux_logits = None
            targets = labels[:, 1:]
            mask = targets != -1
            if mask.sum() == 0:
                continue
            loss = compute_loss(preds[mask], targets[mask], pos_weight, args.focal_gamma, args.focal_alpha).mean()
            if args.skill_aux_weight > 0 and skill_aux_logits is not None:
                if not isinstance(c_vecs, dict):
                    raise RuntimeError("skill auxiliary loss requires dict c_vecs")
                skill_targets = c_vecs[args.skill_aux_key].clamp(0.0, 1.0)
                skill_mask = labels != -1
                if skill_mask.sum() > 0:
                    skill_aux_loss = F.binary_cross_entropy_with_logits(
                        skill_aux_logits[skill_mask],
                        skill_targets[skill_mask],
                    )
                    loss = loss + float(args.skill_aux_weight) * skill_aux_loss
            if args.use_rasch and args.rasch_l2 > 0:
                loss = loss + model.rasch_regularization(p_ids)
            loss.backward()
            optimizer.step()
            losses.append(loss.item())
        val_auc, val_rmse, _val_precision_fixed, _val_recall_fixed, _val_f1_fixed, _ = evaluate(
            model, val_loader, device, threshold=args.early_stop_threshold
        )
        if args.early_stop_threshold_mode == "val_best":
            val_auc_tmp, val_rmse_tmp, records = None, None, None
            model.eval()
            all_preds = []
            all_targets = []
            with torch.no_grad():
                for p_ids, r_ids, c_vecs, labels, row_idx, event_idx, user_ids in val_loader:
                    p_ids, r_ids, labels = p_ids.to(device), r_ids.to(device), labels.to(device)
                    if isinstance(c_vecs, dict):
                        c_vecs = {k: v.to(device) for k, v in c_vecs.items()}
                    else:
                        c_vecs = c_vecs.to(device)
                    preds = model(p_ids, r_ids, c_vecs)
                    targets = labels[:, 1:]
                    mask = targets != -1
                    if mask.sum() == 0:
                        continue
                    all_preds.extend(preds[mask].detach().cpu().numpy())
                    all_targets.extend(targets[mask].detach().cpu().numpy())
            preds_np = np.array(all_preds)
            targets_np = np.array(all_targets)
            val_threshold, _ = select_best_f1_threshold(targets_np, preds_np)
        else:
            val_threshold = args.early_stop_threshold
        val_auc, val_rmse, val_precision, val_recall, val_f1, _ = evaluate(
            model, val_loader, device, threshold=val_threshold
        )
        print(
            f"Epoch {epoch+1} | val AUC: {val_auc:.4f} | val RMSE: {val_rmse:.4f} | "
            f"val F1@{val_threshold:.4f}: {val_f1:.4f} | loss: {np.mean(losses):.4f}"
        )
        if args.early_stop_metric:
            if args.early_stop_metric == "auc":
                metric = val_auc
            elif args.early_stop_metric == "rmse":
                metric = val_rmse
            else:
                metric = val_f1
            if best_metric is None:
                improved = True
            else:
                if args.early_stop_metric in {"auc", "f1"}:
                    improved = metric > best_metric + args.early_stop_min_improvement
                else:
                    improved = metric < best_metric - args.early_stop_min_improvement
            if improved:
                best_metric = metric
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                best_epoch = epoch + 1
                best_val_auc = float(val_auc)
                best_val_rmse = float(val_rmse)
                best_val_f1 = float(val_f1)
                best_val_precision = float(val_precision)
                best_val_recall = float(val_recall)
                best_threshold = float(val_threshold)
                patience = 0
            else:
                patience += 1
                if patience >= args.early_stop_patience:
                    print(f"[EarlyStop] stopped at epoch {epoch+1}")
                    break

    if best_state is not None:
        model.load_state_dict(best_state)
    if args.ckpt_out:
        ckpt_out = Path(args.ckpt_out)
        ckpt_out.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "model_state_dict": model.state_dict(),
                "best_metric": best_metric,
                "args": vars(args),
            },
            ckpt_out,
        )
        print(f"[Checkpoint] saved {ckpt_out}")
    val_auc_final, val_rmse_final, val_precision_final, val_recall_final, val_f1_final, val_records = evaluate(
        model,
        val_loader,
        device,
        collect_predictions=bool(args.val_pred_out),
        threshold=best_threshold,
    )
    test_auc, test_rmse, test_precision, test_recall, test_f1, records = evaluate(
        model,
        test_loader,
        device,
        collect_predictions=bool(args.pred_out),
        threshold=best_threshold,
    )
    if args.pred_out:
        pred_out = Path(args.pred_out)
        pred_out.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame.from_records(records).to_csv(pred_out, index=False)
        print(f"[Pred] saved {pred_out} rows={len(records)}")
    if args.val_pred_out:
        val_pred_out = Path(args.val_pred_out)
        val_pred_out.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame.from_records(val_records).to_csv(val_pred_out, index=False)
        print(f"[Pred] saved {val_pred_out} rows={len(val_records)}")
    if args.result_out:
        result_out = Path(args.result_out)
        result_out.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "best_epoch": best_epoch,
            "best_metric": best_metric,
            "best_val_auc": best_val_auc,
            "best_val_rmse": best_val_rmse,
            "best_val_f1": best_val_f1 if best_state is not None else None,
            "best_val_precision": best_val_precision if best_state is not None else None,
            "best_val_recall": best_val_recall if best_state is not None else None,
            "best_threshold": best_threshold if best_state is not None else args.early_stop_threshold,
            "val_auc": float(val_auc_final),
            "val_rmse": float(val_rmse_final),
            "val_precision": float(val_precision_final),
            "val_recall": float(val_recall_final),
            "val_f1": float(val_f1_final),
            "test_auc": float(test_auc),
            "test_rmse": float(test_rmse),
            "test_precision": float(test_precision),
            "test_recall": float(test_recall),
            "test_f1": float(test_f1),
            "rnn_type": args.rnn_type,
            "args": vars(args),
        }
        result_out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(f"[Result] saved {result_out}")
    print(f">>> Test AUC: {test_auc:.4f}")
    print(f">>> Test RMSE: {test_rmse:.4f}")
    print(f">>> Test Precision@{best_threshold:.4f}: {test_precision:.4f}")
    print(f">>> Test Recall@{best_threshold:.4f}: {test_recall:.4f}")
    print(f">>> Test F1@{best_threshold:.4f}: {test_f1:.4f}")


if __name__ == "__main__":
    main()
