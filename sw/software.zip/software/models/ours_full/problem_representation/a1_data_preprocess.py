# 이 파일은 각 데이터에서 문제 관련 특징과 스킬 관련 특징을 추출하는 역할을 함
# 추후 실행시 CSEDM 또는 BePKT 데이터셋을 선택하여 처리할 수 있음

import os
import pandas as pd
import numpy as np
from scipy import sparse

class DataProcess:
    def __init__(self, data_folder, dataset_type='bepkt', min_inter_num=3):
        """
        dataset_type: 'bepkt' or 'csedm'
        """
        self.data_folder = data_folder
        self.dataset_type = dataset_type
        self.min_inter_num = min_inter_num
        
        if not os.path.exists(self.data_folder):
            os.makedirs(self.data_folder)

    def process_csv(self, interaction_file, mapping_file=None):
        """
        interaction_file: user_id, problem_id, correct 컬럼이 있는 CSV
        mapping_file:
            - BePKT: problem_tags_remapped.csv
            - CSEDM: 2nd CSEDM Data Challenge...csv
        """
        print(f"[{self.dataset_type.upper()}] Processing Data...")

        # 1. Interaction Data Load
        df = pd.read_csv(os.path.join(self.data_folder, interaction_file))
        
        # 컬럼 이름 통일 (User ID, Problem ID, Correct)
        # 데이터셋별로 컬럼명이 다르면 여기서 수정하세요.
        if self.dataset_type == 'csedm':
            # 예: CSEDM은 ProblemID 대소문자 주의
            rename_map = {'UserID': 'user_id', 'ProblemID': 'problem_id', 'Correct': 'correct'}
            df = df.rename(columns=rename_map)
        
        required = ['user_id', 'problem_id', 'correct']
        for col in required:
            if col not in df.columns:
                raise ValueError(f"Interaction CSV must have column: {col}")

        # 2. Skill Mapping Load & Merge
        if mapping_file:
            map_path = os.path.join(self.data_folder, mapping_file)
            
            if self.dataset_type == 'bepkt':
                # BePKT: problem_id, problemtag_id
                # problem_tags_remapped.csv 사용
                map_df = pd.read_csv(map_path)
                # 문제 하나에 여러 태그가 있을 수 있음 -> GroupBy로 리스트화
                # map_df의 컬럼: id, problem_id, problemtag_id
                skill_map = map_df.groupby('problem_id')['problemtag_id'].apply(lambda x: '_'.join(map(str, x))).to_dict()
                
                df['skill_id'] = df['problem_id'].map(skill_map)

            elif self.dataset_type == 'csedm':
                # CSEDM: ProblemID, Requirement, If/Else, ... (Wide format)
                map_df = pd.read_csv(map_path)
                
                # 스킬 컬럼들 추출 (AssignmentID, ProblemID, Requirement 제외한 나머지)
                exclude_cols = ['AssignmentID', 'ProblemID', 'Requirement']
                skill_cols = [c for c in map_df.columns if c not in exclude_cols]
                
                # ProblemID를 인덱스로
                map_df = map_df.set_index('ProblemID')
                
                # 각 문제별로 값이 1.0인 스킬 이름 추출
                problem_to_skills = {}
                for pid, row in map_df.iterrows():
                    skills = [col for col in skill_cols if row[col] == 1.0]
                    if not skills:
                        skills = ['unknown'] # 스킬 정보가 없는 경우
                    problem_to_skills[pid] = '_'.join(skills)
                
                df['skill_id'] = df['problem_id'].map(problem_to_skills)

        # 스킬 정보 없는 행 제거
        df = df.dropna(subset=['skill_id'])

        # 최소 상호작용 수 필터링
        user_counts = df['user_id'].value_counts()
        valid_users = user_counts[user_counts >= self.min_inter_num].index
        df = df[df['user_id'].isin(valid_users)]
        
        print(f"Processed records: {len(df)}")
        
        # 저장
        self.processed_path = os.path.join(self.data_folder, 'processed_data.csv')
        df.to_csv(self.processed_path, index=False)


    def pro_skill_graph(self):
        df = pd.read_csv(self.processed_path)
        
        problems = df['problem_id'].unique()
        # 스킬은 'A_B_C' 형태의 문자열로 저장되어 있으므로 분리해서 유니크 스킬 추출
        unique_skills = set()
        for s_str in df['skill_id'].unique():
            for s in str(s_str).split('_'):
                unique_skills.add(s)
        
        # ID Mapping
        self.pro_id_dict = {pid: i for i, pid in enumerate(problems)}
        self.skill_id_dict = {sid: i for i, sid in enumerate(sorted(unique_skills))}
        
        print(f"Problems: {len(problems)}, Skills: {len(unique_skills)}")

        pro_feat = []
        pro_skill_adj = []
        
        # 문제별 통계 (Features)
        # response_time 등이 없으면 기본값 사용
        has_time = 'response_time' in df.columns
        
        pro_stats = df.groupby('problem_id').agg({
            'correct': 'mean',
            'skill_id': 'first' # 스킬 구성은 문제마다 동일하므로 첫번째 값 사용
        })

        if has_time:
            time_stats = df.groupby('problem_id')['response_time'].mean()

        for pid in problems:
            # Feature: [Time(or 0), 1.0, Accuracy]
            acc = pro_stats.loc[pid, 'correct']
            tm = time_stats.loc[pid] if has_time else 0.0
            
            pro_feat.append([tm, 1.0, acc])
            
            # Graph
            p_idx = self.pro_id_dict[pid]
            s_str = pro_stats.loc[pid, 'skill_id']
            for s in str(s_str).split('_'):
                if s in self.skill_id_dict:
                    s_idx = self.skill_id_dict[s]
                    pro_skill_adj.append([p_idx, s_idx, 1])

        # Normalize Time
        pro_feat = np.array(pro_feat).astype(np.float32)
        if has_time and np.max(pro_feat[:,0]) > np.min(pro_feat[:,0]):
             pro_feat[:,0] = (pro_feat[:,0] - np.min(pro_feat[:,0])) / (np.max(pro_feat[:,0]) - np.min(pro_feat[:,0]))

        # Save Sparse Matrix
        pro_skill_adj = np.array(pro_skill_adj).astype(np.int32)
        pro_num = len(problems)
        skill_num = len(unique_skills)
        
        pro_skill_sparse = sparse.coo_matrix(
            (pro_skill_adj[:, 2].astype(np.float32), (pro_skill_adj[:, 0], pro_skill_adj[:, 1])),
            shape=(pro_num, skill_num)
        )

        sparse.save_npz(os.path.join(self.data_folder, 'pro_skill_sparse.npz'), pro_skill_sparse)
        np.savez(os.path.join(self.data_folder, 'pro_feat.npz'), pro_feat=pro_feat)
        
        # Save Dictionaries
        with open(os.path.join(self.data_folder, 'pro_id_dict.txt'), 'w') as f: f.write(str(self.pro_id_dict))
        with open(os.path.join(self.data_folder, 'skill_id_dict.txt'), 'w') as f: f.write(str(self.skill_id_dict))


    def generate_user_sequence(self, seq_file='data.txt'):
        df = pd.read_csv(self.processed_path)
        df['p_idx'] = df['problem_id'].map(self.pro_id_dict)
        # 스킬 시퀀스는 '주 스킬' 하나만 쓰거나, 임베딩 단계에서 처리해야 함.
        # 여기서는 편의상 첫 번째 스킬 ID를 사용 (DKT 입력용)
        # PEBG는 그래프를 쓰므로 상관없으나 DKT는 시퀀스가 필요함.
        df['s_idx'] = df['skill_id'].apply(lambda x: self.skill_id_dict[str(x).split('_')[0]])
        
        user_groups = df.groupby('user_id')
        data_to_write = []
        
        for uid, group in user_groups:
            skills = group['s_idx'].tolist()
            probs = group['p_idx'].tolist()
            ans = group['correct'].tolist()
            data_to_write.append([[len(group)], skills, probs, ans])
            
        with open(os.path.join(self.data_folder, seq_file), 'w') as f:
            for record in data_to_write:
                for line in record:
                    f.write(str(line) + '\n')

    def read_user_sequence(self, filename='data.txt', max_len=200, min_len=3):
        with open(os.path.join(self.data_folder, filename), 'r') as f:
            lines = f.readlines()
        
        y, skill, problem, real_len = [], [], [], []
        index = 0
        while index < len(lines):
            try:
                num = eval(lines[index])[0]
                tmp_skills = eval(lines[index+1])[:max_len]
                tmp_pro = eval(lines[index+2])[:max_len]
                tmp_ans = eval(lines[index+3])[:max_len]
            except:
                index+=4; continue

            # 1-based index for padding (0 is padding)
            tmp_skills = [s+1 for s in tmp_skills]
            tmp_pro = [p+1 for p in tmp_pro]
            
            if num >= min_len:
                seq_len = len(tmp_skills)
                pad = max_len - seq_len
                y.append(tmp_ans + [-1]*pad)
                skill.append(tmp_skills + [0]*pad)
                problem.append(tmp_pro + [0]*pad)
                real_len.append(seq_len)
            
            index += 4

        # Save Final .npz
        save_path = os.path.join(self.data_folder, f"{os.path.basename(self.data_folder)}.npz")
        np.savez(save_path, 
                 y=np.array(y), skill=np.array(skill), problem=np.array(problem), 
                 real_len=np.array(real_len), 
                 skill_num=len(self.skill_id_dict), problem_num=len(self.pro_id_dict))
        print(f"Saved: {save_path}")

if __name__ == '__main__':
    # ================= SETTINGS =================
    DATASET_TYPE = 'bepkt' 
    MAPPING_FILE = 'problem_tags_remapped_bepkt.csv'
    INTERACTION_FILE = 'interactions_bepkt.csv' # (준비된 CSV 파일명)
    
    # DATASET_TYPE = 'csedm'
    # MAPPING_FILE = 'csedm_problem_concept.csv'
    # INTERACTION_FILE = 'interactions_csedm.csv' # (준비된 CSV 파일명)
    
    DATA_FOLDER = f'./CSEDM/PEBG/{DATASET_TYPE}_data'
    # ============================================

    dp = DataProcess(DATA_FOLDER, dataset_type=DATASET_TYPE)
    
    # 1. Process Raw Data
    dp.process_csv(INTERACTION_FILE, MAPPING_FILE)
    
    # 2. Build Graphs
    dp.pro_skill_graph()
    
    # 3. Gen Sequences
    dp.generate_user_sequence()
    
    # 4. Final Format
    dp.read_user_sequence()