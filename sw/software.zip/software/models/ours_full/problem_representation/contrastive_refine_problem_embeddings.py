#!/usr/bin/env python3
import argparse
import ast
import csv
import json
import os
import random

import numpy as np
import torch
import torch.nn.functional as F


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def load_pro_id_dict(path):
    with open(path, "r", encoding="utf-8") as f:
        text = f.read().strip()
    data = ast.literal_eval(text)
    return {str(k): int(v) for k, v in data.items()}


def load_problem_key_map(problem_text_csv):
    mapping = {}
    with open(problem_text_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = (row.get("problem_key") or "").strip()
            pid = (row.get("problem_id") or "").strip()
            if key and pid:
                mapping[key] = pid
    return mapping


def load_micro_groups(
    micro_edges_csv,
    problem_key_map,
    raw_to_idx,
    micro_problem_id_col,
    micro_problem_id_is_raw,
):
    groups = {}
    with open(micro_edges_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pid_value = (row.get(micro_problem_id_col) or "").strip()
            if not pid_value:
                continue
            if micro_problem_id_is_raw:
                pid_raw = pid_value
            else:
                pid_raw = problem_key_map.get(pid_value)
                if not pid_raw:
                    continue
            pidx = raw_to_idx.get(pid_raw)
            if pidx is None:
                continue
            try:
                mid = int(row.get("micro_id"))
            except (TypeError, ValueError):
                continue
            groups.setdefault(mid, set()).add(pidx)
    # Keep only groups with >=2 problems
    return {mid: sorted(list(pids)) for mid, pids in groups.items() if len(pids) >= 2}


def build_pairs(groups):
    pairs = []
    for pids in groups.values():
        for i in range(len(pids)):
            for j in range(len(pids)):
                if i == j:
                    continue
                pairs.append((pids[i], pids[j]))
    return pairs


def load_weighted_pairs(
    pair_csv,
    problem_key_map,
    raw_to_idx,
    problem_id_col_i,
    problem_id_col_j,
    problem_id_is_raw,
    weight_col,
):
    pairs = []
    weights = []
    with open(pair_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pid_i = (row.get(problem_id_col_i) or "").strip()
            pid_j = (row.get(problem_id_col_j) or "").strip()
            if not pid_i or not pid_j:
                continue
            if not problem_id_is_raw:
                pid_i = problem_key_map.get(pid_i)
                pid_j = problem_key_map.get(pid_j)
            if not pid_i or not pid_j:
                continue
            idx_i = raw_to_idx.get(pid_i)
            idx_j = raw_to_idx.get(pid_j)
            if idx_i is None or idx_j is None or idx_i == idx_j:
                continue
            w = row.get(weight_col)
            try:
                wv = float(w) if w is not None else 1.0
            except ValueError:
                wv = 1.0
            if wv <= 0:
                continue
            pairs.append((idx_i, idx_j))
            weights.append(wv)
    return pairs, weights


def load_hard_neg_pairs(
    hard_neg_csv,
    problem_key_map,
    raw_to_idx,
    problem_id_col_i,
    problem_id_col_j,
    problem_id_is_raw,
):
    neg_map = {}
    with open(hard_neg_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pid_i = (row.get(problem_id_col_i) or "").strip()
            pid_j = (row.get(problem_id_col_j) or "").strip()
            if not pid_i or not pid_j:
                continue
            if not problem_id_is_raw:
                pid_i = problem_key_map.get(pid_i)
                pid_j = problem_key_map.get(pid_j)
            if not pid_i or not pid_j:
                continue
            idx_i = raw_to_idx.get(pid_i)
            idx_j = raw_to_idx.get(pid_j)
            if idx_i is None or idx_j is None:
                continue
            neg_map.setdefault(idx_i, set()).add(idx_j)
            neg_map.setdefault(idx_j, set()).add(idx_i)
    # convert to lists for sampling
    return {k: sorted(v) for k, v in neg_map.items()}


def load_problem_stage_targets(
    problem_stage_csv,
    problem_key_map,
    raw_to_idx,
    problem_id_col,
    problem_id_is_raw,
    target_col,
):
    stage_targets = {}
    with open(problem_stage_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pid = (row.get(problem_id_col) or "").strip()
            if not pid:
                continue
            if not problem_id_is_raw:
                pid = problem_key_map.get(pid)
            if not pid:
                continue
            idx = raw_to_idx.get(pid)
            if idx is None:
                continue
            try:
                target = float(row.get(target_col))
            except (TypeError, ValueError):
                continue
            stage_targets[idx] = target
    return stage_targets


def sample_stage_rank_pairs(stage_items, sample_count, min_gap):
    if sample_count <= 0 or len(stage_items) < 2:
        return []
    pairs = []
    max_tries = max(sample_count * 20, 100)
    tries = 0
    while len(pairs) < sample_count and tries < max_tries:
        idx_a, target_a = random.choice(stage_items)
        idx_b, target_b = random.choice(stage_items)
        tries += 1
        if idx_a == idx_b or abs(target_a - target_b) < min_gap:
            continue
        if target_a < target_b:
            pairs.append((idx_a, idx_b))
        else:
            pairs.append((idx_b, idx_a))
    return pairs


def load_problem_concept_memberships(
    problem_concepts_csv,
    problem_key_map,
    raw_to_idx,
    problem_id_col,
    problem_id_is_raw,
    concept_col,
    weight_col,
):
    concept_members = {}
    with open(problem_concepts_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pid = (row.get(problem_id_col) or "").strip()
            concept = (row.get(concept_col) or "").strip()
            if not pid or not concept:
                continue
            if not problem_id_is_raw:
                pid = problem_key_map.get(pid)
            if not pid:
                continue
            idx = raw_to_idx.get(pid)
            if idx is None:
                continue
            try:
                weight = float(row.get(weight_col))
            except (TypeError, ValueError):
                continue
            if weight <= 0:
                continue
            concept_members.setdefault(concept, []).append((idx, weight))
    return concept_members


def load_concept_prereq_edges(
    prereq_csv,
    source_col,
    target_col,
    weight_col,
):
    edges = []
    with open(prereq_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            source = (row.get(source_col) or "").strip()
            target = (row.get(target_col) or "").strip()
            if not source or not target or source == target:
                continue
            try:
                weight = float(row.get(weight_col))
            except (TypeError, ValueError):
                continue
            if weight <= 0:
                continue
            edges.append((source, target, weight))
    return edges


def main():
    parser = argparse.ArgumentParser(
        description="Refine problem embeddings with contrastive loss over micro-concept pairs."
    )
    parser.add_argument("--base-pt", required=True)
    parser.add_argument("--micro-edges", default=None)
    parser.add_argument("--micro-problem-id-col", default="problem_id")
    parser.add_argument(
        "--micro-problem-id-is-raw",
        action="store_true",
        help="Treat micro edge problem_id as raw problem_id (skip problem_key mapping).",
    )
    parser.add_argument("--problem-text-csv", required=True)
    parser.add_argument("--pro-id-dict", required=True)
    parser.add_argument("--out-pt", required=True)
    parser.add_argument("--hard-neg-edges", default=None, help="CSV with hard-negative pairs")
    parser.add_argument("--hard-neg-problem-id-col-i", default="problem_i")
    parser.add_argument("--hard-neg-problem-id-col-j", default="problem_j")
    parser.add_argument(
        "--hard-neg-problem-id-is-raw",
        action="store_true",
        help="Treat hard-negative problem_id columns as raw problem_id.",
    )
    parser.add_argument("--pair-csv", default=None, help="Optional pre-built (weighted) contrastive pair csv")
    parser.add_argument("--pair-problem-id-col-i", default="problem_i")
    parser.add_argument("--pair-problem-id-col-j", default="problem_j")
    parser.add_argument(
        "--pair-problem-id-is-raw",
        action="store_true",
        help="Treat pair csv problem ids as raw problem_id.",
    )
    parser.add_argument("--pair-weight-col", default="weight")
    parser.add_argument("--problem-stage-csv", default=None, help="Optional CSV with per-problem stage targets")
    parser.add_argument("--problem-stage-id-col", default="problem_id")
    parser.add_argument(
        "--problem-stage-id-is-raw",
        action="store_true",
        help="Treat problem stage CSV problem ids as raw problem_id.",
    )
    parser.add_argument("--problem-stage-target-col", default="mean_stage_by_support")
    parser.add_argument("--stage-loss-weight", type=float, default=0.0)
    parser.add_argument("--stage-ranking-weight", type=float, default=0.0)
    parser.add_argument("--stage-ranking-samples", type=int, default=256)
    parser.add_argument("--stage-ranking-margin", type=float, default=0.1)
    parser.add_argument("--stage-ranking-min-gap", type=float, default=0.25)
    parser.add_argument("--problem-concepts-csv", default=None)
    parser.add_argument("--problem-concepts-id-col", default="problem_id")
    parser.add_argument(
        "--problem-concepts-id-is-raw",
        action="store_true",
        help="Treat problem concepts CSV problem ids as raw problem_id.",
    )
    parser.add_argument("--problem-concepts-concept-col", default="canonical_norm")
    parser.add_argument("--problem-concepts-weight-col", default="support_count")
    parser.add_argument("--concept-prereq-csv", default=None)
    parser.add_argument("--concept-prereq-source-col", default="source_norm")
    parser.add_argument("--concept-prereq-target-col", default="target_norm")
    parser.add_argument("--concept-prereq-weight-col", default="weight")
    parser.add_argument("--concept-prereq-weight", type=float, default=0.0)
    parser.add_argument("--concept-prereq-samples", type=int, default=256)
    parser.add_argument("--concept-prereq-margin", type=float, default=0.1)
    parser.add_argument("--hard-neg-k", type=int, default=64, help="Sample up to K hard negatives per anchor")
    parser.add_argument(
        "--pair-loss-weight",
        type=float,
        default=1.0,
        help="Weight for the pairwise contrastive loss. Set to 0 to keep only auxiliary losses.",
    )
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--lr", type=float, default=0.05)
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    if not args.pair_csv and not args.micro_edges:
        raise SystemExit("Either --micro-edges or --pair-csv is required.")

    set_seed(args.seed)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        print("[warn] CUDA not available; fallback to CPU", flush=True)
        device = torch.device("cpu")
    else:
        device = torch.device(args.device)
    print(f"[info] device={device}", flush=True)
    use_stage_loss = args.stage_loss_weight > 0 or args.stage_ranking_weight > 0
    use_concept_prereq = args.concept_prereq_weight > 0
    use_order_head = use_stage_loss or use_concept_prereq
    if use_stage_loss and not args.problem_stage_csv:
        raise SystemExit("--problem-stage-csv is required when stage regularization is enabled.")
    if use_concept_prereq and (not args.problem_concepts_csv or not args.concept_prereq_csv):
        raise SystemExit(
            "--problem-concepts-csv and --concept-prereq-csv are required "
            "when concept prerequisite regularization is enabled."
        )

    raw_to_idx = load_pro_id_dict(args.pro_id_dict)
    problem_key_map = load_problem_key_map(args.problem_text_csv)
    if args.pair_csv:
        pairs, pair_weights = load_weighted_pairs(
            args.pair_csv,
            problem_key_map,
            raw_to_idx,
            args.pair_problem_id_col_i,
            args.pair_problem_id_col_j,
            args.pair_problem_id_is_raw,
            args.pair_weight_col,
        )
    else:
        groups = load_micro_groups(
            args.micro_edges,
            problem_key_map,
            raw_to_idx,
            args.micro_problem_id_col,
            args.micro_problem_id_is_raw,
        )
        pairs = build_pairs(groups)
        pair_weights = [1.0] * len(pairs)

    if not pairs:
        raise SystemExit("No contrastive pairs found (micro groups < 2).")

    hard_neg_map = None
    if args.hard_neg_edges:
        hard_neg_map = load_hard_neg_pairs(
            args.hard_neg_edges,
            problem_key_map,
            raw_to_idx,
            args.hard_neg_problem_id_col_i,
            args.hard_neg_problem_id_col_j,
            args.hard_neg_problem_id_is_raw,
        )

    concept_membership_lookup = {}
    concept_prereq_edges = []
    if use_concept_prereq:
        raw_concept_members = load_problem_concept_memberships(
            args.problem_concepts_csv,
            problem_key_map,
            raw_to_idx,
            args.problem_concepts_id_col,
            args.problem_concepts_id_is_raw,
            args.problem_concepts_concept_col,
            args.problem_concepts_weight_col,
        )
        raw_concept_edges = load_concept_prereq_edges(
            args.concept_prereq_csv,
            args.concept_prereq_source_col,
            args.concept_prereq_target_col,
            args.concept_prereq_weight_col,
        )
        for concept, members in raw_concept_members.items():
            idxs = torch.tensor([idx for idx, _ in members], dtype=torch.long, device=device)
            ws = torch.tensor([weight for _, weight in members], dtype=torch.float32, device=device)
            ws = ws / ws.sum().clamp_min(1e-6)
            concept_membership_lookup[concept] = (idxs, ws)
        for source, target, weight in raw_concept_edges:
            if source not in concept_membership_lookup or target not in concept_membership_lookup:
                continue
            concept_prereq_edges.append((source, target, weight))
        if not concept_prereq_edges:
            raise SystemExit("No usable concept prerequisite edges found.")
        print(
            f"[info] loaded concept prerequisite edges: {len(concept_prereq_edges)} "
            f"across {len(concept_membership_lookup)} concepts",
            flush=True,
        )

    base = torch.load(args.base_pt, map_location="cpu").float().to(device)
    emb = torch.nn.Parameter(base.clone())
    stage_head = None
    stage_items = []
    stage_target_lookup = {}
    if use_order_head:
        stage_head = torch.nn.Linear(base.size(1), 1).to(device)
    if use_stage_loss:
        stage_target_lookup = load_problem_stage_targets(
            args.problem_stage_csv,
            problem_key_map,
            raw_to_idx,
            args.problem_stage_id_col,
            args.problem_stage_id_is_raw,
            args.problem_stage_target_col,
        )
        if not stage_target_lookup:
            raise SystemExit("No usable stage targets found for stage regularization.")
        stage_items = sorted(stage_target_lookup.items())
        print(
            f"[info] loaded stage targets: {len(stage_items)} "
            f"(target_col={args.problem_stage_target_col})",
            flush=True,
        )
    params = [emb] if stage_head is None else [emb, *stage_head.parameters()]
    optimizer = torch.optim.Adam(params, lr=args.lr)

    n = emb.size(0)
    temp = float(args.temperature)

    for epoch in range(args.epochs):
        pair_data = list(zip(pairs, pair_weights))
        random.shuffle(pair_data)
        total_loss = 0.0
        count = 0
        for i in range(0, len(pair_data), args.batch_size):
            batch_data = pair_data[i : i + args.batch_size]
            batch = [item[0] for item in batch_data]
            batch_w = [item[1] for item in batch_data]
            anchors = torch.tensor([p[0] for p in batch], dtype=torch.long, device=device)
            positives = torch.tensor([p[1] for p in batch], dtype=torch.long, device=device)
            weights_t = torch.tensor(batch_w, dtype=torch.float32, device=device)

            norm_emb = F.normalize(emb, p=2, dim=1)
            if not hard_neg_map:
                logits = torch.matmul(norm_emb[anchors], norm_emb.t()) / temp
                loss_vec = F.cross_entropy(logits, positives, reduction="none")
                pair_loss = (loss_vec * weights_t).sum() / weights_t.sum().clamp_min(1e-6)
            else:
                # Hard-negative InfoNCE: per-anchor candidate set = [positive] + hard negatives
                losses = []
                ws = []
                for a_idx, p_idx, w_i in zip(anchors.tolist(), positives.tolist(), batch_w):
                    negs = hard_neg_map.get(a_idx, [])
                    if args.hard_neg_k and len(negs) > args.hard_neg_k:
                        negs = random.sample(negs, args.hard_neg_k)
                    # Remove accidental positive from negatives
                    negs = [n for n in negs if n != p_idx]
                    if not negs:
                        # fallback to full negatives if no hard negs for this anchor
                        logits = torch.matmul(norm_emb[a_idx], norm_emb.t()) / temp
                        tgt = torch.tensor([p_idx], dtype=torch.long, device=device)
                        loss_i = F.cross_entropy(logits.unsqueeze(0), tgt)
                    else:
                        cand = [p_idx] + negs
                        cand_t = torch.tensor(cand, dtype=torch.long, device=device)
                        logits = torch.matmul(norm_emb[a_idx], norm_emb[cand_t].t()) / temp
                        tgt = torch.tensor([0], dtype=torch.long, device=device)
                        loss_i = F.cross_entropy(logits.unsqueeze(0), tgt)
                    losses.append(loss_i)
                    ws.append(float(w_i))
                loss_vec = torch.stack(losses)
                w_t = torch.tensor(ws, dtype=torch.float32, device=device)
                pair_loss = (loss_vec * w_t).sum() / w_t.sum().clamp_min(1e-6)

            loss = float(args.pair_loss_weight) * pair_loss

            if stage_head is not None:
                stage_batch_indices = sorted(
                    {
                        idx
                        for idx in anchors.tolist() + positives.tolist()
                        if idx in stage_target_lookup
                    }
                )
                if stage_batch_indices:
                    stage_batch_t = torch.tensor(
                        stage_batch_indices, dtype=torch.long, device=device
                    )
                    stage_target_t = torch.tensor(
                        [stage_target_lookup[idx] for idx in stage_batch_indices],
                        dtype=torch.float32,
                        device=device,
                    )
                    stage_pred = stage_head(norm_emb[stage_batch_t]).squeeze(-1)
                    loss = loss + args.stage_loss_weight * F.mse_loss(stage_pred, stage_target_t)
                if args.stage_ranking_weight > 0:
                    rank_pairs = sample_stage_rank_pairs(
                        stage_items,
                        args.stage_ranking_samples,
                        args.stage_ranking_min_gap,
                    )
                    if rank_pairs:
                        low_t = torch.tensor(
                            [low for low, _ in rank_pairs], dtype=torch.long, device=device
                        )
                        high_t = torch.tensor(
                            [high for _, high in rank_pairs], dtype=torch.long, device=device
                        )
                        low_pred = stage_head(norm_emb[low_t]).squeeze(-1)
                        high_pred = stage_head(norm_emb[high_t]).squeeze(-1)
                        rank_gap = high_pred - low_pred
                        rank_loss = F.softplus(args.stage_ranking_margin - rank_gap).mean()
                        loss = loss + args.stage_ranking_weight * rank_loss
                if use_concept_prereq:
                    sampled_edges = concept_prereq_edges
                    if args.concept_prereq_samples and len(sampled_edges) > args.concept_prereq_samples:
                        sampled_edges = random.sample(sampled_edges, args.concept_prereq_samples)
                    centroid_score_cache = {}

                    def get_concept_score(concept_norm):
                        if concept_norm not in centroid_score_cache:
                            member_idx, member_w = concept_membership_lookup[concept_norm]
                            centroid = (norm_emb[member_idx] * member_w.unsqueeze(1)).sum(dim=0)
                            centroid = F.normalize(centroid.unsqueeze(0), p=2, dim=1)
                            centroid_score_cache[concept_norm] = stage_head(centroid).squeeze()
                        return centroid_score_cache[concept_norm]

                    prereq_losses = []
                    prereq_weights = []
                    for source, target, edge_weight in sampled_edges:
                        source_score = get_concept_score(source)
                        target_score = get_concept_score(target)
                        prereq_losses.append(
                            F.softplus(args.concept_prereq_margin - (target_score - source_score))
                        )
                        prereq_weights.append(float(edge_weight))
                    prereq_loss_vec = torch.stack(prereq_losses)
                    prereq_weight_t = torch.tensor(
                        prereq_weights, dtype=torch.float32, device=device
                    )
                    prereq_loss = (
                        prereq_loss_vec * prereq_weight_t
                    ).sum() / prereq_weight_t.sum().clamp_min(1e-6)
                    loss = loss + args.concept_prereq_weight * prereq_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += float(loss.item()) * len(batch)
            count += len(batch)
        if (epoch + 1) % 5 == 0 or epoch == 0:
            avg = total_loss / max(count, 1)
            print(f"[epoch {epoch + 1}] avg loss {avg:.4f}", flush=True)

    os.makedirs(os.path.dirname(args.out_pt) or ".", exist_ok=True)
    torch.save(emb.detach().cpu(), args.out_pt)


if __name__ == "__main__":
    main()
