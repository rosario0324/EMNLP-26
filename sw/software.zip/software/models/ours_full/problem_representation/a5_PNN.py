# 이 파일은 논문에서의 Product layer를 담당하는 부분임. 이를 PNN으로 구현함

import torch
import torch.nn as nn
import torch.nn.functional as F

class PNN(nn.Module):
    def __init__(self, embed_dim, hidden_dim, keep_prob=0.5):
        super(PNN, self).__init__()
        self.embed_dim = embed_dim
        self.hidden_dim = hidden_dim
        self.dropout_rate = 1 - keep_prob
        
        # Output layers
        # Input dim = embed_dim * num_inputs + num_pairs
        # But since num_inputs can vary, we define layers dynamically or assume fixed size.
        # In PEBG, num_inputs is always 3 (Pro, Skill, Diff).
        self.num_inputs = 3
        self.num_pairs = int(self.num_inputs * (self.num_inputs - 1) / 2)
        
        input_dim = (self.embed_dim * self.num_inputs) + self.num_pairs
        
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.dropout = nn.Dropout(self.dropout_rate)
        self.fc2 = nn.Linear(hidden_dim, 1)

    def forward(self, inputs):
        """
        inputs: list of tensors, each [batch_size, embed_dim]
        """
        # [batch_size, num_inputs, embed_dim]
        xw3d = torch.stack(inputs, dim=1)
        batch_size = xw3d.size(0)

        # 1. Linear Part: Concatenate all inputs
        # [batch_size, num_inputs * embed_dim]
        xw = torch.cat(inputs, dim=1)

        # 2. Product Part: Pairwise Inner Products
        # We need pairs (0,1), (0,2), (1,2) for 3 inputs
        pairs = []
        for i in range(self.num_inputs):
            for j in range(i + 1, self.num_inputs):
                # Inner product: (Batch, Emb) * (Batch, Emb) -> (Batch, 1) -> sum dim 1
                p = xw3d[:, i, :]
                q = xw3d[:, j, :]
                ip = torch.sum(p * q, dim=1, keepdim=True) # [batch, 1]
                pairs.append(ip)
        
        # [batch, num_pairs]
        ip_tensor = torch.cat(pairs, dim=1)

        # 3. Concatenate Linear + Product
        l = torch.cat([xw, ip_tensor], dim=1)

        # 4. Dense Layers
        h = F.relu(self.fc1(l))
        h = self.dropout(h)
        p = self.fc2(h).squeeze(-1) # [batch]
        
        return h, p