# 이 파일은 유사도를 뽑는 기능을 담당함. 이때 유사도는 문제-문제, 스킬-스킬간의 유사도를 뜻함
# 추후 CSEDM과 BePKT 데이터셋을 선택하여 처리할 수 있도록 수정됨

import sys
import os

# 현재 파일의 부모의 부모 디렉토리(즉, 프로젝트 루트인 kt_collenction)를 경로에 추가
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import numpy as np
from scipy import sparse

# ========== SETTINGS ==========
# data_folder = './CSEDM/PEBG/csedm_data'  
data_folder = './CSEDM/PEBG/bepkt_data'
# ==============================

pro_skill_coo = sparse.load_npz(os.path.join(data_folder, 'pro_skill_sparse.npz'))
[pro_num, skill_num] = pro_skill_coo.shape
print('problem number %d, skill number %d' % (pro_num, skill_num))

pro_skill_csc = pro_skill_coo.tocsc()
pro_skill_csr = pro_skill_coo.tocsr()

def extract_pro_pro_sim():
    pro_pro_adj = []
    for p in range(pro_num):
        tmp_skills = pro_skill_csr.getrow(p).indices
        if len(tmp_skills) == 0: continue
        similar_pros = pro_skill_csc[:, tmp_skills].indices
        zipped = zip([p] * similar_pros.shape[0], similar_pros)
        pro_pro_adj += list(zipped)

    pro_pro_adj = list(set(pro_pro_adj))
    if not pro_pro_adj:
        print("No pro-pro similarity found.")
        return
        
    pro_pro_adj = np.array(pro_pro_adj).astype(np.int32)
    data = np.ones(pro_pro_adj.shape[0]).astype(np.float32)
    pro_pro_sparse = sparse.coo_matrix((data, (pro_pro_adj[:, 0], pro_pro_adj[:, 1])), shape=(pro_num, pro_num))
    sparse.save_npz(os.path.join(data_folder, 'pro_pro_sparse.npz'), pro_pro_sparse)

def extract_skill_skill_sim():
    skill_skill_adj = []
    for s in range(skill_num):
        tmp_pros = pro_skill_csc.getcol(s).indices
        if len(tmp_pros) == 0: continue
        similar_skills = pro_skill_csr[tmp_pros, :].indices
        zipped = zip([s] * similar_skills.shape[0], similar_skills)
        skill_skill_adj += list(zipped)

    skill_skill_adj = list(set(skill_skill_adj))
    if not skill_skill_adj:
        print("No skill-skill similarity found.")
        return

    skill_skill_adj = np.array(skill_skill_adj).astype(np.int32)
    data = np.ones(skill_skill_adj.shape[0]).astype(np.float32)
    skill_skill_sparse = sparse.coo_matrix((data, (skill_skill_adj[:, 0], skill_skill_adj[:, 1])), shape=(skill_num, skill_num))
    sparse.save_npz(os.path.join(data_folder, 'skill_skill_sparse.npz'), skill_skill_sparse)

extract_pro_pro_sim()
extract_skill_skill_sim()