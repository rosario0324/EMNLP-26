# a1_data_preprocess.py에서 사용할 CSEDM 데이터셋을 준비하는 스크립트

import sys
import os

# 현재 파일의 부모의 부모 디렉토리(즉, 프로젝트 루트인 kt_collenction)를 경로에 추가
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import pandas as pd
import shutil

def prepare_csedm_dataset():
    # ================= 설정 =================
    # 사용자가 업로드한 원본 파일 이름
    RAW_INTERACTION_FILE = './CSEDM/S19_Release/Train/Data/MainTable.csv'
    RAW_MAPPING_FILE = './CSEDM/csedm_problem_concept.csv'
    
    # 데이터가 저장될 폴더 이름 (a1 코드와 맞춰야 함)
    OUTPUT_FOLDER = './CSEDM/PEBG/csedm_data'
    
    # 저장될 파일 이름
    OUTPUT_INTERACTION = 'interactions_csedm.csv'
    OUTPUT_MAPPING = 'mapping_csedm.csv'
    # =======================================

    # 0. 폴더 생성
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)
        print(f"[Info] '{OUTPUT_FOLDER}' 폴더를 생성했습니다.")

    # ---------------------------------------------------------
    # 1. Interaction 데이터 생성 (MainTable.csv -> interactions.csv)
    # ---------------------------------------------------------
    print(f"1. Processing {RAW_INTERACTION_FILE}...")
    try:
        df_main = pd.read_csv(RAW_INTERACTION_FILE)
        
        # (1) 채점 결과(Score)가 있는 행만 추출 (이벤트 타입이 Run.Program인 경우)
        df_filtered = df_main[df_main['Score'].notnull()].copy()
        
        # (2) 정오답(correct) 생성: Score가 1.0이면 정답(1), 아니면 오답(0)
        df_filtered['correct'] = (df_filtered['Score'] == 1.0).astype(int)
        
        # (3) 컬럼 이름 변경 (a1 코드와 호환되도록 user_id, problem_id로 변경)
        df_filtered = df_filtered.rename(columns={
            'SubjectID': 'user_id',
            'ProblemID': 'problem_id'
        })
        
        # (4) 시간 순서 정렬 (Order 기준)
        df_filtered = df_filtered.sort_values(by=['user_id', 'Order'])
        
        # (5) 문제 ID 정수형 변환
        df_filtered['problem_id'] = df_filtered['problem_id'].astype(int)
        
        # (6) 필요한 컬럼만 선택
        final_interaction = df_filtered[['user_id', 'problem_id', 'correct']]
        
        # (7) 저장
        save_path_int = os.path.join(OUTPUT_FOLDER, OUTPUT_INTERACTION)
        final_interaction.to_csv(save_path_int, index=False)
        
        print(f"   >> 완료! '{save_path_int}' 저장됨.")
        print(f"   >> 총 기록 수: {len(final_interaction)}행")
        print(f"   >> 유저 수: {final_interaction['user_id'].nunique()}명")

    except FileNotFoundError:
        print(f"[Error] '{RAW_INTERACTION_FILE}' 파일을 찾을 수 없습니다. 같은 폴더에 있는지 확인해주세요.")
        return
    except Exception as e:
        print(f"[Error] Interaction_csedm 처리 중 오류 발생: {e}")
        return

    # ---------------------------------------------------------
    # 2. Mapping 데이터 준비 (CSEDM...csv -> mapping.csv)
    # ---------------------------------------------------------
    print(f"\n2. Processing {RAW_MAPPING_FILE}...")
    try:
        # 매핑 파일은 a1 코드에서 직접 로직을 처리하도록 되어 있으므로,
        # 파일명을 간단하게 변경하여 csedm_data 폴더로 복사만 해둡니다.
        # (혹시 모를 인코딩 문제를 방지하기 위해 pandas로 읽었다가 다시 저장)
        
        df_map = pd.read_csv(RAW_MAPPING_FILE)
        
        # 저장
        save_path_map = os.path.join(OUTPUT_FOLDER, OUTPUT_MAPPING)
        df_map.to_csv(save_path_map, index=False)
        
        print(f"   >> 완료! '{save_path_map}' 저장됨.")
        print(f"   >> 문제-스킬 정보 수: {len(df_map)}행")

    except FileNotFoundError:
        print(f"[Error] '{RAW_MAPPING_FILE}' 파일을 찾을 수 없습니다.")
        return
    except Exception as e:
        print(f"[Error] Mapping_csedm 처리 중 오류 발생: {e}")
        return

    print("\n[Success] 모든 데이터 준비가 완료되었습니다.")
    print(f"이제 'a1_data_preprocess.py'를 실행할 때 다음 설정을 사용하세요:")
    print(f"DATA_FOLDER = '{OUTPUT_FOLDER}'")
    print(f"MAPPING_FILE = '{OUTPUT_MAPPING}'")
    print(f"INTERACTION_FILE = '{OUTPUT_INTERACTION}'")

if __name__ == "__main__":
    prepare_csedm_dataset()