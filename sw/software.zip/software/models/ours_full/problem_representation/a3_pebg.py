# CSEDM과 BePKT 데이터셋을 위한 PEBG 모델 학습 스크립트

"""
    bipartite graph node embedding --> item embedding, skill embedding
       (item is question.)

    plus: item difficutly features

    three different feature use PNN to fuse, and with the help of auxilary target
"""

import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from scipy import sparse
from a5_PNN import PNN

# ========== SETTINGS ==========
# data_folder = './CSEDM/PEBG/csedm_data'  
data_folder = './CSEDM/PEBG/bepkt_data'
epochs = 50
bs = 256
lr = 0.001
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# ==============================

def train_pebg():
    # Load Data
    print(f"Loading data from {data_folder}...")
    pro_skill_coo = sparse.load_npz(os.path.join(data_folder, 'pro_skill_sparse.npz'))
    skill_skill_coo = sparse.load_npz(os.path.join(data_folder, 'skill_skill_sparse.npz'))
    pro_pro_coo = sparse.load_npz(os.path.join(data_folder, 'pro_pro_sparse.npz'))

    pro_num, skill_num = pro_skill_coo.shape
    pro_feat = np.load(os.path.join(data_folder, 'pro_feat.npz'))['pro_feat']
    diff_feat_dim = pro_feat.shape[1] - 1

    # Dense Conversion for Training
    pro_skill_dense = torch.FloatTensor(pro_skill_coo.toarray()).to(device)
    pro_pro_dense = torch.FloatTensor(pro_pro_coo.toarray()).to(device)
    skill_skill_dense = torch.FloatTensor(skill_skill_coo.toarray()).to(device)
    
    # Prepare Problem Features
    # pro_feat: [diff_feat..., aux_target]
    diff_feat_tensor = torch.FloatTensor(pro_feat[:, :-1]).to(device)
    aux_target_tensor = torch.FloatTensor(pro_feat[:, -1]).to(device)
    all_pro_indices = torch.arange(pro_num).long().to(device)

    # Dataset & DataLoader
    dataset = TensorDataset(all_pro_indices, diff_feat_tensor, aux_target_tensor, pro_skill_dense, pro_pro_dense)
    loader = DataLoader(dataset, batch_size=bs, shuffle=True)

    # Model Definition
    class PEBG(nn.Module):
        def __init__(self, pro_num, skill_num, diff_dim, embed_dim=64, hidden_dim=128):
            super(PEBG, self).__init__()
            self.pro_emb = nn.Embedding(pro_num, embed_dim)
            self.skill_emb = nn.Embedding(skill_num, embed_dim)
            self.diff_proj = nn.Linear(diff_dim, embed_dim, bias=False) # Simple projection like matmul
            
            self.pnn = PNN(embed_dim, hidden_dim)
            
            # Init weights
            nn.init.normal_(self.pro_emb.weight, std=0.1)
            nn.init.normal_(self.skill_emb.weight, std=0.1)
            nn.init.normal_(self.diff_proj.weight, std=0.1)

        def forward(self, pro_idx, diff_feat, ps_target):
            # Embeddings
            p_emb = self.pro_emb(pro_idx)         # [B, Emb]
            d_emb = self.diff_proj(diff_feat)     # [B, Emb]
            
            # Skill Embedding Aggregation (Weighted Average by edges)
            # ps_target: [B, Skill_Num], skill_emb: [Skill_Num, Emb]
            # [B, Skill_Num] @ [Skill_Num, Emb] -> [B, Emb]
            s_emb_agg = torch.mm(ps_target, self.skill_emb.weight) 
            s_emb_agg = s_emb_agg / (ps_target.sum(dim=1, keepdim=True) + 1e-8)

            # PNN for Aux Task
            _, pred_aux = self.pnn([p_emb, s_emb_agg, d_emb])
            
            # Graph Reconstruction Logits
            # 1. Pro-Skill: p_emb @ skill_emb.T
            logits_ps = torch.mm(p_emb, self.skill_emb.weight.t())
            
            # 2. Pro-Pro: p_emb @ pro_emb.T
            # Note: Computing full NxN might be heavy, but original code did it.
            # Here we compute batch against ALL pros
            logits_pp = torch.mm(p_emb, self.pro_emb.weight.t())
            
            # 3. Skill-Skill: skill_emb @ skill_emb.T
            logits_ss = torch.mm(self.skill_emb.weight, self.skill_emb.weight.t())

            return pred_aux, logits_ps, logits_pp, logits_ss

    model = PEBG(pro_num, skill_num, diff_feat_dim).to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion_bce = nn.BCEWithLogitsLoss()
    criterion_mse = nn.MSELoss()

    # Training Loop
    print("Start Training PEBG...")
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        
        for batch in loader:
            b_pid, b_diff, b_aux, b_ps, b_pp = batch
            
            optimizer.zero_grad()
            
            pred_aux, l_ps, l_pp, l_ss = model(b_pid, b_diff, b_ps)
            
            # Losses
            loss_aux = criterion_mse(pred_aux, b_aux)
            
            # Graph Losses (Masking logic could be added here if needed, but original used full matrix)
            # l_ps: [B, S], b_ps: [B, S]
            loss_ps = criterion_bce(l_ps, b_ps)
            
            # l_pp: [B, P], b_pp: [B, P] - This is memory intensive if P is huge
            loss_pp = criterion_bce(l_pp, b_pp)
            
            # l_ss: [S, S], target is global constant per epoch
            loss_ss = criterion_bce(l_ss, skill_skill_dense)
            
            loss = loss_aux + loss_ps + loss_pp + loss_ss
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()

        print(f"Epoch {epoch+1}/{epochs}, Loss: {total_loss/len(loader):.4f}")

    # Save Embeddings
    model.eval()
    with torch.no_grad():
        # Compute final representation using PNN logic
        # We need to pass data in batches to avoid OOM
        final_repre_list = []
        # Create a loader just for ordered inference
        inf_dataset = TensorDataset(all_pro_indices, diff_feat_tensor, pro_skill_dense)
        inf_loader = DataLoader(inf_dataset, batch_size=bs, shuffle=False)
        
        for b_pid, b_diff, b_ps in inf_loader:
             p_emb = model.pro_emb(b_pid)
             d_emb = model.diff_proj(b_diff)
             s_emb_agg = torch.mm(b_ps, model.skill_emb.weight) / (b_ps.sum(1, keepdim=True) + 1e-8)
             
             final_emb, _ = model.pnn([p_emb, s_emb_agg, d_emb])
             final_repre_list.append(final_emb.cpu().numpy())
        
        pro_final_repre = np.concatenate(final_repre_list, axis=0)
        pro_repre = model.pro_emb.weight.cpu().numpy()
        skill_repre = model.skill_emb.weight.cpu().numpy()

    np.savez(os.path.join(data_folder, 'embedding_final.npz'), 
             pro_repre=pro_repre, skill_repre=skill_repre, pro_final_repre=pro_final_repre)
    print("Saved pretrained embeddings.")

if __name__ == '__main__':
    train_pebg()