#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


def norm_text(text: object) -> str:
    text = str(text or "").strip().lower()
    text = re.sub(r"^additional::", "", text)
    text = re.sub(r"^additional_", "", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def title_skill(text: str) -> str:
    keep_upper = {"and": "AND", "or": "OR"}
    words = []
    for word in text.replace("/", " / ").split():
        key = word.lower()
        if key in keep_upper:
            words.append(keep_upper[key])
        elif key == "stringbuilder":
            words.append("StringBuilder")
        elif key == "math.abs":
            words.append("Math.abs")
        elif key == "indexof":
            words.append("indexOf")
        else:
            words.append(word[:1].upper() + word[1:])
    return " ".join(words)


CURATED_SKILLS: dict[str, dict[str, object]] = {
    "declare_local_variable": {
        "display": "Declare local variable",
        "stage": 1,
        "parent_hint": "variable_use",
    },
    "ensure_all_paths_return_value": {
        "display": "Ensure all paths return value",
        "stage": 2,
        "parent_hint": "DefFunction",
    },
    "return_boolean_expression_directly": {
        "display": "Return boolean expression directly",
        "stage": 2,
        "parent_hint": "LogicBoolean",
    },
    "avoid_premature_return_in_loop": {
        "display": "Avoid premature return in loop",
        "stage": 2,
        "parent_hint": "For",
    },
    "set_loop_bounds": {
        "display": "Set loop bounds",
        "stage": 2,
        "parent_hint": "For",
    },
    "set_lookahead_loop_bounds": {
        "display": "Set lookahead loop bounds",
        "stage": 3,
        "parent_hint": "For",
    },
    "initialize_accumulator_before_loop": {
        "display": "Initialize accumulator before loop",
        "stage": 2,
        "parent_hint": "For",
    },
    "update_accumulator_in_loop": {
        "display": "Update accumulator in loop",
        "stage": 2,
        "parent_hint": "For",
    },
    "return_accumulator_after_loop": {
        "display": "Return accumulator after loop",
        "stage": 2,
        "parent_hint": "For",
    },
    "combine_range_bounds_with_and": {
        "display": "Combine range bounds with AND",
        "stage": 2,
        "parent_hint": "LogicAndNotOr",
    },
    "combine_alternative_conditions_with_or": {
        "display": "Combine alternative conditions with OR",
        "stage": 2,
        "parent_hint": "LogicAndNotOr",
    },
    "distinguish_assignment_from_equality": {
        "display": "Distinguish assignment from equality",
        "stage": 1,
        "parent_hint": "LogicCompareNum",
    },
    "avoid_chained_equality_comparisons": {
        "display": "Avoid chained equality comparisons",
        "stage": 1,
        "parent_hint": "LogicCompareNum",
    },
    "group_boolean_expressions_with_parentheses": {
        "display": "Group boolean expressions with parentheses",
        "stage": 2,
        "parent_hint": "LogicAndNotOr",
    },
    "use_inclusive_range_comparisons": {
        "display": "Use inclusive range comparisons",
        "stage": 1,
        "parent_hint": "LogicCompareNum",
    },
    "use_not_in_conditions": {
        "display": "Use not in conditions",
        "stage": 2,
        "parent_hint": "LogicAndNotOr",
    },
    "order_mutually_exclusive_conditions": {
        "display": "Order mutually exclusive conditions",
        "stage": 2,
        "parent_hint": "If/Else",
    },
    "compare_strings_with_equals": {
        "display": "Compare strings with equals",
        "stage": 2,
        "parent_hint": "StringEqual",
    },
    "compare_chars_with_single_quotes": {
        "display": "Compare chars with single quotes",
        "stage": 2,
        "parent_hint": "CharEqual",
    },
    "use_stringbuilder_for_output": {
        "display": "Use StringBuilder for output",
        "stage": 2,
        "parent_hint": "StringConcat",
    },
    "build_output_incrementally": {
        "display": "Build output incrementally",
        "stage": 2,
        "parent_hint": "StringConcat",
    },
    "search_substring_with_indexof": {
        "display": "Search substring with indexOf",
        "stage": 2,
        "parent_hint": "StringIndex",
    },
    "scan_substring_windows": {
        "display": "Scan substring windows",
        "stage": 3,
        "parent_hint": "StringIndex",
    },
    "use_substring_start_end_indices": {
        "display": "Use substring start/end indices",
        "stage": 3,
        "parent_hint": "StringIndex",
    },
    "compute_substring_start_index": {
        "display": "Compute substring start index",
        "stage": 3,
        "parent_hint": "StringIndex",
    },
    "guard_substring_with_length_check": {
        "display": "Guard substring with length check",
        "stage": 3,
        "parent_hint": "StringIndex",
    },
    "reverse_string_traversal": {
        "display": "Reverse string traversal",
        "stage": 2,
        "parent_hint": "StringIndex",
    },
    "use_array_length_field": {
        "display": "Use array length field",
        "stage": 2,
        "parent_hint": "ArrayIndex",
    },
    "guard_array_access_with_bounds": {
        "display": "Guard array access with bounds",
        "stage": 2,
        "parent_hint": "ArrayIndex",
    },
    "allocate_array_with_computed_length": {
        "display": "Allocate array with computed length",
        "stage": 2,
        "parent_hint": "ArrayIndex",
    },
    "return_newly_created_array": {
        "display": "Return newly created array",
        "stage": 2,
        "parent_hint": "ArrayIndex",
    },
    "update_array_element_in_place": {
        "display": "Update array element in place",
        "stage": 2,
        "parent_hint": "ArrayIndex",
    },
    "use_separate_read_write_indices": {
        "display": "Use separate read/write indices",
        "stage": 3,
        "parent_hint": "ArrayIndex",
    },
    "map_loop_value_to_array_index": {
        "display": "Map loop value to array index",
        "stage": 2,
        "parent_hint": "ArrayIndex",
    },
    "swap_array_elements_in_place": {
        "display": "Swap array elements in place",
        "stage": 3,
        "parent_hint": "ArrayIndex",
    },
    "sort_three_values_by_swapping": {
        "display": "Sort three values by swapping",
        "stage": 3,
        "parent_hint": "LogicCompareNum",
    },
    "compare_adjacent_elements": {
        "display": "Compare adjacent elements",
        "stage": 2,
        "parent_hint": "ArrayIndex",
    },
    "compare_all_pairs": {
        "display": "Compare all pairs",
        "stage": 3,
        "parent_hint": "NestedFor",
    },
    "track_boolean_state_flag": {
        "display": "Track boolean state flag",
        "stage": 2,
        "parent_hint": "LogicBoolean",
    },
    "maintain_two_running_sums": {
        "display": "Maintain two running sums",
        "stage": 3,
        "parent_hint": "For",
    },
    "track_min_max_while_summing": {
        "display": "Track min/max while summing",
        "stage": 3,
        "parent_hint": "For",
    },
    "skip_next_element_via_index": {
        "display": "Skip next element via index",
        "stage": 3,
        "parent_hint": "ArrayIndex",
    },
    "use_math_abs_for_difference": {
        "display": "Use Math.abs for difference",
        "stage": 1,
        "parent_hint": "Math+-*/",
    },
    "compute_ones_digit_with_modulo": {
        "display": "Compute ones digit with modulo",
        "stage": 1,
        "parent_hint": "Math%",
    },
    "cap_quotient_by_available_count": {
        "display": "Cap quotient by available count",
        "stage": 1,
        "parent_hint": "Math+-*/",
    },
    "update_remainder_after_allocation": {
        "display": "Update remainder after allocation",
        "stage": 2,
        "parent_hint": "Math%",
    },
    "convert_number_to_string": {
        "display": "Convert number to string",
        "stage": 1,
        "parent_hint": "StringFormat",
    },
    "use_helper_return_values": {
        "display": "Use helper return values",
        "stage": 4,
        "parent_hint": "DefFunction",
    },
    "handle_empty_input_safely": {
        "display": "Handle empty input safely",
        "stage": 2,
        "parent_hint": "ArrayIndex",
    },
}


def reject_reason(norm: str) -> str | None:
    if not norm:
        return "empty"
    if len(norm.split()) < 2:
        return "too_short"
    generic = {
        "use correct logic",
        "write correct logic",
        "write correct code",
        "handle edge cases",
        "implement problem logic",
        "use correct condition",
        "use correct syntax",
        "fix syntax errors",
        "avoid syntax errors",
        "use correct operator",
        "use correct method",
        "return correct value",
        "return expected value",
        "return correct answer",
        "return computed value",
        "return calculated value",
        "return result value",
        "compute correct result",
        "produce correct output",
    }
    if norm in generic:
        return "too_generic"
    if "problem specific" in norm or "codingbat" in norm:
        return "problem_specific"
    if "method name" in norm or "function name" in norm:
        return "interface_or_method_name"
    if "parameter name" in norm or "parameter names" in norm:
        return "interface_or_method_name"
    if "function signature" in norm or "method signature" in norm:
        return "interface_or_method_name"
    if "correct return type" in norm or "return type" in norm or "boolean return type" in norm:
        return "interface_or_type"
    if "import" in norm:
        return "syntax_or_library"
    if "semicolon" in norm or "brace" in norm or "parenthesis syntax" in norm:
        return "syntax_typo"
    if "variable name" in norm or "variable names" in norm:
        return "syntax_or_naming"
    if "all equal case" in norm:
        return "one_problem_case"
    if "birthday" in norm or "cigar" in norm or "squirrel" in norm:
        return "story_specific"
    return None


def map_skill(norm: str) -> tuple[str | None, str | None]:
    rej = reject_reason(norm)
    if rej is not None:
        return None, rej
    words = f" {norm} "

    if "declare" in norm and ("variable" in norm or "local" in norm):
        return "declare_local_variable", None
    if "initialize local variable" in norm or "declare and initialize" in norm:
        return "declare_local_variable", None

    if "all paths" in norm and "return" in norm:
        return "ensure_all_paths_return_value", None
    if "every path" in norm and "return" in norm:
        return "ensure_all_paths_return_value", None
    if "return on all paths" in norm:
        return "ensure_all_paths_return_value", None
    if "return value from method" in norm:
        return "ensure_all_paths_return_value", None

    if "boolean expression" in norm and "return" in norm:
        return "return_boolean_expression_directly", None
    if "return boolean expression" in norm or "return boolean directly" in norm:
        return "return_boolean_expression_directly", None
    if "return boolean result" in norm:
        return "return_boolean_expression_directly", None

    if "premature return" in norm or "early return" in norm:
        return "avoid_premature_return_in_loop", None
    if "return after loop" in norm or "return after full scan" in norm:
        return "avoid_premature_return_in_loop", None
    if "place return after loop" in norm or "return outside loop" in norm:
        return "avoid_premature_return_in_loop", None

    if "lookahead" in norm and ("bound" in norm or "loop" in norm):
        return "set_lookahead_loop_bounds", None
    if "length minus one" in norm or "i 1" in norm or "adjacent pair" in norm:
        return "set_lookahead_loop_bounds", None

    if "loop bound" in norm or "loop upper bound" in norm or "iteration bound" in norm:
        return "set_loop_bounds", None
    if "iterate correct range" in norm or "range iteration" in norm:
        return "set_loop_bounds", None

    if "initialize accumulator" in norm or "accumulator before" in norm:
        return "initialize_accumulator_before_loop", None
    if "initialize string accumulator" in norm or "initialize return variable" in norm:
        return "initialize_accumulator_before_loop", None
    if "update accumulator" in norm or "accumulate" in norm or "increment count" in norm:
        return "update_accumulator_in_loop", None
    if "return accumulator" in norm:
        return "return_accumulator_after_loop", None

    if "range" in norm and ("and" in norm or "both bounds" in norm):
        return "combine_range_bounds_with_and", None
    if "bounds with and" in norm or "comparisons with and" in norm:
        return "combine_range_bounds_with_and", None
    if "combine conditions with and" in norm and ("range" in norm or "bound" in norm):
        return "combine_range_bounds_with_and", None
    if "and for range" in norm or "valid range check" in norm:
        return "combine_range_bounds_with_and", None
    if "combine conditions with or" in norm or "alternative conditions" in norm:
        return "combine_alternative_conditions_with_or", None

    if "chained equality" in norm or "chained comparisons" in norm:
        return "avoid_chained_equality_comparisons", None
    if "assignment" in norm and ("equality" in norm or "condition" in norm):
        return "distinguish_assignment_from_equality", None
    if "equality operator" in norm or "equality not assignment" in norm:
        return "distinguish_assignment_from_equality", None
    if "compare boolean without assignment" in norm:
        return "distinguish_assignment_from_equality", None

    if "parentheses" in norm and ("boolean" in norm or "condition" in norm or "logic" in norm):
        return "group_boolean_expressions_with_parentheses", None
    if "group boolean" in norm or "negate compound condition" in norm:
        return "group_boolean_expressions_with_parentheses", None

    if "inclusive" in norm and ("range" in norm or "bound" in norm or "comparison" in norm):
        return "use_inclusive_range_comparisons", None
    if "not in condition" in norm or norm == "use not in conditions":
        return "use_not_in_conditions", None
    if "mutually exclusive" in norm or "overlapping conditions" in norm:
        return "order_mutually_exclusive_conditions", None
    if "order conditional" in norm or "order conditions" in norm:
        return "order_mutually_exclusive_conditions", None
    if "else if" in norm or "specific condition first" in norm or "overriding condition" in norm:
        return "order_mutually_exclusive_conditions", None

    if "string" in norm and (" equals" in words or "equal" in norm):
        return "compare_strings_with_equals", None
    if "equals for strings" in norm:
        return "compare_strings_with_equals", None
    if "char" in norm and ("single quote" in norm or "compare" in norm):
        return "compare_chars_with_single_quotes", None

    if "stringbuilder" in norm:
        return "use_stringbuilder_for_output", None
    if "build output incrementally" in norm or "append output" in norm:
        return "build_output_incrementally", None
    if "indexof" in norm or "find substring" in norm or "search substring" in norm:
        return "search_substring_with_indexof", None
    if "scan all substring" in norm or "substring positions" in norm or "substring window" in norm:
        return "scan_substring_windows", None
    if "substring" in norm and (
        "length check" in norm or "bounds" in norm or "out of bounds" in norm or "safe" in norm
    ):
        return "guard_substring_with_length_check", None
    if "substring start end" in norm or "extract substring" in norm:
        return "use_substring_start_end_indices", None
    if "substring end index" in norm or "start end indices" in norm:
        return "use_substring_start_end_indices", None
    if "compute substring start" in norm or "compute suffix start" in norm:
        return "compute_substring_start_index", None
    if "compute end start index" in norm or "substring start index" in norm:
        return "compute_substring_start_index", None
    if "reverse string" in norm or "scan string from end" in norm or "right to left" in norm:
        return "reverse_string_traversal", None

    if "array length" in norm or "length property" in norm or "length field" in norm:
        return "use_array_length_field", None
    if "array" in norm and ("bounds" in norm or "out of bounds" in norm or "index bounds" in norm):
        return "guard_array_access_with_bounds", None
    if "guard index bounds" in norm:
        return "guard_array_access_with_bounds", None
    if "empty array" in norm or "empty string" in norm or "empty input" in norm:
        return "handle_empty_input_safely", None
    if "allocate array" in norm and ("length" in norm or "computed" in norm):
        return "allocate_array_with_computed_length", None
    if "array by length" in norm:
        return "allocate_array_with_computed_length", None
    if "return newly created array" in norm or "return new array" in norm:
        return "return_newly_created_array", None
    if "return computed array" in norm or "return constructed array" in norm or "return modified array" in norm:
        return "return_newly_created_array", None
    if "update array element" in norm or "assign to array element" in norm:
        return "update_array_element_in_place", None
    if "separate read" in norm and "write" in norm:
        return "use_separate_read_write_indices", None
    if "write index" in norm:
        return "use_separate_read_write_indices", None
    if "map loop value" in norm or "loop value to array index" in norm:
        return "map_loop_value_to_array_index", None
    if "swap array" in norm or "temporary variable for swap" in norm:
        return "swap_array_elements_in_place", None
    if "sort three values" in norm:
        return "sort_three_values_by_swapping", None
    if "compare adjacent" in norm or "check both neighbors" in norm:
        return "compare_adjacent_elements", None
    if "compare all pairs" in norm:
        return "compare_all_pairs", None

    if "boolean state" in norm or "state flag" in norm or "boolean flag" in norm:
        return "track_boolean_state_flag", None
    if "track clump state" in norm or "branch on boolean flag" in norm:
        return "track_boolean_state_flag", None
    if "two running sums" in norm or "shifting split" in norm:
        return "maintain_two_running_sums", None
    if "min max" in norm or "min and max" in norm or "track min" in norm or "track max" in norm:
        return "track_min_max_while_summing", None
    if "skip next element" in norm or "advance index by word length" in norm:
        return "skip_next_element_via_index", None

    if "math abs" in norm or "absolute difference" in norm:
        return "use_math_abs_for_difference", None
    if "ones digit" in norm and ("modulo" in norm or "mod" in norm):
        return "compute_ones_digit_with_modulo", None
    if "capped quotient" in norm or "cap quotient" in norm or "cap division" in norm:
        return "cap_quotient_by_available_count", None
    if "usable big" in norm or "available count" in norm:
        return "cap_quotient_by_available_count", None
    if "update remainder" in norm or "remaining goal" in norm or "remaining amount" in norm:
        return "update_remainder_after_allocation", None
    if "convert int to string" in norm or "number to string" in norm:
        return "convert_number_to_string", None
    if "helper return" in norm or "use helper return value" in norm:
        return "use_helper_return_values", None

    return None, "unmapped_or_too_specific"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_csv(path: Path, rows: list[dict[str, object]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def parse_problem_list(text: str) -> set[int]:
    out = set()
    for part in str(text or "").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.add(int(part))
        except ValueError:
            pass
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description="Curate raw implementation-skill extractions.")
    parser.add_argument("--summary-tsv", required=True, type=Path)
    parser.add_argument("--problem-links-tsv", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--min-skill-problems", type=int, default=2)
    parser.add_argument("--min-skill-batch-mentions", type=int, default=5)
    parser.add_argument("--min-edge-batch-mentions", type=int, default=1)
    args = parser.parse_args()

    summary_rows = read_tsv(args.summary_tsv)
    link_rows = read_tsv(args.problem_links_tsv)

    raw_meta: dict[str, dict[str, object]] = {}
    mapped_raws: dict[str, list[dict[str, object]]] = defaultdict(list)
    rejected: list[dict[str, object]] = []

    for row in summary_rows:
        raw = norm_text(row.get("normalized_skill") or row.get("display_skill"))
        display = str(row.get("display_skill") or row.get("normalized_skill") or "").strip()
        batch_mentions = int(float(row.get("batch_mentions") or 0))
        problems = parse_problem_list(row.get("linked_problems") or "")
        canonical_key, reason = map_skill(raw)
        raw_meta[raw] = {
            "raw_norm": raw,
            "display_skill": display,
            "batch_mentions": batch_mentions,
            "linked_problem_count": len(problems),
            "linked_problems": ",".join(str(p) for p in sorted(problems)),
            "canonical_key": canonical_key or "",
            "reject_reason": reason or "",
        }
        if canonical_key is None:
            rejected.append(raw_meta[raw])
            continue
        mapped_raws[canonical_key].append(raw_meta[raw])

    edge_acc: dict[tuple[int, str], Counter] = defaultdict(Counter)
    for row in link_rows:
        raw = norm_text(row.get("normalized_skill") or row.get("display_skill"))
        meta = raw_meta.get(raw)
        if not meta or not meta.get("canonical_key"):
            continue
        canonical_key = str(meta["canonical_key"])
        try:
            problem_id = int(str(row.get("problem_id") or "").split("|")[-1])
        except ValueError:
            continue
        mentions = int(float(row.get("batch_mentions_for_problem") or 0))
        if mentions < args.min_edge_batch_mentions:
            continue
        edge_acc[(problem_id, canonical_key)]["batch_mentions"] += mentions
        edge_acc[(problem_id, canonical_key)]["raw_skill_count"] += 1

    skill_edges: dict[str, list[tuple[int, Counter]]] = defaultdict(list)
    for (problem_id, canonical_key), counts in edge_acc.items():
        skill_edges[canonical_key].append((problem_id, counts))

    concept_rows = []
    membership_rows = []
    problem_edge_rows = []
    kept_keys = set()

    for canonical_key, raw_rows in mapped_raws.items():
        meta = CURATED_SKILLS[canonical_key]
        problems = sorted(problem_id for problem_id, _ in skill_edges.get(canonical_key, []))
        total_batch_mentions = sum(int(r["batch_mentions"]) for r in raw_rows)
        raw_rows_sorted = sorted(
            raw_rows,
            key=lambda r: (-int(r["batch_mentions"]), str(r["raw_norm"])),
        )
        status = "kept" if (
            len(problems) >= args.min_skill_problems
            and total_batch_mentions >= args.min_skill_batch_mentions
        ) else "low_support"
        if status == "kept":
            kept_keys.add(canonical_key)
        top_raw = " | ".join(
            f"{r['display_skill']} ({r['batch_mentions']})" for r in raw_rows_sorted[:12]
        )
        all_raw = " | ".join(
            f"{r['display_skill']} ({r['batch_mentions']})" for r in raw_rows_sorted
        )
        concept_rows.append(
            {
                "canonical_key": canonical_key,
                "canonical_skill": f"additional::{meta['display']}",
                "display_skill": meta["display"],
                "canonical_norm": f"additional_{canonical_key}",
                "assigned_stage": meta["stage"],
                "parent_hint": meta["parent_hint"],
                "status": status,
                "num_raw_skills": len(raw_rows),
                "raw_batch_mentions": total_batch_mentions,
                "num_problems": len(problems),
                "problems": ",".join(str(p) for p in problems),
                "top_raw_skills": top_raw,
                "all_merged_raw_skills": all_raw,
            }
        )
        for r in raw_rows_sorted:
            membership_rows.append(
                {
                    "canonical_key": canonical_key,
                    "canonical_skill": f"additional::{meta['display']}",
                    "display_skill": meta["display"],
                    "status": status,
                    "raw_norm": r["raw_norm"],
                    "raw_display_skill": r["display_skill"],
                    "raw_batch_mentions": r["batch_mentions"],
                    "raw_linked_problem_count": r["linked_problem_count"],
                    "raw_linked_problems": r["linked_problems"],
                }
            )

    for (problem_id, canonical_key), counts in sorted(edge_acc.items()):
        if canonical_key not in kept_keys:
            continue
        meta = CURATED_SKILLS[canonical_key]
        problem_edge_rows.append(
            {
                "problem_id": problem_id,
                "canonical_skill": f"additional::{meta['display']}",
                "canonical_norm": f"additional_{canonical_key}",
                "assigned_stage": meta["stage"],
                "support_count": 0.35,
                "support_languages": json.dumps(["Java"]),
                "evidence_skills": json.dumps([]),
                "match_types": json.dumps({"llm_implementation_skill": 1}, sort_keys=True),
                "batch_mentions": int(counts["batch_mentions"]),
                "raw_skill_count": int(counts["raw_skill_count"]),
                "parent_hint": meta["parent_hint"],
            }
        )

    concept_rows.sort(
        key=lambda r: (
            0 if r["status"] == "kept" else 1,
            -int(r["num_problems"]),
            -int(r["raw_batch_mentions"]),
            str(r["canonical_key"]),
        )
    )
    membership_rows.sort(
        key=lambda r: (
            str(r["canonical_key"]),
            -int(r["raw_batch_mentions"]),
            str(r["raw_norm"]),
        )
    )
    rejected.sort(key=lambda r: (-int(r["batch_mentions"]), str(r["raw_norm"])))
    problem_edge_rows.sort(key=lambda r: (int(r["problem_id"]), str(r["canonical_norm"])))

    concept_fields = [
        "canonical_key",
        "canonical_skill",
        "display_skill",
        "canonical_norm",
        "assigned_stage",
        "parent_hint",
        "status",
        "num_raw_skills",
        "raw_batch_mentions",
        "num_problems",
        "problems",
        "top_raw_skills",
        "all_merged_raw_skills",
    ]
    membership_fields = [
        "canonical_key",
        "canonical_skill",
        "display_skill",
        "status",
        "raw_norm",
        "raw_display_skill",
        "raw_batch_mentions",
        "raw_linked_problem_count",
        "raw_linked_problems",
    ]
    reject_fields = [
        "raw_norm",
        "display_skill",
        "batch_mentions",
        "linked_problem_count",
        "linked_problems",
        "reject_reason",
    ]
    edge_fields = [
        "problem_id",
        "canonical_skill",
        "canonical_norm",
        "assigned_stage",
        "support_count",
        "support_languages",
        "evidence_skills",
        "match_types",
        "batch_mentions",
        "raw_skill_count",
        "parent_hint",
    ]
    write_tsv(args.out_dir / "merged_concept_raw_skill_map.tsv", concept_rows, concept_fields)
    write_tsv(args.out_dir / "merged_raw_skill_membership.tsv", membership_rows, membership_fields)
    write_tsv(args.out_dir / "rejected_raw_skills.tsv", rejected, reject_fields)
    write_csv(args.out_dir / "problem_skill_edges.csv", problem_edge_rows, edge_fields)
    write_tsv(
        args.out_dir / "implementation_skill_catalog.tsv",
        [r for r in concept_rows if r["status"] == "kept"],
        concept_fields,
    )
    stats = {
        "raw_unique_skills": len(summary_rows),
        "mapped_raw_skills": sum(len(v) for v in mapped_raws.values()),
        "rejected_raw_skills": len(rejected),
        "canonical_concepts_all": len(concept_rows),
        "canonical_concepts_kept": len(kept_keys),
        "problem_edges_kept": len(problem_edge_rows),
        "covered_problems_kept": len({int(r["problem_id"]) for r in problem_edge_rows}),
        "min_skill_problems": args.min_skill_problems,
        "min_skill_batch_mentions": args.min_skill_batch_mentions,
        "min_edge_batch_mentions": args.min_edge_batch_mentions,
    }
    (args.out_dir / "curation_stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(stats, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
