#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import torch


def weighted_problem_skill_matrix(
    edges: pd.DataFrame, pro_id_dict: Path
) -> tuple[pd.DataFrame, torch.Tensor]:
    mapping = {
        int(k): int(v)
        for k, v in ast.literal_eval(pro_id_dict.read_text(encoding="utf-8")).items()
    }
    skills = sorted(edges["canonical_skill"].astype(str).unique())
    skill_idx = {skill: idx for idx, skill in enumerate(skills)}
    skill_problem_count = edges.groupby("canonical_skill")["problem_id"].nunique().to_dict()
    matrix = np.zeros((len(mapping), len(skills)), dtype=np.float32)
    for problem_id, group in edges.groupby("problem_id"):
        weighted_skills: list[tuple[int, float]] = []
        for row in group.itertuples(index=False):
            evidence = max(
                float(getattr(row, "batch_mentions", 0) or 0),
                float(getattr(row, "support_count", 0) or 0),
                float(getattr(row, "raw_skill_count", 0) or 0),
                1.0,
            )
            coverage = max(float(skill_problem_count[str(row.canonical_skill)]), 1.0)
            specificity = 1.0 / np.log1p(coverage + 1.0)
            weighted_skills.append((skill_idx[str(row.canonical_skill)], evidence * specificity))
        total = sum(weight for _, weight in weighted_skills)
        for index, weight in weighted_skills:
            matrix[mapping[int(problem_id)], index] = weight / max(total, 1e-8)
    vocab = pd.DataFrame({"canonical_skill": skills})
    vocab["canonical_norm"] = (
        vocab["canonical_skill"].str.replace("::", "_", regex=False).str.lower()
    )
    return vocab, torch.from_numpy(matrix)


def copy_required_base_assets(base_root: Path, out_root: Path, tasks: list[str]) -> None:
    for task in tasks:
        src_global = base_root / task / "assets" / "global" / "iice_fused_code.pt"
        dst_global = out_root / task / "assets" / "global"
        dst_global.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_global, dst_global / src_global.name)
        for fold in range(1, 6):
            src_problem = (
                base_root / task / f"fold_{fold}" / "assets" / "problem_embedding_full.pt"
            )
            dst_problem = out_root / task / f"fold_{fold}" / "assets"
            dst_problem.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_problem, dst_problem / src_problem.name)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build implementation-skill input assets for Ours (full)."
    )
    parser.add_argument("--base-asset-root", required=True, type=Path)
    parser.add_argument("--edge-csv", required=True, type=Path)
    parser.add_argument("--catalog-tsv", required=True, type=Path)
    parser.add_argument("--pro-id-dict", required=True, type=Path)
    parser.add_argument("--protocol-root", required=True, type=Path)
    parser.add_argument("--out-asset-root", required=True, type=Path)
    parser.add_argument("--tasks", required=True)
    args = parser.parse_args()

    tasks = [task.strip() for task in args.tasks.split(",") if task.strip()]
    edges = pd.read_csv(args.edge_csv)
    base_vocab, problem_skill_matrix = weighted_problem_skill_matrix(edges, args.pro_id_dict)
    copy_required_base_assets(args.base_asset_root, args.out_asset_root, tasks)

    vocab_rows = []
    for channel in ("failure", "success"):
        for row in base_vocab.itertuples(index=False):
            vocab_rows.append(
                {
                    "canonical_skill": f"{row.canonical_skill}::{channel}",
                    "canonical_norm": f"{row.canonical_norm}_{channel}",
                    "base_canonical_skill": row.canonical_skill,
                    "base_canonical_norm": row.canonical_norm,
                    "evidence_channel": channel,
                }
            )
    vocab = pd.DataFrame(vocab_rows)
    vocab["implementation_idx"] = np.arange(len(vocab))
    vocab.to_csv(args.out_asset_root / "implementation_skill_vocab.tsv", sep="\t", index=False)
    torch.save(problem_skill_matrix, args.out_asset_root / "problem_skill_matrix.pt")
    pd.DataFrame(problem_skill_matrix.numpy()).to_csv(
        args.out_asset_root / "problem_skill_matrix.tsv", sep="\t", index=False
    )
    shutil.copy2(args.catalog_tsv, args.out_asset_root / "implementation_skill_catalog.tsv")

    mapping = {
        int(k): int(v)
        for k, v in ast.literal_eval(args.pro_id_dict.read_text(encoding="utf-8")).items()
    }
    task_stats = []
    for task in tasks:
        events = pd.read_csv(
            args.protocol_root / "setting1" / task / "full_events_chunked.csv",
            usecols=["problem_id", "result"],
        )
        array = np.zeros((len(events), 2 * problem_skill_matrix.shape[1]), dtype=np.float32)
        for row_idx, row in enumerate(events.itertuples(index=False)):
            weights = problem_skill_matrix[mapping[int(row.problem_id)]].numpy()
            offset = problem_skill_matrix.shape[1] if int(row.result) == 1 else 0
            array[row_idx, offset : offset + problem_skill_matrix.shape[1]] = weights
        global_dir = args.out_asset_root / task / "assets" / "global"
        torch.save(torch.from_numpy(array), global_dir / "implementation_skill_row_aligned.pt")
        task_stats.append(
            {
                "task": task,
                "num_rows": int(len(events)),
                "num_implementation_features": int(array.shape[1]),
                "active_rows": int((array.sum(axis=1) > 0).sum()),
                "value_sum": float(array.sum()),
            }
        )

    stats = {
        "base_asset_root": str(args.base_asset_root),
        "asset_root": str(args.out_asset_root),
        "edge_csv": str(args.edge_csv),
        "representation": "signed_connection_weighted",
        "num_implementation_skills": int(problem_skill_matrix.shape[1]),
        "num_signed_implementation_features": int(2 * problem_skill_matrix.shape[1]),
        "num_problem_skill_edges": int(len(edges)),
        "covered_problems": int(edges["problem_id"].nunique()),
        "problem_skill_matrix": str(args.out_asset_root / "problem_skill_matrix.pt"),
        "tasks": tasks,
        "task_stats": task_stats,
    }
    (args.out_asset_root / "target_skill_asset_stats.json").write_text(
        json.dumps(stats, indent=2), encoding="utf-8"
    )
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
