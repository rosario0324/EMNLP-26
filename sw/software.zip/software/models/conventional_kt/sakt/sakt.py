import os

import numpy as np
import torch

from torch.nn import Module, Parameter, Embedding, Sequential, Linear, ReLU, \
    MultiheadAttention, LayerNorm, Dropout
from torch.nn.init import kaiming_normal_
from torch.nn.functional import binary_cross_entropy
import torch.nn.functional as F
from sklearn import metrics


class SAKT(Module):
    '''
        This implementation has a reference from: \
        https://pytorch.org/docs/stable/_modules/torch/nn/modules/transformer.html#TransformerEncoderLayer

        Args:
            num_q: the total number of the questions(KCs) in the given dataset
            n: the length of the sequence of the questions or responses
            d: the dimension of the hidden vectors in this model
            num_attn_heads: the number of the attention heads in the \
                multi-head attention module in this model
            dropout: the dropout rate of this model
    '''
    def __init__(self, num_q, n, d, num_attn_heads, dropout, micro_emb=None, micro_mode="none"):
        super().__init__()
        self.num_q = num_q
        self.n = n
        self.d = d
        self.num_attn_heads = num_attn_heads
        self.dropout = dropout

        self.micro_mode = micro_mode
        self.use_micro = micro_emb is not None and micro_mode != "none"

        if self.use_micro:
            self.q_emb = Embedding(self.num_q, self.d)
            self.r_emb = Embedding(2, self.d)
            self.register_buffer("micro_emb", micro_emb)
            micro_dim = micro_emb.shape[1]
            self.micro_proj = Linear(micro_dim, self.d, bias=False) if micro_dim != self.d else None
            self.concat_proj = (
                Linear(self.d * 2, self.d, bias=False)
                if micro_mode in ("concat", "contrastive")
                else None
            )
            self.M = None
            self.E = None
        else:
            self.M = Embedding(self.num_q * 2, self.d)
            self.E = Embedding(self.num_q, d)
            self.q_emb = None
            self.r_emb = None
            self.micro_proj = None
            self.concat_proj = None
        self.P = Parameter(torch.Tensor(self.n, self.d))

        kaiming_normal_(self.P)

        self.attn = MultiheadAttention(
            self.d, self.num_attn_heads, dropout=self.dropout
        )
        self.attn_dropout = Dropout(self.dropout)
        self.attn_layer_norm = LayerNorm(self.d)

        self.FFN = Sequential(
            Linear(self.d, self.d),
            ReLU(),
            Dropout(self.dropout),
            Linear(self.d, self.d),
            Dropout(self.dropout),
        )
        self.FFN_layer_norm = LayerNorm(self.d)

        self.pred = Linear(self.d, 1)

    def forward(self, q, r, qry):
        '''
            Args:
                q: the question(KC) sequence with the size of [batch_size, n]
                r: the response sequence with the size of [batch_size, n]
                qry: the query sequence with the size of [batch_size, m], \
                    where the query is the question(KC) what the user wants \
                    to check the knowledge level of

            Returns:
                p: the knowledge level about the query
                attn_weights: the attention weights from the multi-head \
                    attention module
        '''
        if not self.use_micro:
            x = q + self.num_q * r
            M = self.M(x).permute(1, 0, 2)
            E = self.E(qry).permute(1, 0, 2)
        else:
            q_rep = self.question_repr(q)
            r_rep = self.r_emb(r)
            M = (q_rep + r_rep).permute(1, 0, 2)
            E = self.question_repr(qry).permute(1, 0, 2)
        P = self.P.unsqueeze(1)

        causal_mask = torch.triu(
            torch.ones([E.shape[0], M.shape[0]], device=E.device), diagonal=1
        ).bool()

        M = M + P

        S, attn_weights = self.attn(E, M, M, attn_mask=causal_mask)
        S = self.attn_dropout(S)
        S = S.permute(1, 0, 2)
        M = M.permute(1, 0, 2)
        E = E.permute(1, 0, 2)

        if M.shape[1] != S.shape[1]:
            # Align memory length to query length when evaluating variable-length queries
            if M.shape[1] > S.shape[1]:
                M = M[:, -S.shape[1]:, :]
            else:
                pad_len = S.shape[1] - M.shape[1]
                pad = torch.zeros((M.shape[0], pad_len, M.shape[2]), device=M.device, dtype=M.dtype)
                M = torch.cat([pad, M], dim=1)

        S = self.attn_layer_norm(S + M + E)

        F = self.FFN(S)
        F = self.FFN_layer_norm(F + S)

        p = torch.sigmoid(self.pred(F)).squeeze()

        return p, attn_weights

    def _project_micro(self, micro_vec):
        return self.micro_proj(micro_vec) if self.micro_proj is not None else micro_vec

    def micro_repr(self, q):
        if not self.use_micro:
            raise RuntimeError("micro_repr called without micro embeddings.")
        return self._project_micro(self.micro_emb[q])

    def question_repr(self, q):
        if not self.use_micro:
            raise RuntimeError("question_repr called without micro embeddings.")
        micro = self._project_micro(self.micro_emb[q])
        if self.micro_mode == "replace":
            return micro
        base = self.q_emb(q)
        if self.concat_proj is not None:
            return self.concat_proj(torch.cat([base, micro], dim=-1))
        return base + micro

    def contrastive_loss(self, q_ids, temperature=0.1):
        if not self.use_micro:
            return None
        q_ids = torch.unique(q_ids)
        if q_ids.numel() == 0:
            return None
        q_rep = self.question_repr(q_ids)
        m_rep = self.micro_repr(q_ids)
        q_rep = F.normalize(q_rep, dim=-1)
        m_rep = F.normalize(m_rep, dim=-1)
        logits = q_rep @ m_rep.T / temperature
        labels = torch.arange(q_rep.size(0), device=q_rep.device)
        return F.cross_entropy(logits, labels)

    def train_model(
        self, train_loader, test_loader, num_epochs, opt, ckpt_path
    ):
        '''
            Args:
                train_loader: the PyTorch DataLoader instance for training
                test_loader: the PyTorch DataLoader instance for test
                num_epochs: the number of epochs
                opt: the optimization to train this model
                ckpt_path: the path to save this model's parameters
        '''
        aucs = []
        loss_means = []

        max_auc = 0

        for i in range(1, num_epochs + 1):
            loss_mean = []

            for data in train_loader:
                q, r, qshft, rshft, m = data

                self.train()

                p, _ = self(q.long(), r.long(), qshft.long())
                p = torch.masked_select(p, m)
                t = torch.masked_select(rshft, m)

                opt.zero_grad()
                loss = binary_cross_entropy(p, t)
                loss.backward()
                opt.step()

                loss_mean.append(loss.detach().cpu().numpy())

            with torch.no_grad():
                for data in test_loader:
                    q, r, qshft, rshft, m = data

                    self.eval()

                    p, _ = self(q.long(), r.long(), qshft.long())
                    p = torch.masked_select(p, m).detach().cpu()
                    t = torch.masked_select(rshft, m).detach().cpu()

                    auc = metrics.roc_auc_score(
                        y_true=t.numpy(), y_score=p.numpy()
                    )

                    loss_mean = np.mean(loss_mean)

                    print(
                        "Epoch: {},   AUC: {},   Loss Mean: {}"
                        .format(i, auc, loss_mean)
                    )

                    if auc > max_auc:
                        torch.save(
                            self.state_dict(),
                            os.path.join(
                                ckpt_path, "model.ckpt"
                            )
                        )
                        max_auc = auc

                    aucs.append(auc)
                    loss_means.append(loss_mean)

        return aucs, loss_means
