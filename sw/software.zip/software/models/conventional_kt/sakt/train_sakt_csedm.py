import sys
import os
import argparse

def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import json
import ast
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import Adam
from torch.nn.functional import binary_cross_entropy
from sklearn import metrics
import torch.nn.functional as F

from sakt import SAKT
from micro_utils import load_micro_embedding
from rec_utils import (
    RecDataset,
    build_loader as build_rec_loader,
    collate_rec_batch,
    load_rec_examples,
    split_examples,
)


@dataclass
class TrainConfig:
    seq_csv_path: str = "./CSEDM/S19_Release/csedm_sequences_runprogram.csv"
    out_dir: str = "./kt_collection/checkpoints/sakt_csedm"
    seed: int = 42

    d: int = 128
    num_attn_heads: int = 4
    dropout: float = 0.2

    batch_size: int = 64
    num_epochs: int = 20
    lr: float = 1e-3
    val_ratio: float = 0.1

    pad_q: int = 0
    pad_r: int = 0


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_list_col(x):
    if isinstance(x, list):
        return x
    return ast.literal_eval(x)


def split_sequences_random(sequences, val_ratio, seed):
    rng = random.Random(seed)
    seqs = list(sequences)
    rng.shuffle(seqs)
    n_val = int(len(seqs) * val_ratio)
    return seqs[n_val:], seqs[:n_val]


def split_sequences_stratified(sequences, val_ratio, seed, bins=5):
    rng = random.Random(seed)
    lengths = [len(q) for q, _ in sequences]
    if len(sequences) < bins:
        return split_sequences_random(sequences, val_ratio, seed)
    quantiles = np.linspace(0, 1, bins + 1)
    edges = np.quantile(lengths, quantiles)
    edges = np.unique(edges)
    if len(edges) <= 2:
        return split_sequences_random(sequences, val_ratio, seed)
    groups = [[] for _ in range(len(edges) - 1)]
    for seq, L in zip(sequences, lengths):
        idx = np.searchsorted(edges, L, side="right") - 1
        idx = max(0, min(idx, len(groups) - 1))
        groups[idx].append(seq)
    train, val = [], []
    for g in groups:
        rng.shuffle(g)
        n_val = int(len(g) * val_ratio)
        val.extend(g[:n_val])
        train.extend(g[n_val:])
    return train, val


def compute_pos_weight(sequences):
    pos = 0
    neg = 0
    for _, r in sequences:
        if len(r) < 2:
            continue
        for x in r[1:]:
            if int(x) == 1:
                pos += 1
            else:
                neg += 1
    if pos == 0:
        return None
    return float(neg) / float(pos)


class SAKTDataset(Dataset):
    def __init__(self, sequences, pad_q=0, pad_r=0, max_len=None):
        self.sequences = sequences
        self.pad_q = pad_q
        self.pad_r = pad_r
        self.max_len = max_len or max(len(q) for q, _ in sequences)

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        q, r = self.sequences[idx]
        q_in, r_in = q[:-1], r[:-1]
        qry, target = q[1:], r[1:]
        n = self.max_len - 1

        q_pad = np.full((n,), self.pad_q, dtype=np.int64)
        r_pad = np.full((n,), self.pad_r, dtype=np.int64)
        qry_pad = np.full((n,), self.pad_q, dtype=np.int64)
        t_pad = np.full((n,), self.pad_r, dtype=np.float32)
        m = np.zeros((n,), dtype=np.bool_)

        cur = len(qry)
        q_pad[:cur] = q_in
        r_pad[:cur] = r_in
        qry_pad[:cur] = qry
        t_pad[:cur] = target
        m[:cur] = True

        return (
            torch.from_numpy(q_pad),
            torch.from_numpy(r_pad),
            torch.from_numpy(qry_pad),
            torch.from_numpy(t_pad),
            torch.from_numpy(m),
        )


def build_loader(dataset, batch_size, shuffle, num_workers, prefetch_factor, persistent_workers, pin_memory):
    kwargs = {
        "batch_size": batch_size,
        "shuffle": shuffle,
        "drop_last": False,
        "num_workers": num_workers,
    }
    if num_workers > 0:
        kwargs["prefetch_factor"] = prefetch_factor
        kwargs["persistent_workers"] = persistent_workers
    if pin_memory:
        kwargs["pin_memory"] = True
    return DataLoader(dataset, **kwargs)


def train_rec(model, train_loader, val_loader, opt, device: torch.device, num_epochs: int, ckpt_path: str):
    best_hit = -1.0
    eps = 1e-6

    for epoch in range(1, num_epochs + 1):
        model.train()
        loss_mean = []
        for q, r, cand, cand_mask, lengths, target_pos in train_loader:
            q = q.long().to(device)
            r = r.long().to(device)
            cand = cand.long().to(device)
            cand_mask = cand_mask.to(device)
            target_pos = target_pos.to(device)

            p, _ = model(q, r, cand)
            if p.dim() == 1:
                p = p.unsqueeze(1)
            cand_logits = torch.logit(p.clamp(min=eps, max=1 - eps))
            cand_logits = cand_logits.masked_fill(~cand_mask, -1e9)

            opt.zero_grad()
            loss = F.cross_entropy(cand_logits, target_pos)
            loss.backward()
            opt.step()
            loss_mean.append(loss.detach().cpu().numpy())

        model.eval()
        hit1 = 0
        total = 0
        with torch.no_grad():
            for q, r, cand, cand_mask, lengths, target_pos in val_loader:
                q = q.long().to(device)
                r = r.long().to(device)
                cand = cand.long().to(device)
                cand_mask = cand_mask.to(device)
                target_pos = target_pos.to(device)

                p, _ = model(q, r, cand)
                if p.dim() == 1:
                    p = p.unsqueeze(1)
                scores = p.masked_fill(~cand_mask, -1e9)
                preds = scores.argmax(dim=1)
                hit1 += (preds == target_pos).sum().item()
                total += q.size(0)

        hit1_rate = hit1 / total if total else 0.0
        loss_epoch = float(np.mean(loss_mean)) if loss_mean else 0.0
        print(f"Epoch {epoch}: rec_hit@1={hit1_rate:.4f} loss_mean={loss_epoch:.4f}")

        if hit1_rate > best_hit:
            torch.save(model.state_dict(), ckpt_path)
            best_hit = hit1_rate

    return best_hit


def train_sakt(
    model, train_loader, val_loader, opt, cfg: TrainConfig, device: torch.device,
    contrastive_weight: float = 0.0, contrastive_temp: float = 0.1, pos_weight=None
):
    ckpt_dir = Path(cfg.out_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    best_auc = -1.0
    for epoch in range(1, cfg.num_epochs + 1):
        model.train()
        loss_mean = []

        for q, r, qry, t, m in train_loader:
            q = q.long().to(device)
            r = r.long().to(device)
            qry = qry.long().to(device)
            t = t.to(device)
            m = m.to(device)

            p, _ = model(q, r, qry)
            p = torch.masked_select(p, m)
            tgt = torch.masked_select(t, m)

            opt.zero_grad()
            if pos_weight is None:
                loss = binary_cross_entropy(p, tgt)
            else:
                eps = 1e-7
                loss = -(pos_weight * tgt * torch.log(p + eps) + (1 - tgt) * torch.log(1 - p + eps)).mean()
            if model.micro_mode == "contrastive" and contrastive_weight > 0:
                q_ids = torch.masked_select(qry, m)
                if q_ids.numel() > 0:
                    c_loss = model.contrastive_loss(q_ids, temperature=contrastive_temp)
                    if c_loss is not None:
                        loss = loss + contrastive_weight * c_loss
            loss.backward()
            opt.step()

            loss_mean.append(loss.detach().cpu().numpy())

        model.eval()
        y_list = []
        t_list = []
        val_loss_mean = []
        with torch.no_grad():
            for q, r, qry, t, m in val_loader:
                q = q.long().to(device)
                r = r.long().to(device)
                qry = qry.long().to(device)
                t = t.to(device)
                m = m.to(device)

                p, _ = model(q, r, qry)
                p_masked = torch.masked_select(p, m)
                tgt_masked = torch.masked_select(t, m)

                if p_masked.numel() > 0:
                    val_loss = binary_cross_entropy(p_masked, tgt_masked)
                    val_loss_mean.append(val_loss.detach().cpu().numpy())

                    y_list.append(p_masked.detach().cpu())
                    t_list.append(tgt_masked.detach().cpu())

        auc = None
        if y_list:
            all_y = torch.cat(y_list).numpy()
            all_t = torch.cat(t_list).numpy()
            if len(np.unique(all_t)) > 1:
                auc = metrics.roc_auc_score(y_true=all_t, y_score=all_y)

        loss_epoch = float(np.mean(loss_mean)) if loss_mean else 0.0
        val_loss = float(np.mean(val_loss_mean)) if val_loss_mean else 0.0
        auc_msg = f"{auc:.4f}" if auc is not None else "NA"
        print(f"Epoch {epoch}: val_auc={auc_msg}, train_loss={loss_epoch:.4f}, val_loss={val_loss:.4f}")

        if auc is not None and auc > best_auc:
            torch.save(model.state_dict(), ckpt_dir / "model.ckpt")
            best_auc = auc

    return best_auc


def main():
    parser = argparse.ArgumentParser(description="Train SAKT on CSEDM (KT or Recommendation).")
    parser.add_argument("--task", choices=["kt", "rec"], default="kt", help="학습 목적 (kt=지식추적, rec=추천)")
    parser.add_argument("--gpu", type=str, default="0", help="사용할 GPU 인덱스 (0 또는 1)")
    parser.add_argument("--seed", type=int, default=None, help="random seed override")
    parser.add_argument("--seq-csv-path", type=str, default=None, help="시퀀스 CSV 경로")
    parser.add_argument(
        "--benchmark-dir",
        type=str,
        default="./CSEDM/S19_Release/benchmark",
        help="추천 학습용 benchmark 디렉토리 (train/val 분리 없을 때 사용)",
    )
    parser.add_argument("--train-benchmark-dir", type=str, default=None, help="추천 학습 train benchmark 디렉토리")
    parser.add_argument("--val-benchmark-dir", type=str, default=None, help="추천 학습 val benchmark 디렉토리")
    parser.add_argument("--k-list", type=str, default="10,20,30,40,50", help="추천 학습 K 리스트")
    parser.add_argument("--max-candidates", type=int, default=200, help="추천 학습 후보 수 상한")
    parser.add_argument("--use-all-candidates", action="store_true", help="추천 학습에서 전체 문제를 후보로 사용")
    parser.add_argument("--out-dir", type=str, default=None, help="체크포인트 저장 경로")
    parser.add_argument("--batch-size", type=int, default=None, help="배치 크기")
    parser.add_argument("--num-workers", type=int, default=None, help="DataLoader 워커 수")
    parser.add_argument("--prefetch-factor", type=int, default=2, help="DataLoader prefetch factor (num_workers>0)")
    parser.add_argument("--persistent-workers", action="store_true", help="DataLoader persistent workers 사용")
    parser.add_argument("--pin-memory", action="store_true", help="DataLoader pin_memory 사용")
    parser.add_argument("--stratify-users", action="store_true", help="stratify split by sequence length bins")
    parser.add_argument("--stratify-bins", type=int, default=5, help="number of bins for stratified split")
    parser.add_argument("--auto-pos-weight", action="store_true", help="use neg/pos ratio as positive class weight")
    parser.add_argument("--micro-mode", choices=["none", "replace", "concat", "contrastive"], default="none")
    parser.add_argument("--micro-emb", type=str, default=None, help="micro-concept embedding .pt path")
    parser.add_argument("--micro-pro-id-dict", type=str, default=None, help="problem id dict path for micro emb")
    parser.add_argument("--contrastive-weight", type=float, default=0.1, help="contrastive loss weight")
    parser.add_argument("--contrastive-temp", type=float, default=0.1, help="contrastive loss temperature")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    cfg = TrainConfig()
    if args.seq_csv_path:
        cfg.seq_csv_path = args.seq_csv_path
    if args.out_dir:
        cfg.out_dir = args.out_dir
    if args.batch_size is not None:
        cfg.batch_size = args.batch_size
    if args.seed is not None:
        cfg.seed = args.seed

    set_seed(cfg.seed)
    Path(cfg.out_dir).mkdir(parents=True, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pin_memory = args.pin_memory or device.type == "cuda"
    num_workers = args.num_workers if args.num_workers is not None else 4

    df = pd.read_csv(cfg.seq_csv_path)
    df.columns = [c.strip().lstrip("\ufeff") for c in df.columns]

    df["problem_sequence"] = df["problem_sequence"].apply(parse_list_col)
    df["result_sequence"] = df["result_sequence"].apply(parse_list_col)

    all_probs = sorted({p for seq in df["problem_sequence"] for p in seq})
    pid2idx = {int(p): i + 1 for i, p in enumerate(all_probs)}  # reserve 0 for padding
    idx2pid = {i: p for p, i in pid2idx.items()}
    num_q = len(pid2idx) + 1

    micro_emb = None
    if args.micro_mode != "none":
        if not args.micro_emb or not args.micro_pro_id_dict:
            raise ValueError("micro_mode requires --micro-emb and --micro-pro-id-dict")
        micro_emb, missing = load_micro_embedding(
            args.micro_emb, args.micro_pro_id_dict, pid2idx, num_q=num_q, pad_idx=0
        )
        if missing:
            print(f"[micro] missing problem ids: {missing}")

    sequences = []
    for _, row in df.iterrows():
        q = [pid2idx[int(p)] for p in row["problem_sequence"]]
        r = [int(x) for x in row["result_sequence"]]
        if len(q) >= 2:
            sequences.append((q, r))

    if args.stratify_users:
        train_seqs, val_seqs = split_sequences_stratified(
            sequences, cfg.val_ratio, seed=cfg.seed, bins=args.stratify_bins
        )
    else:
        train_seqs, val_seqs = split_sequences_random(sequences, cfg.val_ratio, seed=cfg.seed)

    max_len = max(max(len(q) for q, _ in train_seqs), max(len(q) for q, _ in val_seqs))

    map_path = Path(cfg.out_dir) / "problem_id_map.json"
    with map_path.open("w", encoding="utf-8") as f:
        json.dump(
            {"pid2idx": pid2idx, "idx2pid": idx2pid, "num_q": num_q, "n": max_len - 1},
            f,
            ensure_ascii=False,
            indent=2,
        )

    if args.task == "kt":
        train_ds = SAKTDataset(train_seqs, pad_q=cfg.pad_q, pad_r=cfg.pad_r, max_len=max_len)
        val_ds = SAKTDataset(val_seqs, pad_q=cfg.pad_q, pad_r=cfg.pad_r, max_len=max_len)

        train_loader = build_loader(
            train_ds, cfg.batch_size, True, num_workers, args.prefetch_factor, args.persistent_workers, pin_memory
        )
        val_loader = build_loader(
            val_ds, cfg.batch_size, False, num_workers, args.prefetch_factor, args.persistent_workers, pin_memory
        )

        model = SAKT(
            num_q=num_q,
            n=max_len - 1,
            d=cfg.d,
            num_attn_heads=cfg.num_attn_heads,
            dropout=cfg.dropout,
            micro_emb=micro_emb,
            micro_mode=args.micro_mode,
        ).to(device)
        opt = Adam(model.parameters(), lr=cfg.lr)

        pos_weight = compute_pos_weight(train_seqs) if args.auto_pos_weight else None
        best_auc = train_sakt(
            model=model,
            train_loader=train_loader,
            val_loader=val_loader,
            opt=opt,
            cfg=cfg,
            device=device,
            contrastive_weight=args.contrastive_weight if args.micro_mode == "contrastive" else 0.0,
            contrastive_temp=args.contrastive_temp,
            pos_weight=pos_weight,
        )

        print(f"Best val AUC: {best_auc if best_auc is not None else 'NA'}")
        print(f"Saved checkpoint to: {Path(cfg.out_dir) / 'model.ckpt'}")
    else:
        k_list = [int(k.strip()) for k in args.k_list.split(",") if k.strip()]
        train_dir = Path(args.train_benchmark_dir) if args.train_benchmark_dir else Path(args.benchmark_dir)
        val_dir = Path(args.val_benchmark_dir) if args.val_benchmark_dir else None

        for label, dir_path in (("train", train_dir), ("val", val_dir)):
            if dir_path is None:
                continue
            if not dir_path.exists():
                raise FileNotFoundError(f"{label} benchmark_dir not found: {dir_path.resolve()}")
            expected = [dir_path / f"benchmark_K{k}.jsonl" for k in k_list]
            if not any(p.exists() for p in expected):
                raise FileNotFoundError(
                    f"No benchmark_K*.jsonl found in {dir_path.resolve()} for k_list={k_list}"
                )

        if val_dir:
            train_ex, skipped_train = load_rec_examples(
                train_dir,
                k_list,
                pid2idx,
                max_seq_len=max_len - 1,
                max_candidates=args.max_candidates,
                seed=cfg.seed,
                use_all_candidates=args.use_all_candidates,
            )
            val_ex, skipped_val = load_rec_examples(
                val_dir,
                k_list,
                pid2idx,
                max_seq_len=max_len - 1,
                max_candidates=args.max_candidates,
                seed=cfg.seed,
                use_all_candidates=args.use_all_candidates,
            )
            if not train_ex or not val_ex:
                raise ValueError(
                    "No recommendation examples loaded. Check train/val benchmark dirs and problem_id mapping."
                )
            if skipped_train:
                print(f"[Info] 추천 train 스킵 {skipped_train}개 (매핑/히스토리 부족).")
            if skipped_val:
                print(f"[Info] 추천 val 스킵 {skipped_val}개 (매핑/히스토리 부족).")
        else:
            examples, skipped = load_rec_examples(
                train_dir,
                k_list,
                pid2idx,
                max_seq_len=max_len - 1,
                max_candidates=args.max_candidates,
                seed=cfg.seed,
                use_all_candidates=args.use_all_candidates,
            )
            if not examples:
                raise ValueError(
                    "No recommendation examples loaded. Check benchmark_dir, k_list, and problem_id mapping."
                )
            if skipped:
                print(f"[Info] 추천 학습 스킵 {skipped}개 (매핑/히스토리 부족).")

            train_ex, val_ex = split_examples(examples, cfg.val_ratio, seed=cfg.seed)
        rec_train_loader = build_rec_loader(
            RecDataset(train_ex),
            cfg.batch_size,
            True,
            num_workers,
            args.prefetch_factor,
            args.persistent_workers,
            pin_memory,
            collate_fn=lambda b: collate_rec_batch(
                b, pad_q=0, pad_r=0, pad_cand=0, fixed_len=max_len - 1, pad_left=False
            ),
        )
        rec_val_loader = build_rec_loader(
            RecDataset(val_ex),
            cfg.batch_size,
            False,
            num_workers,
            args.prefetch_factor,
            args.persistent_workers,
            pin_memory,
            collate_fn=lambda b: collate_rec_batch(
                b, pad_q=0, pad_r=0, pad_cand=0, fixed_len=max_len - 1, pad_left=False
            ),
        )

        model = SAKT(
            num_q=num_q,
            n=max_len - 1,
            d=cfg.d,
            num_attn_heads=cfg.num_attn_heads,
            dropout=cfg.dropout,
        ).to(device)
        opt = Adam(model.parameters(), lr=cfg.lr)
        rec_ckpt = str(Path(cfg.out_dir) / "model_rec.ckpt")
        train_rec(model, rec_train_loader, rec_val_loader, opt, device, cfg.num_epochs, rec_ckpt)
        print(f"Saved recommendation checkpoint to: {rec_ckpt}")

    print(f"Saved problem id map to: {map_path}")


if __name__ == "__main__":
    main()
