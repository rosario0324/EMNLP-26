import os

import numpy as np
import torch

from torch.nn import Module, Parameter, Embedding, Linear
from torch.nn.init import kaiming_normal_
from torch.nn.functional import binary_cross_entropy
import torch.nn.functional as F
from sklearn import metrics


class DKVMN(Module):
    '''
        Args:
            num_q: the total number of the questions(KCs) in the given dataset
            dim_s: the dimension of the state vectors in this model
            size_m: the memory size of this model
    '''
    def __init__(self, num_q, dim_s, size_m, micro_emb=None, micro_mode="none"):
        super().__init__()
        self.num_q = num_q
        self.dim_s = dim_s
        self.size_m = size_m

        self.micro_mode = micro_mode
        self.use_micro = micro_emb is not None and micro_mode != "none"

        if self.use_micro:
            self.q_emb = Embedding(self.num_q, self.dim_s)
            self.r_emb = Embedding(2, self.dim_s)
            self.register_buffer("micro_emb", micro_emb)
            micro_dim = micro_emb.shape[1]
            self.micro_proj = Linear(micro_dim, self.dim_s, bias=False) if micro_dim != self.dim_s else None
            self.concat_proj = (
                Linear(self.dim_s * 2, self.dim_s, bias=False)
                if micro_mode in ("concat", "contrastive")
                else None
            )
            self.k_emb_layer = None
            self.v_emb_layer = None
        else:
            self.k_emb_layer = Embedding(self.num_q, self.dim_s)
            self.v_emb_layer = Embedding(self.num_q * 2, self.dim_s)
            self.q_emb = None
            self.r_emb = None
            self.micro_proj = None
            self.concat_proj = None
        self.Mk = Parameter(torch.Tensor(self.size_m, self.dim_s))
        self.Mv0 = Parameter(torch.Tensor(self.size_m, self.dim_s))

        kaiming_normal_(self.Mk)
        kaiming_normal_(self.Mv0)

        self.f_layer = Linear(self.dim_s * 2, self.dim_s)
        self.p_layer = Linear(self.dim_s, 1)

        self.e_layer = Linear(self.dim_s, self.dim_s)
        self.a_layer = Linear(self.dim_s, self.dim_s)

    def forward(self, q, r):
        '''
            Args:
                q: the question(KC) sequence with the size of [batch_size, n]
                r: the response sequence with the size of [batch_size, n]

            Returns:
                p: the knowledge level about q
                Mv: the value matrices from q, r
        '''
        x = q + self.num_q * r

        batch_size = x.shape[0]
        Mvt = self.Mv0.unsqueeze(0).repeat(batch_size, 1, 1)

        Mv = [Mvt]

        if not self.use_micro:
            k = self.k_emb_layer(q)
            v = self.v_emb_layer(x)
        else:
            q_rep = self.question_repr(q)
            r_rep = self.r_emb(r)
            k = q_rep
            v = q_rep + r_rep

        w = torch.softmax(torch.matmul(k, self.Mk.T), dim=-1)

        # Write Process
        e = torch.sigmoid(self.e_layer(v))
        a = torch.tanh(self.a_layer(v))

        for et, at, wt in zip(
            e.permute(1, 0, 2), a.permute(1, 0, 2), w.permute(1, 0, 2)
        ):
            Mvt = Mvt * (1 - (wt.unsqueeze(-1) * et.unsqueeze(1))) + \
                (wt.unsqueeze(-1) * at.unsqueeze(1))
            Mv.append(Mvt)

        Mv = torch.stack(Mv, dim=1)

        # Read Process
        f = torch.tanh(
            self.f_layer(
                torch.cat(
                    [
                        (w.unsqueeze(-1) * Mv[:, :-1]).sum(-2),
                        k
                    ],
                    dim=-1
                )
            )
        )
        p = torch.sigmoid(self.p_layer(f)).squeeze()

        return p, Mv

    def _project_micro(self, micro_vec):
        return self.micro_proj(micro_vec) if self.micro_proj is not None else micro_vec

    def micro_repr(self, q):
        if not self.use_micro:
            raise RuntimeError("micro_repr called without micro embeddings.")
        return self._project_micro(self.micro_emb[q])

    def question_repr(self, q):
        if not self.use_micro:
            raise RuntimeError("question_repr called without micro embeddings.")
        micro = self._project_micro(self.micro_emb[q])
        if self.micro_mode == "replace":
            return micro
        base = self.q_emb(q)
        if self.concat_proj is not None:
            return self.concat_proj(torch.cat([base, micro], dim=-1))
        return base + micro

    def contrastive_loss(self, q_ids, temperature=0.1):
        if not self.use_micro:
            return None
        q_ids = torch.unique(q_ids)
        if q_ids.numel() == 0:
            return None
        q_rep = self.question_repr(q_ids)
        m_rep = self.micro_repr(q_ids)
        q_rep = F.normalize(q_rep, dim=-1)
        m_rep = F.normalize(m_rep, dim=-1)
        logits = q_rep @ m_rep.T / temperature
        labels = torch.arange(q_rep.size(0), device=q_rep.device)
        return F.cross_entropy(logits, labels)

    def train_model(
            self, train_loader, test_loader, num_epochs, opt, ckpt_path,
            contrastive_weight=0.0, contrastive_temp=0.1, pos_weight=None
        ):
        '''
            Args:
                train_loader: the PyTorch DataLoader instance for training
                test_loader: the PyTorch DataLoader instance for test
                num_epochs: the number of epochs
                opt: the optimization to train this model
                ckpt_path: the path to save this model's parameters
        '''
        aucs = []
        loss_means = []

        max_auc = 0

        for i in range(1, num_epochs + 1):
            loss_mean = []

            for data in train_loader:
                q, r, _, _, m = data

                self.train()

                p, _ = self(q.long(), r.long())
                p = torch.masked_select(p, m)
                t = torch.masked_select(r, m).float()

                opt.zero_grad()
                if pos_weight is None:
                    loss = binary_cross_entropy(p, t)
                else:
                    eps = 1e-7
                    loss = -(pos_weight * t * torch.log(p + eps) + (1 - t) * torch.log(1 - p + eps)).mean()
                if self.micro_mode == "contrastive" and contrastive_weight > 0:
                    q_ids = torch.masked_select(q, m)
                    if q_ids.numel() > 0:
                        c_loss = self.contrastive_loss(q_ids, temperature=contrastive_temp)
                        if c_loss is not None:
                            loss = loss + contrastive_weight * c_loss
                loss.backward()
                opt.step()

                loss_mean.append(loss.detach().cpu().numpy())

            with torch.no_grad():
                for data in test_loader:
                    q, r, _, _, m = data

                    self.eval()

                    p, _ = self(q.long(), r.long())
                    p = torch.masked_select(p, m).detach().cpu()
                    t = torch.masked_select(r, m).float().detach().cpu()

                    auc = metrics.roc_auc_score(
                        y_true=t.numpy(), y_score=p.numpy()
                    )

                    loss_mean = np.mean(loss_mean)

                    print(
                        "Epoch: {},   AUC: {},   Loss Mean: {}"
                        .format(i, auc, loss_mean)
                    )

                    if auc > max_auc:
                        torch.save(
                            self.state_dict(),
                            os.path.join(
                                ckpt_path, "model.ckpt"
                            )
                        )
                        max_auc = auc

                    aucs.append(auc)
                    loss_means.append(loss_mean)

        return aucs, loss_means
