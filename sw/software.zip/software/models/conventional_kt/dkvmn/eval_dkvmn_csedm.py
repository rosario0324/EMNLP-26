import sys
import os
import argparse

def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import json
from pathlib import Path
from typing import Dict, Tuple, Optional

import numpy as np
import torch
from sklearn import metrics
import random

from dkvmn import DKVMN


def load_pid_map(map_path: str) -> Tuple[Dict[int, int], int]:
    with open(map_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}
    num_q = int(m["num_q"])
    return pid2idx, num_q


def map_history(seq, pid2idx: Dict[int, int], max_seq_len: Optional[int]):
    q_hist, r_hist = [], []
    for s in seq:
        pid = int(s["problem_id"])
        if pid not in pid2idx:
            return None, None
        q_hist.append(pid2idx[pid])
        r_hist.append(int(s["result"]))
    if max_seq_len and len(q_hist) > max_seq_len:
        q_hist = q_hist[-max_seq_len:]
        r_hist = r_hist[-max_seq_len:]
    return q_hist, r_hist


@torch.no_grad()
def predict_prob_batch(model, q_hist, r_hist, target_indices, device):
    base_q = torch.tensor(q_hist, dtype=torch.long, device=device).unsqueeze(0)
    base_r = torch.tensor(r_hist, dtype=torch.long, device=device).unsqueeze(0)

    cand = torch.tensor(target_indices, dtype=torch.long, device=device).unsqueeze(1)
    zeros = torch.zeros(len(target_indices), 1, dtype=torch.long, device=device)

    q_eval = torch.cat([base_q.expand(len(target_indices), -1), cand], dim=1)
    r_eval = torch.cat([base_r.expand(len(target_indices), -1), zeros], dim=1)

    p, _ = model(q_eval, r_eval)
    if p.dim() == 1:
        return p[-1:].cpu().numpy()
    if p.dim() == 2:
        return p[:, -1].detach().cpu().numpy()
    return p.reshape(len(target_indices), -1)[:, -1].detach().cpu().numpy()


@torch.no_grad()
def eval_auc(model, pid2idx, jsonl_path: Path, device: torch.device, max_seq_len: Optional[int]):
    y_scores = []
    y_true = []
    n_skipped = 0

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            ex = json.loads(line)

            seq = ex["input_sequence"]
            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))

            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q_hist, r_hist = map_history(seq, pid2idx, max_seq_len)
            if not q_hist:
                n_skipped += 1
                continue

            prob = float(predict_prob_batch(model, q_hist, r_hist, [pid2idx[target_pid]], device)[0])
            y_scores.append(prob)
            y_true.append(target_r)

    y_scores = np.array(y_scores, dtype=np.float32)
    y_true = np.array(y_true, dtype=np.int32)

    if len(y_true) == 0:
        return {"auc": None, "acc@0.5": None, "logloss": None, "n_eval": 0, "n_skipped": n_skipped}

    auc = metrics.roc_auc_score(y_true=y_true, y_score=y_scores) if len(np.unique(y_true)) > 1 else None
    acc = ((y_scores >= 0.5).astype(np.int32) == y_true).mean()
    ll = metrics.log_loss(y_true=y_true, y_pred=np.clip(y_scores, 1e-6, 1 - 1e-6))

    return {
        "auc": None if auc is None else float(auc),
        "acc@0.5": float(acc),
        "logloss": float(ll),
        "n_eval": int(len(y_true)),
        "n_skipped": int(n_skipped),
    }


def hit_at_k(rank_pos: int, k: int) -> float:
    return 1.0 if rank_pos <= k else 0.0


def ndcg_at_k(rank_pos: int, k: int) -> float:
    if rank_pos <= k:
        return 1.0 / np.log2(rank_pos + 1)
    return 0.0


@torch.no_grad()
def eval_topk(
    model,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    num_q: int,
    device: torch.device,
    ks=(1, 3, 5, 10, 20, 50),
    candidate_batch: int = 64,
    max_seq_len: Optional[int] = None,
):
    ks = sorted(set(ks))
    max_k = max(ks)

    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}

    n_eval = 0
    n_skipped = 0

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            ex = json.loads(line)

            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))

            if target_pid not in pid2idx or target_r != 1:
                n_skipped += 1
                continue

            q_hist, r_hist = map_history(ex["input_sequence"], pid2idx, max_seq_len)
            if not q_hist:
                n_skipped += 1
                continue

            scores = np.zeros(num_q - 1, dtype=np.float32)
            cand_indices = list(range(1, num_q))
            for start in range(0, len(cand_indices), candidate_batch):
                batch = cand_indices[start : start + candidate_batch]
                probs = predict_prob_batch(model, q_hist, r_hist, batch, device)
                scores[start : start + len(batch)] = probs

            tgt_idx = pid2idx[target_pid]
            sorted_idx = np.argsort(-scores)
            rank_pos = np.where(sorted_idx == (tgt_idx - 1))[0]
            rank_pos = int(rank_pos[0]) + 1 if rank_pos.size > 0 else 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)

            n_eval += 1

    out = {"n_eval": n_eval, "n_skipped": n_skipped}
    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out

    for k in ks:
        out[f"Hit@{k}"] = sums_hit[k] / n_eval
        out[f"NDCG@{k}"] = sums_ndcg[k] / n_eval
    return out


@torch.no_grad()
def eval_topk_candidates(
    model,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    device: torch.device,
    ks=(1, 3, 5, 10, 20, 50),
    candidate_batch: int = 64,
    max_seq_len: Optional[int] = None,
    max_candidates: int = 0,
):
    ks = sorted(set(ks))
    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}
    n_eval = 0
    n_skipped = 0
    rng = random.Random(42)

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            ex = json.loads(line)

            target_pid = int(ex["target_problem_id"])
            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q_hist, r_hist = map_history(ex["input_sequence"], pid2idx, max_seq_len)
            if not q_hist:
                n_skipped += 1
                continue

            cand_raw = ex.get("candidate_problems")
            if not isinstance(cand_raw, list):
                n_skipped += 1
                continue
            candidates = [pid2idx[int(pid)] for pid in cand_raw if int(pid) in pid2idx]
            tgt = pid2idx[target_pid]
            if tgt not in candidates:
                candidates.append(tgt)
            if max_candidates and len(candidates) > max_candidates:
                others = [c for c in candidates if c != tgt]
                keep = rng.sample(others, max_candidates - 1)
                candidates = keep + [tgt]

            scores = np.zeros(len(candidates), dtype=np.float32)
            for start in range(0, len(candidates), candidate_batch):
                batch = candidates[start : start + candidate_batch]
                probs = predict_prob_batch(model, q_hist, r_hist, batch, device)
                scores[start : start + len(batch)] = probs

            target_pos = candidates.index(tgt)
            sorted_idx = np.argsort(-scores)
            rank_pos = int(np.where(sorted_idx == target_pos)[0][0]) + 1 if target_pos >= 0 else 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)

            n_eval += 1

    out = {"n_eval": n_eval, "n_skipped": n_skipped}
    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out

    for k in ks:
        out[f"Hit@{k}"] = sums_hit[k] / n_eval
        out[f"NDCG@{k}"] = sums_ndcg[k] / n_eval
    return out


def main():
    parser = argparse.ArgumentParser(description="Evaluate DKVMN on CSEDM benchmarks with OOM-safe settings.")
    parser.add_argument("--model-ckpt", type=str, default="./kt_collection/checkpoints/dkvmn_csedm/model.ckpt")
    parser.add_argument("--map-path", type=str, default="./kt_collection/checkpoints/dkvmn_csedm/problem_id_map.json")
    parser.add_argument("--gpu", type=str, default="0", help="사용할 GPU 인덱스 (0 또는 1)")
    parser.add_argument("--benchmark-dir", type=str, default="./CSEDM/S19_Release/benchmark")
    parser.add_argument("--k-list", type=str, default="10,20,30,40,50", help="Comma-separated K list")
    parser.add_argument("--device", type=str, default=None, help="cpu or cuda (default: cuda if available else cpu)")
    parser.add_argument("--candidate-batch", type=int, default=64, help="Candidate scoring batch size to limit GPU memory")
    parser.add_argument("--max-seq-len", type=int, default=400, help="Trim history to last N steps to avoid long-sequence OOM (set 0 to disable)")
    parser.add_argument(
        "--eval-scope",
        choices=["full", "candidate"],
        default="full",
        help="추천 평가 범위 (full=전체 문제, candidate=candidate_problems)",
    )
    parser.add_argument("--use-candidate-problems", action="store_true", help="(deprecated) eval-scope=candidate")
    parser.add_argument("--max-candidates", type=int, default=0, help="후보 수 제한 (0=제한 없음)")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    device_str = args.device or ("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device_str)

    if args.use_candidate_problems and args.eval_scope == "full":
        print("[Info] --use-candidate-problems is deprecated; use --eval-scope candidate")
    use_candidates = args.eval_scope == "candidate" or args.use_candidate_problems

    benchmark_dir = Path(args.benchmark_dir)
    K_LIST = [int(k.strip()) for k in args.k_list.split(",") if k.strip()]

    pid2idx, num_q = load_pid_map(str(args.map_path))

    model = DKVMN(num_q=num_q, dim_s=50, size_m=20).to(device)
    model.load_state_dict(torch.load(args.model_ckpt, map_location=device))
    model.eval()

    fmt = lambda v: f"{v:.4f}" if v is not None else "NA"

    max_seq_len = args.max_seq_len if args.max_seq_len > 0 else None

    for K in K_LIST:
        path = benchmark_dir / f"benchmark_K{K}.jsonl"
        if not path.exists():
            print(f"[SKIP] not found: {path}")
            continue

        stats = eval_auc(model, pid2idx, path, device, max_seq_len=max_seq_len)
        print(f"[K={K}] file={path.name} AUC={fmt(stats['auc'])} ACC@0.5={fmt(stats['acc@0.5'])} LOGLOSS={fmt(stats['logloss'])} n_eval={stats['n_eval']} n_skip={stats['n_skipped']}")
        if device.type == "cuda":
            torch.cuda.empty_cache()

    ks = (1, 3, 5, 10, 20, 50)
    for K in K_LIST:
        p = benchmark_dir / f"benchmark_K{K}.jsonl"
        if not p.exists():
            continue

        if use_candidates:
            r = eval_topk_candidates(
                model,
                pid2idx,
                p,
                device=device,
                ks=ks,
                candidate_batch=args.candidate_batch,
                max_seq_len=max_seq_len,
                max_candidates=args.max_candidates,
            )
        else:
            r = eval_topk(
                model,
                pid2idx,
                p,
                num_q=num_q,
                device=device,
                ks=ks,
                candidate_batch=args.candidate_batch,
                max_seq_len=max_seq_len,
            )

        print(f"\n[CSEDM | K={K}]")
        print(f"  n_eval={r['n_eval']}  n_skipped={r['n_skipped']}")
        for k in ks:
            print(
                f"  Hit@{k}={fmt(r[f'Hit@{k}'])} "
                f"NDCG@{k}={fmt(r[f'NDCG@{k}'])}"
            )
        if device.type == "cuda":
            torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
