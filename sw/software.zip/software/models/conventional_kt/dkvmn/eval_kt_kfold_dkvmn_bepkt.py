import sys
import os
import argparse

from sklearn.model_selection import KFold

def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import json
import ast
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from torch.nn.functional import binary_cross_entropy
from torch.optim import Adam
from sklearn import metrics

from dkvmn import DKVMN

DEFAULT_SEQ_CSV = "./CSEDM/BePKT/remapped_data/user_index_mapped_filteringQ4(17)_remapped.csv"
DEFAULT_OUT_DIR = "../kt_collection/checkpoints/dkvmn_kfold_bepkt"


@dataclass
class EvalConfig:
    seq_csv_path: str = DEFAULT_SEQ_CSV
    out_dir: str = DEFAULT_OUT_DIR
    seed: int = 42

    dim_s: int = 50
    size_m: int = 20

    batch_size: int = 64
    num_epochs: int = 20
    lr: float = 1e-3

    pad_q: int = 0
    pad_r: int = 0


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_list_col(x):
    if isinstance(x, list):
        return x
    return ast.literal_eval(x)


class DKVMNDataset(Dataset):
    def __init__(self, sequences, pad_q=0, pad_r=0, max_len=None):
        self.sequences = sequences
        self.pad_q = pad_q
        self.pad_r = pad_r
        self.max_len = max_len or max(len(q) for q, _ in sequences)

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        q, r = self.sequences[idx]
        n = self.max_len

        q_pad = np.full((n,), self.pad_q, dtype=np.int64)
        r_pad = np.full((n,), self.pad_r, dtype=np.int64)
        m = np.zeros((n,), dtype=np.bool_)

        cur = len(q)
        q_pad[:cur] = q
        r_pad[:cur] = r
        m[:cur] = True

        return (
            torch.from_numpy(q_pad),
            torch.from_numpy(r_pad),
            torch.from_numpy(m),
        )


def build_loader(dataset, batch_size, shuffle, num_workers, prefetch_factor, persistent_workers, pin_memory):
    kwargs = {
        "batch_size": batch_size,
        "shuffle": shuffle,
        "drop_last": False,
        "num_workers": num_workers,
    }
    if num_workers > 0:
        kwargs["prefetch_factor"] = prefetch_factor
        kwargs["persistent_workers"] = persistent_workers
    if pin_memory:
        kwargs["pin_memory"] = True
    return DataLoader(dataset, **kwargs)


def load_pid_map(map_path):
    with open(map_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}
    num_q = int(m.get("num_q", len(pid2idx)))
    return pid2idx, num_q


def build_sequences(df, pid2idx):
    sequences = []
    skipped_unknown = 0
    skipped_short = 0
    skipped_mismatch = 0

    for _, row in df.iterrows():
        q_raw = parse_list_col(row["problem_sequence"])
        r_raw = parse_list_col(row["result_sequence"])
        if len(q_raw) != len(r_raw):
            skipped_mismatch += 1
            continue

        q = []
        ok = True
        for p in q_raw:
            pid = int(p)
            if pid not in pid2idx:
                ok = False
                break
            q.append(pid2idx[pid])
        if not ok:
            skipped_unknown += 1
            continue

        r = [int(x) for x in r_raw]
        if len(q) < 2:
            skipped_short += 1
            continue

        sequences.append((q, r))

    skipped = {
        "unknown_pid": skipped_unknown,
        "too_short": skipped_short,
        "length_mismatch": skipped_mismatch,
    }
    return sequences, skipped


def train_one_epoch(model, loader, device, opt):
    model.train()
    losses = []
    for q, r, m in loader:
        q = q.long().to(device)
        r = r.long().to(device)
        m = m.to(device)

        p, _ = model(q, r)
        p_masked = torch.masked_select(p, m)
        t_masked = torch.masked_select(r, m).float()

        if p_masked.numel() == 0:
            continue

        opt.zero_grad()
        loss = binary_cross_entropy(p_masked, t_masked)
        loss.backward()
        opt.step()

        losses.append(loss.detach().cpu().numpy())

    return float(np.mean(losses)) if losses else None


def evaluate(model, loader, device):
    y_list = []
    t_list = []
    loss_vals = []

    model.eval()
    with torch.no_grad():
        for q, r, m in loader:
            q = q.long().to(device)
            r = r.long().to(device)
            m = m.to(device)

            p, _ = model(q, r)
            p_masked = torch.masked_select(p, m)
            t_masked = torch.masked_select(r, m).float()

            if p_masked.numel() > 0:
                loss = binary_cross_entropy(p_masked, t_masked)
                loss_vals.append(loss.detach().cpu().numpy())
                y_list.append(p_masked.detach().cpu())
                t_list.append(t_masked.detach().cpu())

    if not y_list:
        return {
            "auc": None,
            "acc@0.5": None,
            "logloss": None,
            "rmse": None,
            "loss": None,
            "n_eval": 0,
        }

    y_scores = torch.cat(y_list).numpy()
    y_true = torch.cat(t_list).numpy()
    n_eval = len(y_true)

    auc = metrics.roc_auc_score(y_true=y_true, y_score=y_scores) if len(np.unique(y_true)) > 1 else None
    acc = ((y_scores >= 0.5).astype(np.int32) == y_true.astype(np.int32)).mean()
    try:
        logloss = metrics.log_loss(y_true=y_true, y_pred=np.clip(y_scores, 1e-6, 1 - 1e-6))
    except ValueError:
        logloss = None

    rmse = float(np.sqrt(metrics.mean_squared_error(y_true, y_scores)))

    loss_mean = float(np.mean(loss_vals)) if loss_vals else None

    return {
        "auc": None if auc is None else float(auc),
        "acc@0.5": float(acc),
        "logloss": None if logloss is None else float(logloss),
        "rmse": float(rmse),
        "loss": None if loss_mean is None else float(loss_mean),
        "n_eval": int(n_eval),
    }


def summarize(values):
    vals = [v for v in values if v is not None]
    if not vals:
        return None, None, 0
    return float(np.mean(vals)), float(np.std(vals)), len(vals)


def main():
    parser = argparse.ArgumentParser(description="K-fold (k=5) evaluation for DKVMN on BePKT (KT).")
    parser.add_argument("--seq-csv-path", type=str, default=None, help="sequence CSV path")
    parser.add_argument("--out-dir", type=str, default=None, help="output dir for maps/checkpoints")
    parser.add_argument("--map-path", type=str, default=None, help="problem_id map path")
    parser.add_argument("--k-folds", type=int, default=5, help="number of folds")
    parser.add_argument("--seed", type=int, default=None, help="random seed")
    parser.add_argument("--num-epochs", type=int, default=None, help="number of epochs")
    parser.add_argument("--lr", type=float, default=None, help="learning rate")
    parser.add_argument("--dim-s", type=int, default=None, help="state dimension")
    parser.add_argument("--size-m", type=int, default=None, help="memory size")
    parser.add_argument("--batch-size", type=int, default=None, help="batch size")
    parser.add_argument("--num-workers", type=int, default=None, help="DataLoader workers")
    parser.add_argument("--prefetch-factor", type=int, default=2, help="DataLoader prefetch factor")
    parser.add_argument("--persistent-workers", action="store_true", help="use DataLoader persistent workers")
    parser.add_argument("--pin-memory", action="store_true", help="use DataLoader pin_memory")
    parser.add_argument("--save-fold-ckpt", action="store_true", help="save best checkpoint per fold")
    parser.add_argument("--gpu", type=str, default="0", help="GPU index")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    cfg = EvalConfig()
    if args.seq_csv_path:
        cfg.seq_csv_path = args.seq_csv_path
    if args.out_dir:
        cfg.out_dir = args.out_dir
    if args.seed is not None:
        cfg.seed = args.seed
    if args.num_epochs is not None:
        cfg.num_epochs = args.num_epochs
    if args.lr is not None:
        cfg.lr = args.lr
    if args.dim_s is not None:
        cfg.dim_s = args.dim_s
    if args.size_m is not None:
        cfg.size_m = args.size_m
    if args.batch_size is not None:
        cfg.batch_size = args.batch_size

    set_seed(cfg.seed)

    out_dir = Path(cfg.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(cfg.seq_csv_path)
    df.columns = [c.strip().lstrip("﻿") for c in df.columns]

    map_path = args.map_path or str(out_dir / "problem_id_map.json")
    if Path(map_path).exists():
        pid2idx, num_q = load_pid_map(map_path)
    else:
        all_probs = sorted({int(p) for seq in df["problem_sequence"].apply(parse_list_col) for p in seq})
        pid2idx = {int(p): i for i, p in enumerate(all_probs)}
        idx2pid = {i: p for p, i in pid2idx.items()}
        num_q = len(pid2idx)
        with open(map_path, "w", encoding="utf-8") as f:
            json.dump({"pid2idx": pid2idx, "idx2pid": idx2pid, "num_q": num_q}, f, ensure_ascii=False, indent=2)

    sequences, skipped = build_sequences(df, pid2idx)
    if not sequences:
        raise ValueError("No usable sequences after filtering.")

    max_len = max(len(q) for q, _ in sequences)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pin_memory = args.pin_memory or device.type == "cuda"
    num_workers = args.num_workers if args.num_workers is not None else 4

    kf = KFold(n_splits=args.k_folds, shuffle=True, random_state=cfg.seed)

    fold_metrics = []
    for fold, (train_idx, val_idx) in enumerate(kf.split(sequences), start=1):
        print(f"\n=== Fold {fold}/{args.k_folds} ===")

        train_seqs = [sequences[i] for i in train_idx]
        val_seqs = [sequences[i] for i in val_idx]

        train_ds = DKVMNDataset(train_seqs, pad_q=cfg.pad_q, pad_r=cfg.pad_r, max_len=max_len)
        val_ds = DKVMNDataset(val_seqs, pad_q=cfg.pad_q, pad_r=cfg.pad_r, max_len=max_len)

        train_loader = build_loader(
            train_ds, cfg.batch_size, True, num_workers, args.prefetch_factor, args.persistent_workers, pin_memory
        )
        val_loader = build_loader(
            val_ds, cfg.batch_size, False, num_workers, args.prefetch_factor, args.persistent_workers, pin_memory
        )

        model = DKVMN(num_q=num_q, dim_s=cfg.dim_s, size_m=cfg.size_m).to(device)
        opt = Adam(model.parameters(), lr=cfg.lr)

        best_auc = -1.0
        best_state = None

        for epoch in range(1, cfg.num_epochs + 1):
            train_loss = train_one_epoch(model, train_loader, device, opt)
            val_stats = evaluate(model, val_loader, device)
            val_auc = val_stats["auc"]
            val_loss = val_stats["loss"]

            loss_msg = f"{train_loss:.4f}" if train_loss is not None else "NA"
            val_auc_msg = f"{val_auc:.4f}" if val_auc is not None else "NA"
            val_loss_msg = f"{val_loss:.4f}" if val_loss is not None else "NA"

            print(f"Epoch {epoch}: train_loss={loss_msg} val_auc={val_auc_msg} val_loss={val_loss_msg}")

            if val_auc is not None and val_auc > best_auc:
                best_auc = val_auc
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        if best_state is not None:
            model.load_state_dict(best_state)

        final_stats = evaluate(model, val_loader, device)
        fold_metrics.append(final_stats)

        if args.save_fold_ckpt and best_state is not None:
            fold_dir = out_dir / f"fold_{fold}"
            fold_dir.mkdir(parents=True, exist_ok=True)
            torch.save(best_state, fold_dir / "model.ckpt")

        fmt = lambda v: f"{v:.4f}" if v is not None else "NA"
        print(
            f"[Fold {fold}] AUC={fmt(final_stats['auc'])} ACC@0.5={fmt(final_stats['acc@0.5'])} "
            f"LOGLOSS={fmt(final_stats['logloss'])} RMSE={fmt(final_stats['rmse'])} n_eval={final_stats['n_eval']}"
        )

    auc_mean, auc_std, auc_n = summarize([m["auc"] for m in fold_metrics])
    acc_mean, acc_std, acc_n = summarize([m["acc@0.5"] for m in fold_metrics])
    logloss_mean, logloss_std, logloss_n = summarize([m["logloss"] for m in fold_metrics])
    rmse_mean, rmse_std, rmse_n = summarize([m["rmse"] for m in fold_metrics])

    fmt = lambda v: f"{v:.4f}" if v is not None else "NA"
    print("\n=== K-Fold Summary ===")
    print(f"AUC: mean={fmt(auc_mean)} std={fmt(auc_std)} n={auc_n}")
    print(f"ACC@0.5: mean={fmt(acc_mean)} std={fmt(acc_std)} n={acc_n}")
    print(f"LOGLOSS: mean={fmt(logloss_mean)} std={fmt(logloss_std)} n={logloss_n}")
    print(f"RMSE: mean={fmt(rmse_mean)} std={fmt(rmse_std)} n={rmse_n}")

    skipped_total = sum(skipped.values())
    print(
        f"[Data] total_sequences={len(sequences)} skipped={skipped_total} "
        f"(unknown_pid={skipped['unknown_pid']} too_short={skipped['too_short']} mismatch={skipped['length_mismatch']})"
    )


if __name__ == "__main__":
    main()
