import sys
import os
import argparse


def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

for _thread_key in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "BLIS_NUM_THREADS",
):
    os.environ.setdefault(_thread_key, "1")

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
repo_root = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
akt_dir = os.path.join(repo_root, "models", "AKT")
sys.path.insert(0, akt_dir)

import json
import ast
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import Adam
from sklearn import metrics
import torch.nn.functional as F

from akt import AKT
from micro_utils import load_micro_embedding
from rec_utils import (
    RecDataset,
    build_loader as build_rec_loader,
    collate_rec_batch,
    load_rec_examples,
    split_examples,
)

torch.set_num_threads(int(os.environ.get("TORCH_NUM_THREADS", os.environ.get("OMP_NUM_THREADS", "1"))))
try:
    torch.set_num_interop_threads(int(os.environ.get("TORCH_NUM_INTEROP_THREADS", "1")))
except RuntimeError:
    pass


@dataclass
class TrainConfig:
    seq_csv_path: str = "./CSEDM/BePKT/remapped_data/user_index_mapped_filteringQ4(17)_remapped.csv"
    out_dir: str = "./kt_collection/checkpoints/akt_bepkt"
    seed: int = 42

    d_model: int = 256
    d_ff: int = 1024
    n_block: int = 1
    n_head: int = 8
    kq_same: int = 1
    dropout: float = 0.05
    l2: float = 1e-5

    batch_size: int = 64
    num_epochs: int = 20
    lr: float = 1e-3
    val_ratio: float = 0.1

    max_seq_len: int = 0
    pad_q: int = 0
    pad_r: int = 0


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_list_col(x):
    if isinstance(x, list):
        return x
    return ast.literal_eval(x)


def load_user_split(path: str):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return {
        "train": {str(u) for u in payload["train_user_ids"]},
        "val": {str(u) for u in payload["val_user_ids"]},
        "test": {str(u) for u in payload["test_user_ids"]},
    }


def split_sequences_random(sequences, val_ratio, seed):
    rng = random.Random(seed)
    seqs = list(sequences)
    rng.shuffle(seqs)
    n_val = int(len(seqs) * val_ratio)
    return seqs[n_val:], seqs[:n_val]


def split_sequences_stratified(sequences, val_ratio, seed, bins=5):
    rng = random.Random(seed)
    lengths = [len(q) for q, _ in sequences]
    if len(sequences) < bins:
        return split_sequences_random(sequences, val_ratio, seed)
    quantiles = np.linspace(0, 1, bins + 1)
    edges = np.quantile(lengths, quantiles)
    edges = np.unique(edges)
    if len(edges) <= 2:
        return split_sequences_random(sequences, val_ratio, seed)
    groups = [[] for _ in range(len(edges) - 1)]
    for seq, L in zip(sequences, lengths):
        idx = np.searchsorted(edges, L, side="right") - 1
        idx = max(0, min(idx, len(groups) - 1))
        groups[idx].append(seq)
    train, val = [], []
    for g in groups:
        rng.shuffle(g)
        n_val = int(len(g) * val_ratio)
        val.extend(g[:n_val])
        train.extend(g[n_val:])
    return train, val


def compute_pos_weight(sequences, target_only_last=False):
    pos = 0
    neg = 0
    for _, r in sequences:
        if len(r) < 2:
            continue
        values = [r[-1]] if target_only_last else r[1:]
        for x in values:
            if int(x) == 1:
                pos += 1
            else:
                neg += 1
    if pos == 0:
        return None
    return float(neg) / float(pos)


def select_best_f1_threshold(y_true_np, y_pred_np):
    precision, recall, thresholds = metrics.precision_recall_curve(
        y_true_np.astype(np.int64), y_pred_np
    )
    if thresholds.size == 0:
        thr = 0.5
        pred_labels = (y_pred_np >= thr).astype(np.int64)
        f1 = metrics.f1_score(y_true_np.astype(np.int64), pred_labels, zero_division=0)
        return float(thr), float(f1)
    f1_scores = 2 * precision[:-1] * recall[:-1] / np.clip(precision[:-1] + recall[:-1], 1e-12, None)
    best_idx = int(np.nanargmax(f1_scores))
    return float(thresholds[best_idx]), float(f1_scores[best_idx])


def build_loader(dataset, batch_size, shuffle, num_workers, prefetch_factor, persistent_workers, pin_memory):
    kwargs = {
        "batch_size": batch_size,
        "shuffle": shuffle,
        "drop_last": False,
        "num_workers": num_workers,
    }
    if num_workers > 0:
        kwargs["prefetch_factor"] = prefetch_factor
        kwargs["persistent_workers"] = persistent_workers
    if pin_memory:
        kwargs["pin_memory"] = True
    return DataLoader(dataset, **kwargs)


class AKTDataset(Dataset):
    def __init__(self, sequences, n_question, max_len, target_only_last=False):
        self.sequences = sequences
        self.n_question = n_question
        self.max_len = max_len
        self.target_only_last = target_only_last

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        q, r = self.sequences[idx]
        if self.max_len and len(q) > self.max_len:
            q = q[-self.max_len :]
            r = r[-self.max_len :]
        seq_len = len(q)

        q_pad = np.zeros((self.max_len,), dtype=np.int64)
        qa_pad = np.zeros((self.max_len,), dtype=np.int64)
        target = np.full((self.max_len,), -1, dtype=np.float32)

        if seq_len > 0:
            q_pad[:seq_len] = q
            qa_pad[:seq_len] = [qq + rr * self.n_question for qq, rr in zip(q, r)]
            target[:seq_len] = r
            if self.target_only_last:
                last_target = target[seq_len - 1]
                target[:] = -1
                target[seq_len - 1] = last_target

        return (
            torch.from_numpy(q_pad),
            torch.from_numpy(qa_pad),
            torch.from_numpy(target),
        )


def _prepare_history(q_row, r_row, length, max_hist_len):
    q_hist = q_row[:length].tolist()
    r_hist = r_row[:length].tolist()
    if max_hist_len is not None and max_hist_len > 0 and len(q_hist) > max_hist_len:
        q_hist = q_hist[-max_hist_len:]
        r_hist = r_hist[-max_hist_len:]
    return q_hist, r_hist


def score_candidates_tensor(model, q_hist, r_hist, candidates, n_question, max_seq_len, device, candidate_batch):
    if max_seq_len is None or max_seq_len <= 0:
        max_seq_len = len(q_hist) + 1
    max_hist_len = max_seq_len - 1
    if max_hist_len < 0:
        max_hist_len = 0
    if len(q_hist) > max_hist_len:
        q_hist = q_hist[-max_hist_len:]
        r_hist = r_hist[-max_hist_len:]
    hist_len = len(q_hist)
    pos = hist_len

    if hist_len > 0:
        q_hist_t = torch.tensor(q_hist, dtype=torch.long, device=device)
        qa_hist_t = torch.tensor(
            [qq + rr * n_question for qq, rr in zip(q_hist, r_hist)],
            dtype=torch.long,
            device=device,
        )
        r_hist_t = torch.tensor(r_hist, dtype=torch.float32, device=device)
    else:
        q_hist_t = None
        qa_hist_t = None
        r_hist_t = None

    scores = []
    for start in range(0, len(candidates), candidate_batch):
        cand_batch = candidates[start : start + candidate_batch]
        bsz = len(cand_batch)
        q_pad = torch.zeros((bsz, max_seq_len), dtype=torch.long, device=device)
        qa_pad = torch.zeros_like(q_pad)
        target_pad = torch.full((bsz, max_seq_len), -1.0, dtype=torch.float32, device=device)

        if hist_len > 0:
            q_pad[:, :hist_len] = q_hist_t.unsqueeze(0).expand(bsz, -1)
            qa_pad[:, :hist_len] = qa_hist_t.unsqueeze(0).expand(bsz, -1)
            target_pad[:, :hist_len] = r_hist_t.unsqueeze(0).expand(bsz, -1)

        cand_t = torch.tensor(cand_batch, dtype=torch.long, device=device)
        q_pad[:, pos] = cand_t
        qa_pad[:, pos] = cand_t
        target_pad[:, pos] = 0.0

        _, preds, _ = model(q_pad, qa_pad, target_pad)
        preds = preds.view(bsz, -1)
        scores.append(preds[:, pos])

    return torch.cat(scores, dim=0)


def train_kt(
    model, train_loader, val_loader, opt, device, num_epochs, ckpt_path,
    contrastive_weight: float = 0.0, contrastive_temp: float = 0.1,
    early_stop_metric: str = "auc", early_stop_patience: int = 5,
    early_stop_min_delta: float = 0.0005, early_stop_threshold: float = 0.5,
    early_stop_threshold_mode: str = "fixed", meta_path: str | None = None,
):
    best_metric = None
    best_auc = None
    best_f1 = None
    best_precision = None
    best_recall = None
    best_threshold = early_stop_threshold
    best_epoch = None
    patience = 0
    for epoch in range(1, num_epochs + 1):
        model.train()
        losses = []
        for q, qa, target in train_loader:
            q = q.to(device)
            qa = qa.to(device)
            target = target.to(device)

            loss, _, ct = model(q, qa, target)
            ct = ct.float().clamp(min=1.0)
            loss = loss / ct
            if model.micro_mode == "contrastive" and contrastive_weight > 0:
                q_ids = q[target > -0.9]
                if q_ids.numel() > 0:
                    c_loss = model.contrastive_loss(q_ids, temperature=contrastive_temp)
                    if c_loss is not None:
                        loss = loss + contrastive_weight * c_loss

            opt.zero_grad()
            loss.backward()
            opt.step()

            losses.append(loss.detach().cpu().item())

        model.eval()
        y_pred = []
        y_true = []
        with torch.no_grad():
            for q, qa, target in val_loader:
                q = q.to(device)
                qa = qa.to(device)
                target = target.to(device)

                _, preds, _ = model(q, qa, target)
                preds = preds.view(q.size(0), -1)
                mask = target > -0.9
                if mask.sum() == 0:
                    continue
                y_pred.append(preds[mask].detach().cpu())
                y_true.append(target[mask].detach().cpu())

        auc = None
        f1 = None
        if y_pred:
            y_pred_np = torch.cat(y_pred).numpy()
            y_true_np = torch.cat(y_true).numpy()
            if len(np.unique(y_true_np)) > 1:
                auc = metrics.roc_auc_score(y_true_np, y_pred_np)
            threshold = early_stop_threshold
            if early_stop_threshold_mode == "val_best":
                threshold, _ = select_best_f1_threshold(y_true_np, y_pred_np)
            pred_label_np = (y_pred_np >= threshold).astype(np.int64)
            f1 = metrics.f1_score(y_true_np.astype(np.int64), pred_label_np, zero_division=0)
            precision, recall, _f1_unused, _ = metrics.precision_recall_fscore_support(
                y_true_np.astype(np.int64), pred_label_np, average="binary", zero_division=0
            )
        else:
            threshold = early_stop_threshold

        mean_loss = float(np.mean(losses)) if losses else 0.0
        print(
            f"Epoch {epoch}: train_loss={mean_loss:.4f} "
            f"val_auc={auc if auc is not None else 'NA'} "
            f"val_f1@{threshold:.4f}={f1 if f1 is not None else 'NA'}"
        )

        metric = auc if early_stop_metric == "auc" else f1
        if metric is None:
            continue
        if best_metric is None:
            improved = True
        else:
            improved = metric > best_metric + early_stop_min_delta
        if improved:
            best_metric = metric
            best_auc = auc
            best_f1 = f1
            best_precision = float(precision) if f1 is not None else None
            best_recall = float(recall) if f1 is not None else None
            best_threshold = float(threshold)
            best_epoch = epoch
            patience = 0
            torch.save(model.state_dict(), ckpt_path)
        else:
            patience += 1
            if patience >= early_stop_patience:
                print(f"[EarlyStop] stopped at epoch {epoch}")
                break

    payload = {
        "best_metric": best_metric,
        "best_auc": best_auc,
        "best_f1": best_f1,
        "best_precision": best_precision,
        "best_recall": best_recall,
        "best_threshold": best_threshold,
        "best_epoch": best_epoch,
    }
    if meta_path:
        Path(meta_path).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload


def train_rec(model, train_loader, val_loader, opt, device, n_question, max_seq_len, candidate_batch, num_epochs, ckpt_path):
    best_hit = -1.0
    eps = 1e-6

    for epoch in range(1, num_epochs + 1):
        model.train()
        losses = []
        for q, r, cand, cand_mask, lengths, target_pos in train_loader:
            valid_items = []
            for i in range(q.size(0)):
                length = int(lengths[i].item())
                if length <= 0:
                    continue

                cand_row = cand[i][cand_mask[i]].tolist()
                if not cand_row:
                    continue

                valid_items.append((i, length, cand_row))

            if not valid_items:
                continue

            opt.zero_grad()
            num_valid = len(valid_items)
            batch_loss_sum = 0.0
            for i, length, cand_row in valid_items:
                q_hist, r_hist = _prepare_history(q[i], r[i], length, max_seq_len - 1)
                scores_i = score_candidates_tensor(
                    model,
                    q_hist,
                    r_hist,
                    cand_row,
                    n_question,
                    max_seq_len,
                    device,
                    candidate_batch,
                )
                scores_i = torch.logit(scores_i.clamp(min=eps, max=1 - eps))
                target_i = torch.tensor([int(target_pos[i].item())], dtype=torch.long, device=device)
                loss_i = F.cross_entropy(scores_i.unsqueeze(0), target_i)
                (loss_i / num_valid).backward()
                batch_loss_sum += loss_i.detach().cpu().item()

            opt.step()
            losses.append(batch_loss_sum / num_valid)

        model.eval()
        hit1 = 0
        total = 0
        with torch.no_grad():
            for q, r, cand, cand_mask, lengths, target_pos in val_loader:
                for i in range(q.size(0)):
                    length = int(lengths[i].item())
                    if length <= 0:
                        continue

                    cand_row = cand[i][cand_mask[i]].tolist()
                    if not cand_row:
                        continue

                    q_hist, r_hist = _prepare_history(q[i], r[i], length, max_seq_len - 1)
                    scores_i = score_candidates_tensor(
                        model,
                        q_hist,
                        r_hist,
                        cand_row,
                        n_question,
                        max_seq_len,
                        device,
                        candidate_batch,
                    )
                    pred_idx = int(scores_i.argmax().item())
                    if pred_idx == int(target_pos[i].item()):
                        hit1 += 1
                    total += 1

        hit1_rate = hit1 / total if total else 0.0
        mean_loss = float(np.mean(losses)) if losses else 0.0
        print(f"Epoch {epoch}: rec_hit@1={hit1_rate:.4f} loss_mean={mean_loss:.4f}")

        if hit1_rate > best_hit:
            torch.save(model.state_dict(), ckpt_path)
            best_hit = hit1_rate

    return best_hit


def main():
    parser = argparse.ArgumentParser(description="Train AKT on BePKT (KT or Recommendation).")
    parser.add_argument("--task", choices=["kt", "rec"], default="kt", help="training task")
    parser.add_argument("--gpu", type=str, default="0", help="GPU index")
    parser.add_argument("--seed", type=int, default=None, help="random seed override")
    parser.add_argument("--seq-csv-path", type=str, default=None, help="sequence CSV path")
    parser.add_argument(
        "--benchmark-dir",
        type=str,
        default="./CSEDM/BePKT/remapped_benchmark",
        help="benchmark dir for recommendation",
    )
    parser.add_argument("--train-benchmark-dir", type=str, default=None, help="train benchmark dir")
    parser.add_argument("--val-benchmark-dir", type=str, default=None, help="val benchmark dir")
    parser.add_argument("--k-list", type=str, default="10,20,30,40,50", help="K list for benchmark")
    parser.add_argument("--max-candidates", type=int, default=200, help="max candidates per example")
    parser.add_argument("--use-all-candidates", action="store_true", help="use all problems as candidates")
    parser.add_argument("--out-dir", type=str, default=None, help="output dir")
    parser.add_argument("--batch-size", type=int, default=None, help="batch size")
    parser.add_argument("--num-workers", type=int, default=None, help="DataLoader workers")
    parser.add_argument("--prefetch-factor", type=int, default=2, help="DataLoader prefetch factor")
    parser.add_argument("--persistent-workers", action="store_true", help="use persistent workers")
    parser.add_argument("--pin-memory", action="store_true", help="use pin_memory")
    parser.add_argument("--stratify-users", action="store_true", help="stratify split by sequence length bins")
    parser.add_argument("--stratify-bins", type=int, default=5, help="number of bins for stratified split")
    parser.add_argument("--split-json", type=str, default=None, help="fixed user split JSON for KT task")
    parser.add_argument("--auto-pos-weight", action="store_true", help="use neg/pos ratio as positive class weight")
    parser.add_argument("--micro-mode", choices=["none", "replace", "concat", "contrastive"], default="none")
    parser.add_argument("--micro-emb", type=str, default=None, help="micro-concept embedding .pt path")
    parser.add_argument("--micro-pro-id-dict", type=str, default=None, help="problem id dict path for micro emb")
    parser.add_argument("--contrastive-weight", type=float, default=0.1, help="contrastive loss weight")
    parser.add_argument("--contrastive-temp", type=float, default=0.1, help="contrastive loss temperature")
    parser.add_argument("--max-seq-len", type=int, default=None, help="truncate max sequence length")
    parser.add_argument("--candidate-batch", type=int, default=64, help="candidate batch for rec scoring")

    parser.add_argument("--d-model", type=int, default=None, help="AKT d_model")
    parser.add_argument("--d-ff", type=int, default=None, help="AKT d_ff")
    parser.add_argument("--n-block", type=int, default=None, help="AKT n_block")
    parser.add_argument("--n-head", type=int, default=None, help="AKT n_head")
    parser.add_argument("--kq-same", type=int, default=None, help="AKT kq_same")
    parser.add_argument("--dropout", type=float, default=None, help="AKT dropout")
    parser.add_argument("--l2", type=float, default=None, help="AKT l2")
    parser.add_argument("--lr", type=float, default=None, help="learning rate")
    parser.add_argument("--num-epochs", type=int, default=None, help="num epochs")
    parser.add_argument("--early-stop-metric", choices=["auc", "f1"], default="auc")
    parser.add_argument("--early-stop-patience", type=int, default=5)
    parser.add_argument("--early-stop-min-delta", type=float, default=0.0005)
    parser.add_argument("--early-stop-threshold", type=float, default=0.5)
    parser.add_argument("--early-stop-threshold-mode", choices=["fixed", "val_best"], default="fixed")
    parser.add_argument("--target-only-last", action="store_true", help="supervise only the final target in each sequence")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    cfg = TrainConfig()
    if args.seq_csv_path:
        cfg.seq_csv_path = args.seq_csv_path
    if args.out_dir:
        cfg.out_dir = args.out_dir
    if args.batch_size is not None:
        cfg.batch_size = args.batch_size
    if args.max_seq_len is not None:
        cfg.max_seq_len = args.max_seq_len
    if args.d_model is not None:
        cfg.d_model = args.d_model
    if args.d_ff is not None:
        cfg.d_ff = args.d_ff
    if args.n_block is not None:
        cfg.n_block = args.n_block
    if args.n_head is not None:
        cfg.n_head = args.n_head
    if args.kq_same is not None:
        cfg.kq_same = args.kq_same
    if args.dropout is not None:
        cfg.dropout = args.dropout
    if args.l2 is not None:
        cfg.l2 = args.l2
    if args.lr is not None:
        cfg.lr = args.lr
    if args.num_epochs is not None:
        cfg.num_epochs = args.num_epochs
    if args.seed is not None:
        cfg.seed = args.seed

    if args.task == "rec" and args.max_seq_len is None:
        cfg.max_seq_len = 200
        print("[Info] max_seq_len not set; using 200 for rec. Override with --max-seq-len.")

    set_seed(cfg.seed)
    Path(cfg.out_dir).mkdir(parents=True, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pin_memory = args.pin_memory or device.type == "cuda"
    num_workers = args.num_workers if args.num_workers is not None else 4

    df = pd.read_csv(cfg.seq_csv_path)
    df.columns = [c.strip().lstrip("\ufeff") for c in df.columns]

    df["problem_sequence"] = df["problem_sequence"].apply(parse_list_col)
    df["result_sequence"] = df["result_sequence"].apply(parse_list_col)

    all_probs = sorted({p for seq in df["problem_sequence"] for p in seq})
    pid2idx = {int(p): i + 1 for i, p in enumerate(all_probs)}
    idx2pid = {i: p for p, i in pid2idx.items()}
    num_q = len(pid2idx) + 1

    micro_emb = None
    if args.micro_mode != "none":
        if not args.micro_emb or not args.micro_pro_id_dict:
            raise ValueError("micro_mode requires --micro-emb and --micro-pro-id-dict")
        micro_emb, missing = load_micro_embedding(
            args.micro_emb, args.micro_pro_id_dict, pid2idx, num_q=num_q, pad_idx=0
        )
        if missing:
            print(f"[micro] missing problem ids: {missing}")
    n_question = num_q - 1

    user_sequences = []
    for _, row in df.iterrows():
        user_id = str(row["user"])
        q = [pid2idx[int(p)] for p in row["problem_sequence"]]
        r = [int(x) for x in row["result_sequence"]]
        if len(q) >= 2:
            user_sequences.append((user_id, q, r))
    sequences = [(q, r) for _, q, r in user_sequences]

    if args.split_json:
        split_users = load_user_split(args.split_json)
        train_seqs = [(q, r) for user_id, q, r in user_sequences if user_id in split_users["train"]]
        val_seqs = [(q, r) for user_id, q, r in user_sequences if user_id in split_users["val"]]
    elif args.stratify_users:
        train_seqs, val_seqs = split_sequences_stratified(
            sequences, cfg.val_ratio, seed=cfg.seed, bins=args.stratify_bins
        )
    else:
        train_seqs, val_seqs = split_sequences_random(sequences, cfg.val_ratio, seed=cfg.seed)

    max_len = max(max(len(q) for q, _ in train_seqs), max(len(q) for q, _ in val_seqs))
    if cfg.max_seq_len and max_len > cfg.max_seq_len:
        max_len = cfg.max_seq_len

    map_path = Path(cfg.out_dir) / "problem_id_map.json"
    with map_path.open("w", encoding="utf-8") as f:
        json.dump(
            {"pid2idx": pid2idx, "idx2pid": idx2pid, "num_q": num_q, "n": max_len},
            f,
            ensure_ascii=False,
            indent=2,
        )

    pos_weight = compute_pos_weight(train_seqs, target_only_last=args.target_only_last) if args.auto_pos_weight else None

    model = AKT(
        n_question=n_question,
        n_pid=0,
        n_blocks=cfg.n_block,
        d_model=cfg.d_model,
        kq_same=cfg.kq_same,
        dropout=cfg.dropout,
        model_type="akt",
        n_heads=cfg.n_head,
        d_ff=cfg.d_ff,
        l2=cfg.l2,
        micro_emb=micro_emb,
        micro_mode=args.micro_mode,
    ).to(device)
    if pos_weight is not None:
        model.pos_weight = torch.tensor([pos_weight], device=device)
    opt = Adam(model.parameters(), lr=cfg.lr)

    if args.task == "kt":
        train_ds = AKTDataset(train_seqs, n_question=n_question, max_len=max_len, target_only_last=args.target_only_last)
        val_ds = AKTDataset(val_seqs, n_question=n_question, max_len=max_len, target_only_last=args.target_only_last)

        train_loader = build_loader(
            train_ds, cfg.batch_size, True, num_workers, args.prefetch_factor, args.persistent_workers, pin_memory
        )
        val_loader = build_loader(
            val_ds, cfg.batch_size, False, num_workers, args.prefetch_factor, args.persistent_workers, pin_memory
        )

        ckpt_path = str(Path(cfg.out_dir) / "model.ckpt")
        best_stats = train_kt(
            model,
            train_loader,
            val_loader,
            opt,
            device,
            cfg.num_epochs,
            ckpt_path,
            contrastive_weight=args.contrastive_weight if args.micro_mode == "contrastive" else 0.0,
            contrastive_temp=args.contrastive_temp,
            early_stop_metric=args.early_stop_metric,
            early_stop_patience=args.early_stop_patience,
            early_stop_min_delta=args.early_stop_min_delta,
            early_stop_threshold=args.early_stop_threshold,
            early_stop_threshold_mode=args.early_stop_threshold_mode,
            meta_path=str(Path(cfg.out_dir) / "train_result.json"),
        )
        print(f"Best val AUC: {best_stats['best_auc'] if best_stats['best_auc'] is not None else 'NA'}")
        print(f"Best val F1: {best_stats['best_f1'] if best_stats['best_f1'] is not None else 'NA'}")
        print(f"Saved checkpoint to: {ckpt_path}")
    else:
        k_list = [int(k.strip()) for k in args.k_list.split(",") if k.strip()]
        train_dir = Path(args.train_benchmark_dir) if args.train_benchmark_dir else Path(args.benchmark_dir)
        val_dir = Path(args.val_benchmark_dir) if args.val_benchmark_dir else None

        for label, dir_path in (("train", train_dir), ("val", val_dir)):
            if dir_path is None:
                continue
            if not dir_path.exists():
                raise FileNotFoundError(f"{label} benchmark_dir not found: {dir_path.resolve()}")
            expected = [dir_path / f"benchmark_K{k}.jsonl" for k in k_list]
            if not any(p.exists() for p in expected):
                raise FileNotFoundError(
                    f"No benchmark_K*.jsonl found in {dir_path.resolve()} for k_list={k_list}"
                )

        if val_dir:
            train_ex, skipped_train = load_rec_examples(
                train_dir,
                k_list,
                pid2idx,
                max_seq_len=max_len - 1,
                max_candidates=args.max_candidates,
                seed=cfg.seed,
                use_all_candidates=args.use_all_candidates,
            )
            val_ex, skipped_val = load_rec_examples(
                val_dir,
                k_list,
                pid2idx,
                max_seq_len=max_len - 1,
                max_candidates=args.max_candidates,
                seed=cfg.seed,
                use_all_candidates=args.use_all_candidates,
            )
            if not train_ex or not val_ex:
                raise ValueError(
                    "No recommendation examples loaded. Check train/val benchmark dirs and problem_id mapping."
                )
            if skipped_train:
                print(f"[Info] skipped {skipped_train} rec train examples")
            if skipped_val:
                print(f"[Info] skipped {skipped_val} rec val examples")
        else:
            examples, skipped = load_rec_examples(
                train_dir,
                k_list,
                pid2idx,
                max_seq_len=max_len - 1,
                max_candidates=args.max_candidates,
                seed=cfg.seed,
                use_all_candidates=args.use_all_candidates,
            )
            if not examples:
                raise ValueError(
                    "No recommendation examples loaded. Check benchmark_dir, k_list, and problem_id mapping."
                )
            if skipped:
                print(f"[Info] skipped {skipped} rec examples")

            train_ex, val_ex = split_examples(examples, cfg.val_ratio, seed=cfg.seed)

        rec_train_loader = build_rec_loader(
            RecDataset(train_ex),
            cfg.batch_size,
            True,
            num_workers,
            args.prefetch_factor,
            args.persistent_workers,
            pin_memory,
            collate_fn=lambda b: collate_rec_batch(
                b, pad_q=0, pad_r=0, pad_cand=0, fixed_len=max_len - 1, pad_left=False
            ),
        )
        rec_val_loader = build_rec_loader(
            RecDataset(val_ex),
            cfg.batch_size,
            False,
            num_workers,
            args.prefetch_factor,
            args.persistent_workers,
            pin_memory,
            collate_fn=lambda b: collate_rec_batch(
                b, pad_q=0, pad_r=0, pad_cand=0, fixed_len=max_len - 1, pad_left=False
            ),
        )

        rec_ckpt = str(Path(cfg.out_dir) / "model_rec.ckpt")
        train_rec(
            model,
            rec_train_loader,
            rec_val_loader,
            opt,
            device,
            n_question,
            max_len,
            args.candidate_batch,
            cfg.num_epochs,
            rec_ckpt,
        )
        print(f"Saved recommendation checkpoint to: {rec_ckpt}")

    print(f"Saved problem id map to: {map_path}")


if __name__ == "__main__":
    main()
