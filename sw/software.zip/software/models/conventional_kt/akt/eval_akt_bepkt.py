import sys
import os
import argparse


def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
repo_root = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
akt_dir = os.path.join(repo_root, "models", "AKT")
sys.path.insert(0, akt_dir)

import json
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import torch
from sklearn import metrics

from akt import AKT


def load_pid_map(map_path: str) -> Tuple[Dict[int, int], int, int]:
    with open(map_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}
    num_q = int(m.get("num_q", len(pid2idx) + 1))
    max_len = int(m.get("n", m.get("seqlen", 200)))
    return pid2idx, num_q, max_len


def _truncate_hist(q_hist, r_hist, max_len):
    if max_len is None or max_len <= 1:
        return q_hist, r_hist
    max_hist = max_len - 1
    if len(q_hist) > max_hist:
        q_hist = q_hist[-max_hist:]
        r_hist = r_hist[-max_hist:]
    return q_hist, r_hist


def score_candidates(
    model: AKT,
    q_hist,
    r_hist,
    candidates,
    n_question: int,
    max_len: int,
    device: torch.device,
    candidate_batch: int,
):
    if max_len is None or max_len <= 0:
        max_len = len(q_hist) + 1

    q_hist, r_hist = _truncate_hist(q_hist, r_hist, max_len)
    hist_len = len(q_hist)
    pos = hist_len

    if hist_len > 0:
        q_hist_t = torch.tensor(q_hist, dtype=torch.long, device=device)
        qa_hist_t = torch.tensor(
            [qq + rr * n_question for qq, rr in zip(q_hist, r_hist)],
            dtype=torch.long,
            device=device,
        )
        r_hist_t = torch.tensor(r_hist, dtype=torch.float32, device=device)
    else:
        q_hist_t = None
        qa_hist_t = None
        r_hist_t = None

    probs = []
    for start in range(0, len(candidates), candidate_batch):
        cand_batch = candidates[start : start + candidate_batch]
        bsz = len(cand_batch)

        q_pad = torch.zeros((bsz, max_len), dtype=torch.long, device=device)
        qa_pad = torch.zeros_like(q_pad)
        target_pad = torch.full((bsz, max_len), -1.0, dtype=torch.float32, device=device)

        if hist_len > 0:
            q_pad[:, :hist_len] = q_hist_t.unsqueeze(0).expand(bsz, -1)
            qa_pad[:, :hist_len] = qa_hist_t.unsqueeze(0).expand(bsz, -1)
            target_pad[:, :hist_len] = r_hist_t.unsqueeze(0).expand(bsz, -1)

        cand_t = torch.tensor(cand_batch, dtype=torch.long, device=device)
        q_pad[:, pos] = cand_t
        qa_pad[:, pos] = cand_t
        target_pad[:, pos] = 0.0

        _, preds, _ = model(q_pad, qa_pad, target_pad)
        preds = preds.view(bsz, -1)
        probs.extend(preds[:, pos].detach().cpu().numpy().tolist())

    return probs


def eval_auc(model, pid2idx, jsonl_path: Path, n_question: int, max_len: int, device: torch.device, candidate_batch: int):
    y_scores = []
    y_true = []
    n_skipped = 0

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            ex = json.loads(line)

            seq = ex["input_sequence"]
            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))

            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q_hist, r_hist = [], []
            ok = True
            for s in seq:
                pid = int(s["problem_id"])
                if pid not in pid2idx:
                    ok = False
                    break
                q_hist.append(pid2idx[pid])
                r_hist.append(int(s["result"]))
            if not ok or len(q_hist) == 0:
                n_skipped += 1
                continue

            tgt_idx = pid2idx[target_pid]
            prob = score_candidates(
                model,
                q_hist,
                r_hist,
                [tgt_idx],
                n_question,
                max_len,
                device,
                candidate_batch,
            )[0]

            y_scores.append(prob)
            y_true.append(target_r)

    if not y_true:
        return {"auc": None, "acc@0.5": None, "logloss": None, "n_eval": 0, "n_skipped": n_skipped}

    y_scores = np.array(y_scores, dtype=np.float32)
    y_true = np.array(y_true, dtype=np.int32)

    auc = metrics.roc_auc_score(y_true=y_true, y_score=y_scores) if len(np.unique(y_true)) > 1 else None
    acc = ((y_scores >= 0.5).astype(np.int32) == y_true).mean()
    ll = metrics.log_loss(y_true=y_true, y_pred=np.clip(y_scores, 1e-6, 1 - 1e-6))

    return {
        "auc": None if auc is None else float(auc),
        "acc@0.5": float(acc),
        "logloss": float(ll),
        "n_eval": int(len(y_true)),
        "n_skipped": int(n_skipped),
    }


def hit_at_k(rank_pos: int, k: int) -> float:
    return 1.0 if rank_pos <= k else 0.0


def ndcg_at_k(rank_pos: int, k: int) -> float:
    if rank_pos <= k:
        return 1.0 / np.log2(rank_pos + 1)
    return 0.0


@torch.no_grad()
def eval_topk_candidates(
    model: AKT,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    n_question: int,
    max_len: int,
    device: torch.device,
    ks=(1, 3, 5, 10),
    only_when_target_correct: bool = False,
    use_candidates: bool = True,
    candidate_batch: int = 128,
    max_candidates: int = 0,
):
    ks = sorted(set(ks))
    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}
    n_eval = 0
    n_skipped = 0

    all_candidates = list(range(1, n_question + 1))

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            ex = json.loads(line)

            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))

            if target_pid not in pid2idx:
                n_skipped += 1
                continue
            if only_when_target_correct and target_r != 1:
                continue

            q_hist, r_hist = [], []
            ok = True
            for s in ex["input_sequence"]:
                pid = int(s["problem_id"])
                if pid not in pid2idx:
                    ok = False
                    break
                q_hist.append(pid2idx[pid])
                r_hist.append(int(s["result"]))

            if not ok or len(q_hist) == 0:
                n_skipped += 1
                continue

            if use_candidates:
                cand_raw = ex.get("candidate_problems")
                if not isinstance(cand_raw, list):
                    n_skipped += 1
                    continue
                candidates = [pid2idx[int(pid)] for pid in cand_raw if int(pid) in pid2idx]
            else:
                candidates = list(all_candidates)

            tgt = pid2idx[target_pid]
            if tgt not in candidates:
                candidates.append(tgt)

            if max_candidates and len(candidates) > max_candidates:
                rng = np.random.default_rng(42)
                others = [c for c in candidates if c != tgt]
                keep = rng.choice(others, size=max_candidates - 1, replace=False).tolist()
                candidates = keep + [tgt]

            scores = score_candidates(
                model,
                q_hist,
                r_hist,
                candidates,
                n_question,
                max_len,
                device,
                candidate_batch,
            )

            sorted_idx = np.argsort(-np.array(scores))
            rank_pos = np.where(sorted_idx == candidates.index(tgt))[0]
            rank_pos = int(rank_pos[0]) + 1 if rank_pos.size > 0 else 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)

            n_eval += 1

    out = {"n_eval": n_eval, "n_skipped": n_skipped}
    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out

    for k in ks:
        out[f"Hit@{k}"] = sums_hit[k] / n_eval
        out[f"NDCG@{k}"] = sums_ndcg[k] / n_eval
    return out


def main():
    parser = argparse.ArgumentParser(description="Evaluate AKT on BePKT.")
    parser.add_argument("--gpu", type=str, default="0", help="GPU index")
    parser.add_argument("--model-ckpt", type=str, default="./kt_collection/checkpoints/akt_bepkt/model.ckpt")
    parser.add_argument("--map-path", type=str, default="./kt_collection/checkpoints/akt_bepkt/problem_id_map.json")
    parser.add_argument("--benchmark-dir", type=str, default="./CSEDM/BePKT/remapped_benchmark")
    parser.add_argument("--k-list", type=str, default="10,20,30,40,50", help="K list to evaluate")
    parser.add_argument("--only-correct-target", action="store_true", help="evaluate only target_result==1")
    parser.add_argument(
        "--eval-scope",
        choices=["full", "candidate"],
        default="full",
        help="recommendation scope",
    )
    parser.add_argument("--use-candidate-problems", action="store_true", help="deprecated: use eval-scope")
    parser.add_argument("--max-candidates", type=int, default=0, help="limit candidate size")
    parser.add_argument("--candidate-batch", type=int, default=128, help="candidate batch size")

    parser.add_argument("--d-model", type=int, default=256)
    parser.add_argument("--d-ff", type=int, default=1024)
    parser.add_argument("--n-block", type=int, default=1)
    parser.add_argument("--n-head", type=int, default=8)
    parser.add_argument("--kq-same", type=int, default=1)
    parser.add_argument("--dropout", type=float, default=0.05)
    parser.add_argument("--l2", type=float, default=1e-5)
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    if args.use_candidate_problems and args.eval_scope == "full":
        print("[Info] --use-candidate-problems is deprecated; use --eval-scope candidate")
    use_candidates = args.eval_scope == "candidate" or args.use_candidate_problems

    benchmark_dir = Path(args.benchmark_dir)
    k_list = [int(k.strip()) for k in args.k_list.split(",") if k.strip()]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pid2idx, num_q, max_len = load_pid_map(str(args.map_path))
    n_question = num_q - 1

    model = AKT(
        n_question=n_question,
        n_pid=0,
        n_blocks=args.n_block,
        d_model=args.d_model,
        kq_same=args.kq_same,
        dropout=args.dropout,
        model_type="akt",
        n_heads=args.n_head,
        d_ff=args.d_ff,
        l2=args.l2,
    ).to(device)
    model.load_state_dict(torch.load(args.model_ckpt, map_location=device))
    model.eval()

    results = []
    fmt = lambda v: f"{v:.4f}" if v is not None else "NA"

    for K in k_list:
        p = benchmark_dir / f"benchmark_K{K}.jsonl"
        if not p.exists():
            print(f"[SKIP] not found: {p}")
            continue

        auc_metrics = eval_auc(model, pid2idx, p, n_question, max_len, device, args.candidate_batch)
        rec = eval_topk_candidates(
            model=model,
            pid2idx=pid2idx,
            jsonl_path=p,
            n_question=n_question,
            max_len=max_len,
            device=device,
            ks=(1, 3, 5, 10),
            only_when_target_correct=args.only_correct_target,
            use_candidates=use_candidates,
            candidate_batch=args.candidate_batch,
            max_candidates=args.max_candidates,
        )

        print(f"\n[K={K}] file={p.name}  n_eval={auc_metrics['n_eval']}  n_skipped={auc_metrics['n_skipped']}")
        print(f"  AUC={fmt(auc_metrics['auc'])}  ACC@0.5={fmt(auc_metrics['acc@0.5'])}")
        for k in (1, 3, 5, 10):
            print(f"  Hit@{k}={fmt(rec[f'Hit@{k}'])}  NDCG@{k}={fmt(rec[f'NDCG@{k}'])}")

        merged = {"K": K}
        merged.update(auc_metrics)
        merged.update(rec)
        results.append(merged)

    out_path = benchmark_dir / "eval_topk_results_akt.json"
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n[OK] saved results: {out_path}")


if __name__ == "__main__":
    main()
