import sys
import os
import argparse


def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

for _thread_key in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "BLIS_NUM_THREADS",
):
    os.environ.setdefault(_thread_key, "1")

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
repo_root = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
akt_dir = os.path.join(repo_root, "models", "AKT")
sys.path.insert(0, akt_dir)

import ast
import json
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn import metrics
from torch.utils.data import DataLoader, Dataset

from akt import AKT

torch.set_num_threads(int(os.environ.get("TORCH_NUM_THREADS", os.environ.get("OMP_NUM_THREADS", "1"))))
try:
    torch.set_num_interop_threads(int(os.environ.get("TORCH_NUM_INTEROP_THREADS", "1")))
except RuntimeError:
    pass

DEFAULT_SEQ_CSV = "../kt_collection/experiments/csedm_sequences_runprogram.csv"
DEFAULT_OUT_DIR = "../kt_collection/checkpoints/akt_csedm"


@dataclass
class EvalConfig:
    seq_csv_path: str = DEFAULT_SEQ_CSV
    out_dir: str = DEFAULT_OUT_DIR
    seed: int = 42
    val_ratio: float = 0.1

    d_model: int = 256
    d_ff: int = 1024
    n_block: int = 1
    n_head: int = 8
    kq_same: int = 1
    dropout: float = 0.05
    l2: float = 1e-5

    batch_size: int = 64
    max_seq_len: int = 0


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_list_col(x):
    if isinstance(x, list):
        return x
    return ast.literal_eval(x)


def load_user_split(path: str):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return {
        "train": {str(u) for u in payload["train_user_ids"]},
        "val": {str(u) for u in payload["val_user_ids"]},
        "test": {str(u) for u in payload["test_user_ids"]},
    }


def build_loader(dataset, batch_size, shuffle, num_workers, prefetch_factor, persistent_workers, pin_memory):
    kwargs = {
        "batch_size": batch_size,
        "shuffle": shuffle,
        "drop_last": False,
        "num_workers": num_workers,
    }
    if num_workers > 0:
        kwargs["prefetch_factor"] = prefetch_factor
        kwargs["persistent_workers"] = persistent_workers
    if pin_memory:
        kwargs["pin_memory"] = True
    return DataLoader(dataset, **kwargs)


class AKTDataset(Dataset):
    def __init__(self, sequences, n_question, max_len, target_only_last=False):
        self.sequences = sequences
        self.n_question = n_question
        self.max_len = max_len
        self.target_only_last = target_only_last

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        if len(self.sequences[idx]) == 4:
            user_id, q, r, event_idx = self.sequences[idx]
            event_idx = np.array(event_idx, dtype=np.int64)
        else:
            user_id, q, r = self.sequences[idx]
            event_idx = np.arange(len(q), dtype=np.int64)
        if self.max_len and len(q) > self.max_len:
            q = q[-self.max_len :]
            r = r[-self.max_len :]
            event_idx = event_idx[-self.max_len :]
        seq_len = len(q)

        q_pad = np.zeros((self.max_len,), dtype=np.int64)
        qa_pad = np.zeros((self.max_len,), dtype=np.int64)
        target = np.full((self.max_len,), -1, dtype=np.float32)
        event_pad = np.full((self.max_len,), -1, dtype=np.int64)

        if seq_len > 0:
            q_pad[:seq_len] = q
            qa_pad[:seq_len] = [qq + rr * self.n_question for qq, rr in zip(q, r)]
            target[:seq_len] = r
            event_pad[:seq_len] = event_idx
            if self.target_only_last:
                last_target = target[seq_len - 1]
                target[:] = -1
                target[seq_len - 1] = last_target

        return user_id, torch.from_numpy(q_pad), torch.from_numpy(qa_pad), torch.from_numpy(target), torch.from_numpy(event_pad)


def load_pid_map(map_path):
    with open(map_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}
    num_q = int(m.get("num_q", len(pid2idx) + 1))
    max_len = int(m.get("n", 0))
    return pid2idx, num_q, max_len


def build_sequences(df, pid2idx):
    sequences = []
    skipped_unknown = 0
    skipped_short = 0
    skipped_mismatch = 0
    user_col = "user_id" if "user_id" in df.columns else "user"

    for _, row in df.iterrows():
        q_raw = parse_list_col(row["problem_sequence"])
        r_raw = parse_list_col(row["result_sequence"])
        e_raw = parse_list_col(row["row_index_sequence"]) if "row_index_sequence" in df.columns else list(range(len(q_raw)))
        if len(q_raw) != len(r_raw):
            skipped_mismatch += 1
            continue
        if len(q_raw) != len(e_raw):
            skipped_mismatch += 1
            continue

        q = []
        e = []
        ok = True
        for p, event_val in zip(q_raw, e_raw):
            pid = int(p)
            if pid not in pid2idx:
                ok = False
                break
            q.append(pid2idx[pid])
            e.append(int(event_val))
        if not ok:
            skipped_unknown += 1
            continue

        r = [int(x) for x in r_raw]
        if len(q) < 2:
            skipped_short += 1
            continue

        sequences.append((str(row[user_col]), q, r, e))

    skipped = {
        "unknown_pid": skipped_unknown,
        "too_short": skipped_short,
        "length_mismatch": skipped_mismatch,
    }
    return sequences, skipped


def split_sequences(sequences, val_ratio, seed):
    rng = random.Random(seed)
    seqs = list(sequences)
    rng.shuffle(seqs)
    n_val = int(len(seqs) * val_ratio)
    return seqs[n_val:], seqs[:n_val]


def evaluate(model, loader, device, collect_predictions: bool = False):
    y_pred = []
    y_true = []
    loss_vals = []
    records = []

    model.eval()
    with torch.no_grad():
        for user_ids, q, qa, target, event_idx in loader:
            q = q.to(device)
            qa = qa.to(device)
            target = target.to(device)

            loss, preds, ct = model(q, qa, target)
            preds = preds.view(q.size(0), -1)
            preds = preds[:, 1:]
            target = target[:, 1:]
            event_idx = event_idx[:, 1:]
            mask = target > -0.9
            if mask.sum() == 0:
                continue

            y_pred.append(preds[mask].detach().cpu())
            y_true.append(target[mask].detach().cpu())
            if collect_predictions:
                preds_cpu = preds.detach().cpu()
                target_cpu = target.detach().cpu()
                event_cpu = event_idx.detach().cpu()
                for i, user_id in enumerate(user_ids):
                    valid = target_cpu[i] > -0.9
                    pred_vals = preds_cpu[i][valid].tolist()
                    target_vals = target_cpu[i][valid].tolist()
                    event_vals = event_cpu[i][valid].tolist()
                    for event_val, target_val, pred_val in zip(event_vals, target_vals, pred_vals):
                        records.append(
                            {
                                "user_id": str(user_id),
                                "event_idx": int(event_val),
                                "target": float(target_val),
                                "pred": float(pred_val),
                            }
                        )

            ct = ct.float().clamp(min=1.0)
            loss_vals.append((loss / ct).detach().cpu().item())

    if not y_pred:
        return {
            "auc": None,
            "acc@0.5": None,
            "logloss": None,
            "rmse": None,
            "loss": None,
            "n_eval": 0,
        }, records

    y_scores = torch.cat(y_pred).numpy()
    y_true_np = torch.cat(y_true).numpy()
    n_eval = len(y_true_np)

    auc = metrics.roc_auc_score(y_true_np, y_scores) if len(np.unique(y_true_np)) > 1 else None
    acc = ((y_scores >= 0.5).astype(np.int32) == y_true_np.astype(np.int32)).mean()
    try:
        logloss = metrics.log_loss(y_true_np, np.clip(y_scores, 1e-6, 1 - 1e-6))
    except ValueError:
        logloss = None

    rmse = float(np.sqrt(metrics.mean_squared_error(y_true_np, y_scores)))
    loss_mean = float(np.mean(loss_vals)) if loss_vals else None

    return {
        "auc": None if auc is None else float(auc),
        "acc@0.5": float(acc),
        "logloss": None if logloss is None else float(logloss),
        "rmse": float(rmse),
        "loss": None if loss_mean is None else float(loss_mean),
        "n_eval": int(n_eval),
    }, records


def fmt(v):
    return "NA" if v is None else f"{v:.4f}"


def main():
    parser = argparse.ArgumentParser(description="Evaluate AKT (KT) on CSEDM sequences.")
    parser.add_argument("--model-ckpt", type=str, default=None, help="model checkpoint path")
    parser.add_argument("--map-path", type=str, default=None, help="problem_id map path")
    parser.add_argument("--seq-csv-path", type=str, default=None, help="sequence CSV path")
    parser.add_argument("--eval-split", choices=["train", "val", "test", "full"], default="val", help="eval split")
    parser.add_argument("--val-ratio", type=float, default=None, help="validation ratio for val split")
    parser.add_argument("--split-json", type=str, default=None, help="fixed user split JSON")
    parser.add_argument("--pred-out", type=str, default=None, help="write event-level predictions to CSV")
    parser.add_argument("--seed", type=int, default=None, help="random seed")
    parser.add_argument("--d-model", type=int, default=None, help="AKT d_model")
    parser.add_argument("--d-ff", type=int, default=None, help="AKT d_ff")
    parser.add_argument("--n-block", type=int, default=None, help="AKT n_block")
    parser.add_argument("--n-head", type=int, default=None, help="AKT n_head")
    parser.add_argument("--kq-same", type=int, default=None, help="AKT kq_same")
    parser.add_argument("--dropout", type=float, default=None, help="AKT dropout")
    parser.add_argument("--l2", type=float, default=None, help="AKT l2")
    parser.add_argument("--batch-size", type=int, default=None, help="batch size")
    parser.add_argument("--max-seq-len", type=int, default=None, help="truncate max sequence length")
    parser.add_argument("--num-workers", type=int, default=None, help="DataLoader workers")
    parser.add_argument("--prefetch-factor", type=int, default=2, help="DataLoader prefetch factor")
    parser.add_argument("--persistent-workers", action="store_true", help="use DataLoader persistent workers")
    parser.add_argument("--pin-memory", action="store_true", help="use DataLoader pin_memory")
    parser.add_argument("--gpu", type=str, default="0", help="GPU index")
    parser.add_argument("--target-only-last", action="store_true", help="evaluate only the final target in each sequence")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    cfg = EvalConfig()
    if args.seq_csv_path:
        cfg.seq_csv_path = args.seq_csv_path
    if args.seed is not None:
        cfg.seed = args.seed
    if args.val_ratio is not None:
        cfg.val_ratio = args.val_ratio
    if args.d_model is not None:
        cfg.d_model = args.d_model
    if args.d_ff is not None:
        cfg.d_ff = args.d_ff
    if args.n_block is not None:
        cfg.n_block = args.n_block
    if args.n_head is not None:
        cfg.n_head = args.n_head
    if args.kq_same is not None:
        cfg.kq_same = args.kq_same
    if args.dropout is not None:
        cfg.dropout = args.dropout
    if args.l2 is not None:
        cfg.l2 = args.l2
    if args.batch_size is not None:
        cfg.batch_size = args.batch_size
    if args.max_seq_len is not None:
        cfg.max_seq_len = args.max_seq_len

    set_seed(cfg.seed)

    out_dir = Path(cfg.out_dir)
    model_ckpt = Path(args.model_ckpt) if args.model_ckpt else out_dir / "model.ckpt"
    map_path = Path(args.map_path) if args.map_path else out_dir / "problem_id_map.json"

    if not model_ckpt.exists():
        raise FileNotFoundError(f"model checkpoint not found: {model_ckpt}")
    if not map_path.exists():
        raise FileNotFoundError(f"problem map not found: {map_path}")

    pid2idx, num_q, map_max_len = load_pid_map(str(map_path))
    n_question = num_q - 1

    df = pd.read_csv(cfg.seq_csv_path)
    df.columns = [c.strip().lstrip("\ufeff") for c in df.columns]
    df["problem_sequence"] = df["problem_sequence"].apply(parse_list_col)
    df["result_sequence"] = df["result_sequence"].apply(parse_list_col)

    sequences, skipped = build_sequences(df, pid2idx)

    if args.split_json:
        split = load_user_split(args.split_json)
        if args.eval_split == "full":
            eval_sequences = sequences
        else:
            eval_sequences = [seq for seq in sequences if seq[0] in split[args.eval_split]]
    else:
        if args.eval_split == "val":
            _, eval_sequences = split_sequences(sequences, cfg.val_ratio, cfg.seed)
        elif args.eval_split == "full":
            eval_sequences = sequences
        else:
            raise ValueError("--split-json is required for eval-split=train/test")

    if not eval_sequences:
        raise ValueError("No sequences available for evaluation.")

    seq_max_len = max(len(seq[1]) for seq in eval_sequences)
    max_len = map_max_len if map_max_len > 0 else seq_max_len
    if cfg.max_seq_len and max_len > cfg.max_seq_len:
        max_len = cfg.max_seq_len

    eval_ds = AKTDataset(eval_sequences, n_question=n_question, max_len=max_len, target_only_last=args.target_only_last)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pin_memory = args.pin_memory or device.type == "cuda"
    num_workers = args.num_workers if args.num_workers is not None else 4
    eval_loader = build_loader(
        eval_ds,
        cfg.batch_size,
        False,
        num_workers,
        args.prefetch_factor,
        args.persistent_workers,
        pin_memory,
    )

    model = AKT(
        n_question=n_question,
        n_pid=0,
        n_blocks=cfg.n_block,
        d_model=cfg.d_model,
        kq_same=cfg.kq_same,
        dropout=cfg.dropout,
        model_type="akt",
        n_heads=cfg.n_head,
        d_ff=cfg.d_ff,
        l2=cfg.l2,
    ).to(device)
    model.load_state_dict(torch.load(model_ckpt, map_location=device))

    result, records = evaluate(model, eval_loader, device, collect_predictions=bool(args.pred_out))
    if args.pred_out:
        pred_out = Path(args.pred_out)
        pred_out.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame.from_records(records).to_csv(pred_out, index=False)

    print(
        f"[Data] total_sequences={len(sequences)} eval_sequences={len(eval_sequences)} "
        f"skipped={sum(skipped.values())}"
    )
    print(
        f"  skipped_unknown_pid={skipped['unknown_pid']} "
        f"skipped_too_short={skipped['too_short']} "
        f"skipped_mismatch={skipped['length_mismatch']}"
    )
    print(f"[Eval] n_eval={result['n_eval']} loss={fmt(result['loss'])}")
    print(
        f"  AUC={fmt(result['auc'])} ACC@0.5={fmt(result['acc@0.5'])} "
        f"LOGLOSS={fmt(result['logloss'])} RMSE={fmt(result['rmse'])}"
    )
    if args.pred_out:
        print(f"[Predictions] saved={Path(args.pred_out).resolve()}")


if __name__ == "__main__":
    main()
