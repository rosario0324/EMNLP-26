import sys
import os
import argparse

from sklearn.model_selection import KFold


def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
repo_root = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
akt_dir = os.path.join(repo_root, "models", "AKT")
sys.path.insert(0, akt_dir)

import json
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.optim import Adam
from sklearn import metrics

from akt import AKT
from rec_utils import RecDataset, build_loader as build_rec_loader, collate_rec_batch, load_rec_examples

DEFAULT_BENCHMARK_DIR = "./CSEDM/BePKT/remapped_benchmark"
DEFAULT_OUT_DIR = "../kt_collection/checkpoints/akt_kfold_rec_bepkt"


@dataclass
class EvalConfig:
    benchmark_dir: str = DEFAULT_BENCHMARK_DIR
    out_dir: str = DEFAULT_OUT_DIR
    seed: int = 42

    d_model: int = 256
    d_ff: int = 1024
    n_block: int = 1
    n_head: int = 8
    kq_same: int = 1
    dropout: float = 0.05
    l2: float = 1e-5

    batch_size: int = 64
    num_epochs: int = 20
    lr: float = 1e-3

    pad_q: int = 0
    pad_r: int = 0


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def load_pid_map(map_path: str):
    with open(map_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}
    num_q = int(m.get("num_q", len(pid2idx) + 1))
    max_len = int(m.get("n", m.get("seqlen", 200)))
    return pid2idx, num_q, max_len


def collect_problem_ids(benchmark_dir: Path, k_list):
    pids = set()
    for k in k_list:
        path = benchmark_dir / f"benchmark_K{k}.jsonl"
        if not path.exists():
            continue
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                ex = json.loads(line)
                try:
                    pids.add(int(ex["target_problem_id"]))
                except Exception:
                    pass
                for step in ex.get("input_sequence", []):
                    try:
                        pids.add(int(step["problem_id"]))
                    except Exception:
                        continue
                cand_raw = ex.get("candidate_problems")
                if isinstance(cand_raw, list):
                    for pid in cand_raw:
                        try:
                            pids.add(int(pid))
                        except Exception:
                            continue
    return pids


def build_pid_map_from_benchmark(benchmark_dir: Path, k_list):
    pids = collect_problem_ids(benchmark_dir, k_list)
    if not pids:
        raise ValueError("No problem ids found in benchmark jsonl files.")
    all_probs = sorted(pids)
    pid2idx = {int(p): i + 1 for i, p in enumerate(all_probs)}
    idx2pid = {i: p for p, i in pid2idx.items()}
    num_q = len(pid2idx) + 1
    return pid2idx, idx2pid, num_q


def _prepare_history(q_row, r_row, length, max_hist_len):
    q_hist = q_row[:length].tolist()
    r_hist = r_row[:length].tolist()
    if max_hist_len is not None and max_hist_len > 0 and len(q_hist) > max_hist_len:
        q_hist = q_hist[-max_hist_len:]
        r_hist = r_hist[-max_hist_len:]
    return q_hist, r_hist


def score_candidates_tensor(model, q_hist, r_hist, candidates, n_question, max_seq_len, device, candidate_batch):
    if max_seq_len is None or max_seq_len <= 0:
        max_seq_len = len(q_hist) + 1
    max_hist_len = max_seq_len - 1
    if max_hist_len < 0:
        max_hist_len = 0
    if len(q_hist) > max_hist_len:
        q_hist = q_hist[-max_hist_len:]
        r_hist = r_hist[-max_hist_len:]
    hist_len = len(q_hist)
    pos = hist_len

    if hist_len > 0:
        q_hist_t = torch.tensor(q_hist, dtype=torch.long, device=device)
        qa_hist_t = torch.tensor(
            [qq + rr * n_question for qq, rr in zip(q_hist, r_hist)],
            dtype=torch.long,
            device=device,
        )
        r_hist_t = torch.tensor(r_hist, dtype=torch.float32, device=device)
    else:
        q_hist_t = None
        qa_hist_t = None
        r_hist_t = None

    scores = []
    for start in range(0, len(candidates), candidate_batch):
        cand_batch = candidates[start : start + candidate_batch]
        bsz = len(cand_batch)
        q_pad = torch.zeros((bsz, max_seq_len), dtype=torch.long, device=device)
        qa_pad = torch.zeros_like(q_pad)
        target_pad = torch.full((bsz, max_seq_len), -1.0, dtype=torch.float32, device=device)

        if hist_len > 0:
            q_pad[:, :hist_len] = q_hist_t.unsqueeze(0).expand(bsz, -1)
            qa_pad[:, :hist_len] = qa_hist_t.unsqueeze(0).expand(bsz, -1)
            target_pad[:, :hist_len] = r_hist_t.unsqueeze(0).expand(bsz, -1)

        cand_t = torch.tensor(cand_batch, dtype=torch.long, device=device)
        q_pad[:, pos] = cand_t
        qa_pad[:, pos] = cand_t
        target_pad[:, pos] = 0.0

        _, preds, _ = model(q_pad, qa_pad, target_pad)
        preds = preds.view(bsz, -1)
        scores.append(preds[:, pos])

    return torch.cat(scores, dim=0)


def collate_rec_with_target(batch, pad_q, pad_r, pad_cand, fixed_len, pad_left):
    q, r, cand, cand_mask, lengths, target_pos = collate_rec_batch(
        batch, pad_q=pad_q, pad_r=pad_r, pad_cand=pad_cand, fixed_len=fixed_len, pad_left=pad_left
    )
    target_result = torch.tensor([b.target_result for b in batch], dtype=torch.long)
    return q, r, cand, cand_mask, lengths, target_pos, target_result


def train_one_epoch_rec(model, loader, device, n_question, max_seq_len, candidate_batch, opt):
    model.train()
    losses = []
    eps = 1e-6
    for q, r, cand, cand_mask, lengths, target_pos in loader:
        q = q.long().to(device)
        r = r.long().to(device)
        cand = cand.long().to(device)
        cand_mask = cand_mask.to(device)
        lengths = lengths.to(device)
        target_pos = target_pos.to(device)

        valid_items = []
        for i in range(q.size(0)):
            length = int(lengths[i].item())
            if length <= 0:
                continue
            cand_row = cand[i][cand_mask[i]].tolist()
            if not cand_row:
                continue
            valid_items.append((i, length, cand_row))

        if not valid_items:
            continue

        opt.zero_grad()
        num_valid = len(valid_items)
        batch_loss_sum = 0.0
        for i, length, cand_row in valid_items:
            q_hist, r_hist = _prepare_history(q[i], r[i], length, max_seq_len - 1)
            scores_i = score_candidates_tensor(
                model,
                q_hist,
                r_hist,
                cand_row,
                n_question,
                max_seq_len,
                device,
                candidate_batch,
            )
            scores_i = torch.logit(scores_i.clamp(min=eps, max=1 - eps))
            target_i = torch.tensor([int(target_pos[i].item())], dtype=torch.long, device=device)
            loss_i = F.cross_entropy(scores_i.unsqueeze(0), target_i)
            (loss_i / num_valid).backward()
            batch_loss_sum += loss_i.detach().cpu().item()

        opt.step()
        losses.append(batch_loss_sum / num_valid)

    return float(np.mean(losses)) if losses else None


@torch.no_grad()
def evaluate_hit1(model, loader, device, n_question, max_seq_len, candidate_batch):
    model.eval()
    hit1 = 0
    total = 0
    for q, r, cand, cand_mask, lengths, target_pos in loader:
        q = q.long().to(device)
        r = r.long().to(device)
        cand = cand.long().to(device)
        cand_mask = cand_mask.to(device)
        lengths = lengths.to(device)
        target_pos = target_pos.to(device)

        for i in range(q.size(0)):
            length = int(lengths[i].item())
            if length <= 0:
                continue
            cand_row = cand[i][cand_mask[i]].tolist()
            if not cand_row:
                continue

            q_hist, r_hist = _prepare_history(q[i], r[i], length, max_seq_len - 1)
            scores_i = score_candidates_tensor(
                model,
                q_hist,
                r_hist,
                cand_row,
                n_question,
                max_seq_len,
                device,
                candidate_batch,
            )
            pred_idx = int(scores_i.argmax().item())
            if pred_idx == int(target_pos[i].item()):
                hit1 += 1
            total += 1

    return hit1 / total if total else 0.0


def hit_at_k(rank_pos: int, k: int) -> float:
    return 1.0 if rank_pos <= k else 0.0


def ndcg_at_k(rank_pos: int, k: int) -> float:
    if rank_pos <= k:
        return 1.0 / np.log2(rank_pos + 1)
    return 0.0


@torch.no_grad()
def evaluate_rec(model, loader, n_question, max_seq_len, device, ks, eval_scope, candidate_batch):
    model.eval()
    ks = sorted(set(ks))
    max_k = max(ks)

    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}
    n_eval = 0
    y_scores = []
    y_true = []

    all_candidates = list(range(1, n_question + 1))

    for q, r, cand, cand_mask, lengths, target_pos, target_result in loader:
        q = q.long().to(device)
        r = r.long().to(device)
        cand = cand.long().to(device)
        cand_mask = cand_mask.to(device)
        lengths = lengths.to(device)
        target_pos = target_pos.to(device)

        for i in range(q.size(0)):
            length = int(lengths[i].item())
            if length <= 0:
                continue

            cand_row = cand[i][cand_mask[i]].tolist()
            if not cand_row:
                continue

            q_hist, r_hist = _prepare_history(q[i], r[i], length, max_seq_len - 1)

            if eval_scope == "candidate":
                scores = score_candidates_tensor(
                    model,
                    q_hist,
                    r_hist,
                    cand_row,
                    n_question,
                    max_seq_len,
                    device,
                    candidate_batch,
                )
                target_idx = int(target_pos[i].item())
                target_score = float(scores[target_idx].item())

                sorted_idx = torch.argsort(scores, descending=True)
                match = (sorted_idx == target_idx).nonzero(as_tuple=False)
                rank_pos = int(match[0, 0]) + 1 if match.numel() > 0 else 10**9
            else:
                scores = score_candidates_tensor(
                    model,
                    q_hist,
                    r_hist,
                    all_candidates,
                    n_question,
                    max_seq_len,
                    device,
                    candidate_batch,
                )
                target_pid = int(cand[i, target_pos[i]].item())
                target_score = float(scores[target_pid - 1].item())

                sorted_idx = torch.argsort(scores, descending=True)
                match = (sorted_idx == (target_pid - 1)).nonzero(as_tuple=False)
                rank_pos = int(match[0, 0]) + 1 if match.numel() > 0 else 10**9

            y_scores.append(target_score)
            y_true.append(int(target_result[i].item()))

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)
            n_eval += 1

    if not y_scores:
        return {
            "auc": None,
            "acc@0.5": None,
            "logloss": None,
            "hit": {k: None for k in ks},
            "ndcg": {k: None for k in ks},
            "n_eval": 0,
        }

    y_scores_np = np.array(y_scores, dtype=np.float32)
    y_true_np = np.array(y_true, dtype=np.int32)

    auc = metrics.roc_auc_score(y_true=y_true_np, y_score=y_scores_np) if len(np.unique(y_true_np)) > 1 else None
    acc = ((y_scores_np >= 0.5).astype(np.int32) == y_true_np.astype(np.int32)).mean()
    try:
        logloss = metrics.log_loss(y_true=y_true_np, y_pred=np.clip(y_scores_np, 1e-6, 1 - 1e-6))
    except ValueError:
        logloss = None

    hit = {k: (sums_hit[k] / n_eval) if n_eval else None for k in ks}
    ndcg = {k: (sums_ndcg[k] / n_eval) if n_eval else None for k in ks}

    return {
        "auc": None if auc is None else float(auc),
        "acc@0.5": float(acc),
        "logloss": None if logloss is None else float(logloss),
        "hit": hit,
        "ndcg": ndcg,
        "n_eval": int(n_eval),
    }


def summarize(values):
    vals = [v for v in values if v is not None]
    if not vals:
        return None, None, 0
    return float(np.mean(vals)), float(np.std(vals)), len(vals)


def main():
    parser = argparse.ArgumentParser(description="K-fold (k=5) evaluation for AKT on BePKT (REC).")
    parser.add_argument("--benchmark-dir", type=str, default=None, help="benchmark JSONL dir path")
    parser.add_argument("--k-list", type=str, default="10,20,30,40,50", help="K values (comma-separated)")
    parser.add_argument("--map-path", type=str, default=None, help="problem_id map path")
    parser.add_argument("--out-dir", type=str, default=None, help="output dir for maps/checkpoints")
    parser.add_argument("--k-folds", type=int, default=5, help="number of folds")
    parser.add_argument(
        "--fold-indices",
        type=str,
        default=None,
        help="comma-separated 1-based fold indices to run (e.g., 1,3,5)",
    )
    parser.add_argument("--seed", type=int, default=None, help="random seed")
    parser.add_argument("--num-epochs", type=int, default=None, help="number of epochs")
    parser.add_argument("--lr", type=float, default=None, help="learning rate")
    parser.add_argument("--d-model", type=int, default=None, help="AKT d_model")
    parser.add_argument("--d-ff", type=int, default=None, help="AKT d_ff")
    parser.add_argument("--n-block", type=int, default=None, help="AKT n_block")
    parser.add_argument("--n-head", type=int, default=None, help="AKT n_head")
    parser.add_argument("--kq-same", type=int, default=None, help="AKT kq_same")
    parser.add_argument("--dropout", type=float, default=None, help="AKT dropout")
    parser.add_argument("--l2", type=float, default=None, help="AKT l2")
    parser.add_argument("--batch-size", type=int, default=None, help="batch size")
    parser.add_argument("--max-seq-len", type=int, default=None, help="max sequence length (includes target slot)")
    parser.add_argument("--max-candidates", type=int, default=0, help="max candidates per example (0=disable)")
    parser.add_argument("--use-all-candidates", action="store_true", help="use all problems as candidates")
    parser.add_argument("--eval-scope", choices=["full", "candidate"], default="full", help="ranking scope")
    parser.add_argument("--candidate-batch", type=int, default=64, help="candidate batch size")
    parser.add_argument("--num-workers", type=int, default=None, help="DataLoader workers")
    parser.add_argument("--prefetch-factor", type=int, default=2, help="DataLoader prefetch factor")
    parser.add_argument("--persistent-workers", action="store_true", help="use DataLoader persistent workers")
    parser.add_argument("--pin-memory", action="store_true", help="use DataLoader pin_memory")
    parser.add_argument("--save-fold-ckpt", action="store_true", help="save best checkpoint per fold")
    parser.add_argument("--gpu", type=str, default="0", help="GPU index")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    fold_indices = None
    if args.fold_indices:
        fold_indices = sorted({int(x) for x in args.fold_indices.split(",") if x.strip()})
        if not fold_indices:
            fold_indices = None
        else:
            for idx in fold_indices:
                if idx < 1 or idx > args.k_folds:
                    raise ValueError(f"fold index {idx} is out of range 1..{args.k_folds}")

    cfg = EvalConfig()
    if args.benchmark_dir:
        cfg.benchmark_dir = args.benchmark_dir
    if args.out_dir:
        cfg.out_dir = args.out_dir
    if args.seed is not None:
        cfg.seed = args.seed
    if args.num_epochs is not None:
        cfg.num_epochs = args.num_epochs
    if args.lr is not None:
        cfg.lr = args.lr
    if args.d_model is not None:
        cfg.d_model = args.d_model
    if args.d_ff is not None:
        cfg.d_ff = args.d_ff
    if args.n_block is not None:
        cfg.n_block = args.n_block
    if args.n_head is not None:
        cfg.n_head = args.n_head
    if args.kq_same is not None:
        cfg.kq_same = args.kq_same
    if args.dropout is not None:
        cfg.dropout = args.dropout
    if args.l2 is not None:
        cfg.l2 = args.l2
    if args.batch_size is not None:
        cfg.batch_size = args.batch_size

    set_seed(cfg.seed)

    out_dir = Path(cfg.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    benchmark_dir = Path(cfg.benchmark_dir)
    k_list = [int(k.strip()) for k in args.k_list.split(",") if k.strip()]

    map_path = args.map_path or str(out_dir / "problem_id_map.json")
    if Path(map_path).exists():
        pid2idx, num_q, max_seq_len = load_pid_map(map_path)
    else:
        pid2idx, idx2pid, num_q = build_pid_map_from_benchmark(benchmark_dir, k_list)
        max_seq_len = 0

    max_hist_len = None
    if args.max_seq_len is not None and args.max_seq_len > 0:
        max_hist_len = args.max_seq_len - 1

    examples, skipped = load_rec_examples(
        benchmark_dir,
        k_list,
        pid2idx,
        max_seq_len=max_hist_len,
        max_candidates=args.max_candidates if args.max_candidates > 0 else None,
        seed=cfg.seed,
        use_all_candidates=args.use_all_candidates,
    )
    if not examples:
        raise ValueError("No recommendation examples loaded. Check benchmark_dir and k_list.")
    if skipped:
        print(f"[Info] skipped {skipped} examples due to mapping/history issues.")

    max_len_hist = max(len(ex.q_hist) for ex in examples)
    if args.max_seq_len is not None and args.max_seq_len > 0:
        max_seq_len = args.max_seq_len
    else:
        max_seq_len = max_len_hist + 1
    if max_seq_len < 2:
        max_seq_len = 2

    if not Path(map_path).exists():
        with open(map_path, "w", encoding="utf-8") as f:
            json.dump(
                {"pid2idx": pid2idx, "idx2pid": idx2pid, "num_q": num_q, "n": max_seq_len},
                f,
                ensure_ascii=False,
                indent=2,
            )

    n_question = num_q - 1

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pin_memory = args.pin_memory or device.type == "cuda"
    num_workers = args.num_workers if args.num_workers is not None else 4

    unique_users = list(dict.fromkeys(ex.user_id for ex in examples))
    kf = KFold(n_splits=args.k_folds, shuffle=True, random_state=cfg.seed)

    fold_metrics = []
    ks = (1, 3, 5, 10)

    for fold, (train_user_idx, val_user_idx) in enumerate(kf.split(unique_users), start=1):
        if fold_indices is not None and fold not in fold_indices:
            continue
        print(f"\n=== Fold {fold}/{args.k_folds} ===")

        train_users = {unique_users[i] for i in train_user_idx}
        val_users = {unique_users[i] for i in val_user_idx}
        train_ex = [ex for ex in examples if ex.user_id in train_users]
        val_ex = [ex for ex in examples if ex.user_id in val_users]

        train_loader = build_rec_loader(
            RecDataset(train_ex),
            cfg.batch_size,
            True,
            num_workers,
            args.prefetch_factor,
            args.persistent_workers,
            pin_memory,
            collate_fn=lambda b: collate_rec_batch(
                b, pad_q=cfg.pad_q, pad_r=cfg.pad_r, pad_cand=0, fixed_len=max_seq_len - 1, pad_left=False
            ),
        )
        val_loader = build_rec_loader(
            RecDataset(val_ex),
            cfg.batch_size,
            False,
            num_workers,
            args.prefetch_factor,
            args.persistent_workers,
            pin_memory,
            collate_fn=lambda b: collate_rec_batch(
                b, pad_q=cfg.pad_q, pad_r=cfg.pad_r, pad_cand=0, fixed_len=max_seq_len - 1, pad_left=False
            ),
        )
        eval_loader = build_rec_loader(
            RecDataset(val_ex),
            cfg.batch_size,
            False,
            num_workers,
            args.prefetch_factor,
            args.persistent_workers,
            pin_memory,
            collate_fn=lambda b: collate_rec_with_target(
                b, pad_q=cfg.pad_q, pad_r=cfg.pad_r, pad_cand=0, fixed_len=max_seq_len - 1, pad_left=False
            ),
        )

        model = AKT(
            n_question=n_question,
            n_pid=0,
            n_blocks=cfg.n_block,
            d_model=cfg.d_model,
            kq_same=cfg.kq_same,
            dropout=cfg.dropout,
            model_type="akt",
            n_heads=cfg.n_head,
            d_ff=cfg.d_ff,
            l2=cfg.l2,
        ).to(device)
        opt = Adam(model.parameters(), lr=cfg.lr)

        best_hit = -1.0
        best_state = None

        for epoch in range(1, cfg.num_epochs + 1):
            train_loss = train_one_epoch_rec(
                model, train_loader, device, n_question, max_seq_len, args.candidate_batch, opt
            )
            val_hit = evaluate_hit1(
                model, val_loader, device, n_question, max_seq_len, args.candidate_batch
            )
            loss_msg = f"{train_loss:.4f}" if train_loss is not None else "NA"
            print(f"Epoch {epoch}: train_loss={loss_msg} val_hit@1={val_hit:.4f}")

            if val_hit > best_hit:
                best_hit = val_hit
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        if best_state is not None:
            model.load_state_dict(best_state)

        final_stats = evaluate_rec(
            model,
            eval_loader,
            n_question,
            max_seq_len,
            device,
            ks=ks,
            eval_scope=args.eval_scope,
            candidate_batch=args.candidate_batch,
        )
        fold_metrics.append(final_stats)

        if args.save_fold_ckpt and best_state is not None:
            fold_dir = out_dir / f"fold_{fold}"
            fold_dir.mkdir(parents=True, exist_ok=True)
            torch.save(best_state, fold_dir / "model_rec.ckpt")

        fmt = lambda v: f"{v:.4f}" if v is not None else "NA"
        print(
            f"[Fold {fold}] AUC={fmt(final_stats['auc'])} ACC@0.5={fmt(final_stats['acc@0.5'])} "
            f"LOGLOSS={fmt(final_stats['logloss'])} n_eval={final_stats['n_eval']}"
        )
        for k in ks:
            print(f"  Hit@{k}={fmt(final_stats['hit'][k])}  NDCG@{k}={fmt(final_stats['ndcg'][k])}")

    auc_mean, auc_std, auc_n = summarize([m["auc"] for m in fold_metrics])
    acc_mean, acc_std, acc_n = summarize([m["acc@0.5"] for m in fold_metrics])
    logloss_mean, logloss_std, logloss_n = summarize([m["logloss"] for m in fold_metrics])

    fmt = lambda v: f"{v:.4f}" if v is not None else "NA"
    summary_label = "K-Fold Summary"
    if fold_indices is not None and len(fold_indices) < args.k_folds:
        summary_label = "Selected Fold Summary"
    print(f"\n=== {summary_label} ===")
    print(f"AUC: mean={fmt(auc_mean)} std={fmt(auc_std)} n={auc_n}")
    print(f"ACC@0.5: mean={fmt(acc_mean)} std={fmt(acc_std)} n={acc_n}")
    print(f"LOGLOSS: mean={fmt(logloss_mean)} std={fmt(logloss_std)} n={logloss_n}")
    for k in ks:
        hit_mean, hit_std, hit_n = summarize([m["hit"][k] for m in fold_metrics])
        ndcg_mean, ndcg_std, ndcg_n = summarize([m["ndcg"][k] for m in fold_metrics])
        print(f"Hit@{k}: mean={fmt(hit_mean)} std={fmt(hit_std)} n={hit_n}")
        print(f"NDCG@{k}: mean={fmt(ndcg_mean)} std={fmt(ndcg_std)} n={ndcg_n}")


if __name__ == "__main__":
    main()
