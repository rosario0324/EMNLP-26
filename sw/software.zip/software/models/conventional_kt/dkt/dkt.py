import os

import numpy as np
import torch

from torch.nn import Module, Embedding, LSTM, Linear, Dropout
from torch.nn.functional import one_hot, binary_cross_entropy
import torch.nn.functional as F
from sklearn import metrics


class DKT(Module):
    '''
        Args:
            num_q: the total number of the questions(KCs) in the given dataset
            emb_size: the dimension of the embedding vectors in this model
            hidden_size: the dimension of the hidden vectors in this model
    '''
    def __init__(self, num_q, emb_size, hidden_size, micro_emb=None, micro_mode="none"):
        super().__init__()
        self.num_q = num_q
        self.emb_size = emb_size
        self.hidden_size = hidden_size

        self.micro_mode = micro_mode
        self.use_micro = micro_emb is not None and micro_mode != "none"

        if self.use_micro:
            self.q_emb = Embedding(self.num_q, self.emb_size)
            self.r_emb = Embedding(2, self.emb_size)
            self.register_buffer("micro_emb", micro_emb)
            micro_dim = micro_emb.shape[1]
            self.micro_proj = Linear(micro_dim, self.emb_size, bias=False) if micro_dim != self.emb_size else None
            self.concat_proj = (
                Linear(self.emb_size * 2, self.emb_size, bias=False)
                if micro_mode in ("concat", "contrastive")
                else None
            )
            self.interaction_emb = None
        else:
            self.interaction_emb = Embedding(self.num_q * 2, self.emb_size)
            self.q_emb = None
            self.r_emb = None
            self.micro_proj = None
            self.concat_proj = None
        self.lstm_layer = LSTM(
            self.emb_size, self.hidden_size, batch_first=True
        )
        self.out_layer = Linear(self.hidden_size, self.num_q)
        self.dropout_layer = Dropout()

    def forward(self, q, r):
        '''
            Args:
                q: the question(KC) sequence with the size of [batch_size, n]
                r: the response sequence with the size of [batch_size, n]

            Returns:
                y: the knowledge level about the all questions(KCs)
        '''

        # 1. 패딩 마스크 생성: q가 -1인 위치 (패딩 위치)를 찾습니다.
        mask = (q >= 0) 
        
        # 2. 패딩을 0 인덱스로 치환 (실제 모델 학습 시에는 mask로 제외되므로 안전함)
        q = torch.where(mask, q, torch.tensor(0, device=q.device))
        r = torch.where(mask, r, torch.tensor(0, device=r.device))

        if not self.use_micro:
            # 3. 상호작용 인덱스 생성
            x = q + self.num_q * r
            h, _ = self.lstm_layer(self.interaction_emb(x))
        else:
            q_rep = self.question_repr(q)
            r_rep = self.r_emb(r)
            h, _ = self.lstm_layer(q_rep + r_rep)
        y = self.out_layer(h)
        y = self.dropout_layer(y)
        y = torch.sigmoid(y)

        return y

    def _project_micro(self, micro_vec):
        return self.micro_proj(micro_vec) if self.micro_proj is not None else micro_vec

    def micro_repr(self, q):
        if not self.use_micro:
            raise RuntimeError("micro_repr called without micro embeddings.")
        return self._project_micro(self.micro_emb[q])

    def question_repr(self, q):
        if not self.use_micro:
            raise RuntimeError("question_repr called without micro embeddings.")
        micro = self._project_micro(self.micro_emb[q])
        if self.micro_mode == "replace":
            return micro
        base = self.q_emb(q)
        if self.concat_proj is not None:
            return self.concat_proj(torch.cat([base, micro], dim=-1))
        return base + micro

    def contrastive_loss(self, q_ids, temperature=0.1):
        if not self.use_micro:
            return None
        q_ids = torch.unique(q_ids)
        if q_ids.numel() == 0:
            return None
        q_rep = self.question_repr(q_ids)
        m_rep = self.micro_repr(q_ids)
        q_rep = F.normalize(q_rep, dim=-1)
        m_rep = F.normalize(m_rep, dim=-1)
        logits = q_rep @ m_rep.T / temperature
        labels = torch.arange(q_rep.size(0), device=q_rep.device)
        return F.cross_entropy(logits, labels)

    def train_model(
            self, train_loader, test_loader, num_epochs, opt, ckpt_path,
            contrastive_weight=0.0, contrastive_temp=0.1, pos_weight=None
        ):
            '''
                Args:
                    train_loader: the PyTorch DataLoader instance for training
                    test_loader: the PyTorch DataLoader instance for test
                    num_epochs: the number of epochs
                    opt: the optimization to train this model
                    ckpt_path: the path to save this model's parameters
            '''
            aucs = []
            loss_means = []
            val_loss_means = []

            max_auc = 0

            # 모델이 위치한 device 확인
            device = next(self.parameters()).device 

            for i in range(1, num_epochs + 1):
                loss_mean = []

                # [Training Loop]
                self.train()
                for data in train_loader:
                    q, r, qshft, rshft, m = data

                    # 1. 데이터를 GPU로 이동
                    q = q.long().to(device)
                    r = r.long().to(device)
                    qshft = qshft.long().to(device)
                    rshft = rshft.to(device)
                    m = m.to(device)

                    # 2. [핵심 수정] qshft의 패딩(-1)을 0으로 치환
                    # one_hot은 음수 인덱스를 받을 수 없으므로, 임시로 0으로 바꿉니다.
                    # 실제 계산 결과는 어차피 마스크(m)에 의해 걸러지므로 0이어도 상관없습니다.
                    safe_qshft = torch.where(qshft >= 0, qshft, torch.tensor(0, device=device))

                    # 3. 모델 예측
                    y = self(q, r) # forward 내부에서 q, r의 패딩은 이미 처리됨

                    # 4. 정답 문제(safe_qshft)에 해당하는 예측값만 추출
                    # safe_qshft를 사용하여 에러 방지
                    y = (y * one_hot(safe_qshft, self.num_q)).sum(-1)

                    # 5. 마스킹 (실제 유효한 데이터만 남김)
                    y = torch.masked_select(y, m)
                    t = torch.masked_select(rshft, m)

                    opt.zero_grad()
                    if pos_weight is None:
                        loss = binary_cross_entropy(y, t)
                    else:
                        eps = 1e-7
                        loss = -(pos_weight * t * torch.log(y + eps) + (1 - t) * torch.log(1 - y + eps)).mean()
                    if self.micro_mode == "contrastive" and contrastive_weight > 0:
                        q_ids = torch.masked_select(qshft, m)
                        if q_ids.numel() > 0:
                            c_loss = self.contrastive_loss(q_ids, temperature=contrastive_temp)
                            if c_loss is not None:
                                loss = loss + contrastive_weight * c_loss
                    loss.backward()
                    opt.step()

                    loss_mean.append(loss.detach().cpu().numpy())

                # [Evaluation Loop]
                self.eval()
                y_list = []
                t_list = []
                val_loss_mean = []
                
                with torch.no_grad():
                    for data in test_loader:
                        q, r, qshft, rshft, m = data

                        q = q.long().to(device)
                        r = r.long().to(device)
                        qshft = qshft.long().to(device)
                        rshft = rshft.to(device)
                        m = m.to(device)

                        # Test 셋에서도 동일하게 처리
                        safe_qshft = torch.where(qshft >= 0, qshft, torch.tensor(0, device=device))

                        y = self(q, r)
                        y = (y * one_hot(safe_qshft, self.num_q)).sum(-1)

                        y = torch.masked_select(y, m)
                        t = torch.masked_select(rshft, m)

                        if y.numel() > 0:
                            loss = binary_cross_entropy(y, t)
                            val_loss_mean.append(loss.detach().cpu().numpy())
                        
                        y_list.append(y.detach().cpu())
                        t_list.append(t.detach().cpu())

                # 전체 결과 취합 후 AUC 계산
                all_y = torch.cat(y_list).numpy()
                all_t = torch.cat(t_list).numpy()

                auc = metrics.roc_auc_score(
                    y_true=all_t, y_score=all_y
                )

                loss_mean = np.mean(loss_mean)
                val_loss = float(np.mean(val_loss_mean)) if val_loss_mean else 0.0

                print(
                    "Epoch: {},   AUC: {:.4f},   Train Loss Mean: {:.4f},   Val Loss Mean: {:.4f}"
                    .format(i, auc, loss_mean, val_loss)
                )

                if auc > max_auc:
                    torch.save(
                        self.state_dict(),
                        os.path.join(
                            ckpt_path, "model.ckpt"
                        )
                    )
                    max_auc = auc

                aucs.append(auc)
                loss_means.append(loss_mean)
                val_loss_means.append(val_loss)

            return aucs, loss_means
