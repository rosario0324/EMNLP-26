import sys
import os
import argparse

def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

# 현재 파일의 부모의 부모 디렉토리(즉, 프로젝트 루트인 kt_collenction)를 경로에 추가
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
from typing import Dict, Tuple
from sklearn import metrics
import random

from dkt import DKT


def load_pid_map(map_path: str):
    with open(map_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}  # keys가 문자열로 저장됐을 수 있음
    return pid2idx, int(m["num_q"])


class EvalDataset(Dataset):
    def __init__(self, examples):
        self.examples = examples

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        return self.examples[idx]


def collate_eval(batch):
    q_seqs, r_seqs, tgt_idx, tgt_r = zip(*batch)
    max_len = max(len(q) for q in q_seqs)
    q_pad = np.full((len(batch), max_len), -1, dtype=np.int64)
    r_pad = np.zeros((len(batch), max_len), dtype=np.int64)
    for i, (q, r) in enumerate(zip(q_seqs, r_seqs)):
        q_pad[i, : len(q)] = q
        r_pad[i, : len(r)] = r
    return (
        torch.from_numpy(q_pad),
        torch.from_numpy(r_pad),
        torch.tensor(tgt_idx, dtype=torch.long),
        torch.tensor(tgt_r, dtype=torch.long),
    )


def build_loader(dataset, batch_size, num_workers, prefetch_factor, persistent_workers, pin_memory):
    kwargs = {
        "batch_size": batch_size,
        "shuffle": False,
        "collate_fn": collate_eval,
        "num_workers": num_workers,
    }
    if num_workers > 0:
        kwargs["prefetch_factor"] = prefetch_factor
        kwargs["persistent_workers"] = persistent_workers
    if pin_memory:
        kwargs["pin_memory"] = True
    return DataLoader(dataset, **kwargs)


def load_eval_examples(jsonl_path: Path, pid2idx: Dict[int, int], only_when_target_correct: bool = False):
    examples = []
    n_skipped = 0
    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            ex = json.loads(line)

            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))
            if only_when_target_correct and target_r != 1:
                continue

            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q, r = [], []
            ok = True
            for s in ex["input_sequence"]:
                pid = int(s["problem_id"])
                if pid not in pid2idx:
                    ok = False
                    break
                q.append(pid2idx[pid])
                r.append(int(s["result"]))
            if not ok or len(q) == 0:
                n_skipped += 1
                continue

            examples.append((q, r, pid2idx[target_pid], target_r))

    return examples, n_skipped


@torch.no_grad()
def eval_one_file(model, pid2idx, jsonl_path: Path, device: torch.device, batch_size: int, num_workers: int, prefetch_factor: int, persistent_workers: bool, pin_memory: bool):
    y_scores = []
    y_true = []

    examples, n_skipped = load_eval_examples(jsonl_path, pid2idx)
    if not examples:
        return {
            "file": str(jsonl_path),
            "n_eval": 0,
            "n_skipped": n_skipped,
            "auc": None,
            "acc@0.5": None,
            "logloss": None,
        }

    loader = build_loader(
        EvalDataset(examples),
        batch_size,
        num_workers,
        prefetch_factor,
        persistent_workers,
        pin_memory,
    )

    for q_t, r_t, tgt_idx, tgt_r in loader:
        q_t = q_t.to(device)
        r_t = r_t.to(device)
        tgt_idx = tgt_idx.to(device)

        y = model(q_t, r_t)
        lengths = (q_t >= 0).sum(dim=1)
        last_idx = lengths - 1
        row_idx = torch.arange(q_t.size(0), device=device)
        last_y = y[row_idx, last_idx, :]
        prob = last_y.gather(1, tgt_idx.unsqueeze(1)).squeeze(1)

        y_scores.extend(prob.detach().cpu().numpy())
        y_true.extend(tgt_r.numpy())

    y_scores = np.array(y_scores, dtype=np.float32)
    y_true = np.array(y_true, dtype=np.int32)

    if len(y_true) == 0:
        return {
            "file": str(jsonl_path),
            "n_eval": 0,
            "n_skipped": n_skipped,
            "auc": None,
            "acc@0.5": None,
            "logloss": None,
        }

    auc = metrics.roc_auc_score(y_true=y_true, y_score=y_scores) if len(np.unique(y_true)) > 1 else None
    acc = ( (y_scores >= 0.5).astype(np.int32) == y_true ).mean()
    ll = metrics.log_loss(y_true=y_true, y_pred=np.clip(y_scores, 1e-6, 1-1e-6))

    return {
        "file": str(jsonl_path),
        "n_eval": int(len(y_true)),
        "n_skipped": int(n_skipped),
        "auc": None if auc is None else float(auc),
        "acc@0.5": float(acc),
        "logloss": float(ll),
    }

# PPR task
def hit_at_k(rank_pos: int, k: int) -> float:
    return 1.0 if rank_pos <= k else 0.0


def ndcg_at_k(rank_pos: int, k: int) -> float:
    if rank_pos <= k:
        return 1.0 / np.log2(rank_pos + 1)
    return 0.0

@torch.no_grad()
def eval_bepkt_topk(
    model,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    device: torch.device,
    ks=(1, 3, 5, 10, 20, 50, 100),
    only_when_target_correct: bool = False,
    batch_size: int = 64,
    num_workers: int = 0,
    prefetch_factor: int = 2,
    persistent_workers: bool = False,
    pin_memory: bool = False,
):
    """
    BePKT benchmark JSONL 형식 가정:
      {
        "user_id": ...,
        "input_sequence": [
            {"problem_id": int, "result": 0/1, ...},
            ...
        ],
        "target_problem_id": int,
        "target_result": 0/1
      }

    - candidate_problems는 완전히 무시
    - y[:, -1, :] 전체 문제 분포에서 top-k 평가
    """

    ks = sorted(set(ks))
    max_k = max(ks)

    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}

    n_total = 0
    n_eval = 0
    n_skipped = 0

    examples, skipped = load_eval_examples(jsonl_path, pid2idx, only_when_target_correct)
    n_skipped += skipped
    n_total = len(examples) + n_skipped
    if not examples:
        out = {
            "file": str(jsonl_path),
            "n_total": n_total,
            "n_eval": 0,
            "n_skipped": n_skipped,
        }
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out

    loader = build_loader(
        EvalDataset(examples),
        batch_size,
        num_workers,
        prefetch_factor,
        persistent_workers,
        pin_memory,
    )

    for q_t, r_t, tgt_idx, _ in loader:
        q_t = q_t.to(device)
        r_t = r_t.to(device)
        tgt_idx = tgt_idx.to(device)

        y = model(q_t, r_t)
        lengths = (q_t >= 0).sum(dim=1)
        last_idx = lengths - 1
        row_idx = torch.arange(q_t.size(0), device=device)
        last_y = y[row_idx, last_idx, :]

        top_vals, top_idx = torch.topk(
            last_y, k=min(max_k, last_y.size(1))
        )
        top_idx = top_idx.cpu().numpy().tolist()
        tgt_idx_cpu = tgt_idx.cpu().numpy().tolist()

        for row, tgt in enumerate(tgt_idx_cpu):
            if tgt in top_idx[row]:
                rank_pos = top_idx[row].index(tgt) + 1
            else:
                rank_pos = 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)
            n_eval += 1

    out = {
        "file": str(jsonl_path),
        "n_total": n_total,
        "n_eval": n_eval,
        "n_skipped": n_skipped,
    }

    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out

    for k in ks:
        out[f"Hit@{k}"] = sums_hit[k] / n_eval
        out[f"NDCG@{k}"] = sums_ndcg[k] / n_eval

    return out


@torch.no_grad()
def eval_bepkt_topk_candidates(
    model,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    device: torch.device,
    ks=(1, 3, 5, 10, 20, 50, 100),
    only_when_target_correct: bool = False,
    max_candidates: int = 0,
):
    ks = sorted(set(ks))
    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}
    n_eval = 0
    n_skipped = 0
    rng = random.Random(42)

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            ex = json.loads(line)
            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))
            if only_when_target_correct and target_r != 1:
                continue
            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q, r = [], []
            ok = True
            for s in ex["input_sequence"]:
                pid = int(s["problem_id"])
                if pid not in pid2idx:
                    ok = False
                    break
                q.append(pid2idx[pid])
                r.append(int(s["result"]))
            if not ok or len(q) == 0:
                n_skipped += 1
                continue

            cand_raw = ex.get("candidate_problems")
            if not isinstance(cand_raw, list):
                n_skipped += 1
                continue
            candidates = [pid2idx[int(pid)] for pid in cand_raw if int(pid) in pid2idx]
            tgt = pid2idx[target_pid]
            if tgt not in candidates:
                candidates.append(tgt)

            if max_candidates and len(candidates) > max_candidates:
                others = [c for c in candidates if c != tgt]
                keep = rng.sample(others, max_candidates - 1)
                candidates = keep + [tgt]

            q_t = torch.tensor(q, device=device).unsqueeze(0)
            r_t = torch.tensor(r, device=device).unsqueeze(0)
            y = model(q_t, r_t)[:, -1, :]
            scores = y[0][candidates].detach().cpu().numpy()

            sorted_idx = np.argsort(-scores)
            rank_pos = int(np.where(sorted_idx == candidates.index(tgt))[0][0]) + 1 if tgt in candidates else 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)
            n_eval += 1

    out = {"n_eval": n_eval, "n_skipped": n_skipped}
    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out
    for k in ks:
        out[f"Hit@{k}"] = sums_hit[k] / n_eval
        out[f"NDCG@{k}"] = sums_ndcg[k] / n_eval
    return out

def main():
    parser = argparse.ArgumentParser(description="Evaluate DKT on BePKT benchmark.")
    parser.add_argument("--model-ckpt", type=str, default="./kt_collection/checkpoints/model.ckpt", help="모델 체크포인트 경로")
    parser.add_argument("--gpu", type=str, default="0", help="사용할 GPU 인덱스 (0 또는 1)")
    parser.add_argument("--map-path", type=str, default="./kt_collection/checkpoints/problem_id_map.json", help="problem_id 매핑 경로")
    parser.add_argument("--benchmark-dir", type=str, default="./CSEDM/BePKT/remapped_benchmark", help="벤치마크 JSONL 디렉토리")
    parser.add_argument("--k-list", type=str, default="10,20,30,40,50", help="평가할 K 리스트")
    parser.add_argument("--batch-size", type=int, default=64, help="평가 배치 크기")
    parser.add_argument("--num-workers", type=int, default=0, help="DataLoader 워커 수")
    parser.add_argument("--prefetch-factor", type=int, default=2, help="DataLoader prefetch factor (num_workers>0)")
    parser.add_argument("--persistent-workers", action="store_true", help="DataLoader persistent workers 사용")
    parser.add_argument("--pin-memory", action="store_true", help="DataLoader pin_memory 사용")
    parser.add_argument("--only-correct-target", action="store_true", help="target_result==1인 예제만 평가")
    parser.add_argument(
        "--eval-scope",
        choices=["full", "candidate"],
        default="full",
        help="추천 평가 범위 (full=전체 문제, candidate=candidate_problems)",
    )
    parser.add_argument("--use-candidate-problems", action="store_true", help="(deprecated) eval-scope=candidate")
    parser.add_argument("--max-candidates", type=int, default=0, help="후보 수 제한 (0=제한 없음)")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    if args.use_candidate_problems and args.eval_scope == "full":
        print("[Info] --use-candidate-problems is deprecated; use --eval-scope candidate")
    use_candidates = args.eval_scope == "candidate" or args.use_candidate_problems

    benchmark_dir = Path(args.benchmark_dir)
    k_list = [int(k.strip()) for k in args.k_list.split(",") if k.strip()]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pin_memory = args.pin_memory or device.type == "cuda"

    pid2idx, num_q = load_pid_map(str(args.map_path))

    model = DKT(num_q=num_q, emb_size=128, hidden_size=128).to(device)
    model.load_state_dict(torch.load(args.model_ckpt, map_location=device))
    model.eval()

    for K in k_list:
        path = benchmark_dir / f"benchmark_K{K}.jsonl"
        if not path.exists():
            print(f"[K={K}] 파일 없음: {path}")
            continue

        stats = eval_one_file(
            model,
            pid2idx,
            path,
            device,
            args.batch_size,
            args.num_workers,
            args.prefetch_factor,
            args.persistent_workers,
            pin_memory,
        )
        print(f"[K={K}] {stats}")

        ks = (1, 3, 5, 10, 20, 50)
        if use_candidates:
            r = eval_bepkt_topk_candidates(
                model,
                pid2idx,
                path,
                device,
                ks=ks,
                only_when_target_correct=args.only_correct_target,
                max_candidates=args.max_candidates,
            )
        else:
            r = eval_bepkt_topk(
                model,
                pid2idx,
                path,
                device,
                ks=ks,
                only_when_target_correct=args.only_correct_target,
                batch_size=args.batch_size,
                num_workers=args.num_workers,
                prefetch_factor=args.prefetch_factor,
                persistent_workers=args.persistent_workers,
                pin_memory=pin_memory,
            )

        print(f"[Rec | K={K}] n_eval={r['n_eval']} n_skipped={r['n_skipped']}")
        for k in ks:
            print(f"  Hit@{k}={r[f'Hit@{k}']} NDCG@{k}={r[f'NDCG@{k}']}")

if __name__ == "__main__":
    main()
