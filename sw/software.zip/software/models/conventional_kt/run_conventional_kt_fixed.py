#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import json
import math
import os
import random
import sys
from dataclasses import dataclass
from pathlib import Path

for _thread_key in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "BLIS_NUM_THREADS",
):
    os.environ.setdefault(_thread_key, "1")

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn import metrics
from torch.nn.functional import binary_cross_entropy, one_hot
from torch.optim import Adam
from torch.utils.data import DataLoader, Dataset

KT_ROOT = Path("../kt_collection/experiments")
sys.path.append(str(KT_ROOT / "dkt"))
sys.path.append(str(KT_ROOT / "dkt_plus"))
sys.path.append(str(KT_ROOT / "sakt"))
sys.path.append(str(KT_ROOT / "dkvmn"))

from dkt import DKT  # type: ignore
from dkt_plus import DKTPlus  # type: ignore
from sakt import SAKT  # type: ignore
from dkvmn import DKVMN  # type: ignore


def configure_cpu_threads() -> None:
    threads = int(os.environ.get("TORCH_NUM_THREADS", os.environ.get("OMP_NUM_THREADS", "1")))
    interop = int(os.environ.get("TORCH_NUM_INTEROP_THREADS", "1"))
    torch.set_num_threads(threads)
    try:
        torch.set_num_interop_threads(interop)
    except RuntimeError:
        pass


configure_cpu_threads()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def parse_list_col(x):
    if isinstance(x, list):
        return x
    return ast.literal_eval(x)


def load_split_users(path: str) -> dict[str, set[str]]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return {
        "train": {str(u) for u in payload["train_user_ids"]},
        "val": {str(u) for u in payload["val_user_ids"]},
        "test": {str(u) for u in payload["test_user_ids"]},
    }


def load_user_sequences(seq_csv_path: str, max_seq_len: int = 0):
    df = pd.read_csv(seq_csv_path)
    df.columns = [c.strip().lstrip("\ufeff") for c in df.columns]
    user_col = "user_id" if "user_id" in df.columns else "user"
    df["problem_sequence"] = df["problem_sequence"].apply(parse_list_col)
    df["result_sequence"] = df["result_sequence"].apply(parse_list_col)

    all_probs = sorted({int(p) for seq in df["problem_sequence"] for p in seq})
    pid2idx = {int(p): i for i, p in enumerate(all_probs)}
    idx2pid = {i: p for p, i in pid2idx.items()}

    user_sequences = []
    for _, row in df.iterrows():
        q_raw = row["problem_sequence"]
        r_raw = row["result_sequence"]
        if len(q_raw) != len(r_raw):
            continue
        q = [pid2idx[int(p)] for p in q_raw]
        r = [int(x) for x in r_raw]
        if max_seq_len and len(q) > max_seq_len:
            q = q[-max_seq_len:]
            r = r[-max_seq_len:]
        if len(q) < 2:
            continue
        user_sequences.append((str(row[user_col]), q, r))
    return user_sequences, pid2idx, idx2pid


def shifted_pos_weight(sequences) -> float | None:
    pos = 0
    neg = 0
    for _, q, r in sequences:
        vals = r[1:]
        pos += int(sum(int(x) for x in vals))
        neg += int(len(vals) - sum(int(x) for x in vals))
    if pos == 0:
        return None
    return float(neg) / float(pos)


class DKTSeqDataset(Dataset):
    def __init__(self, sequences, pad_q: int, pad_r: int, max_len: int, with_meta: bool = False, last_only: bool = False):
        self.sequences = sequences
        self.pad_q = pad_q
        self.pad_r = pad_r
        self.max_len = max_len
        self.with_meta = with_meta
        self.last_only = last_only

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        user_id, q, r = self.sequences[idx]
        q_in, r_in = q[:-1], r[:-1]
        qshft, rshft = q[1:], r[1:]
        event_idx = np.arange(1, len(q), dtype=np.int64)
        n = self.max_len - 1

        q_pad = np.full((n,), self.pad_q, dtype=np.int64)
        r_pad = np.full((n,), self.pad_r, dtype=np.int64)
        qshft_pad = np.full((n,), self.pad_q, dtype=np.int64)
        rshft_pad = np.full((n,), self.pad_r, dtype=np.float32)
        m = np.zeros((n,), dtype=np.bool_)
        e_pad = np.full((n,), -1, dtype=np.int64)

        cur = len(q_in)
        q_pad[:cur] = q_in
        r_pad[:cur] = r_in
        qshft_pad[:cur] = qshft
        rshft_pad[:cur] = rshft
        if self.last_only:
            m[cur - 1] = True
        else:
            m[:cur] = True
        e_pad[:cur] = event_idx

        base = (
            torch.from_numpy(q_pad),
            torch.from_numpy(r_pad),
            torch.from_numpy(qshft_pad),
            torch.from_numpy(rshft_pad),
            torch.from_numpy(m),
        )
        if not self.with_meta:
            return base
        return base + (torch.from_numpy(e_pad), user_id)


class SAKTSeqDataset(Dataset):
    def __init__(self, sequences, pad_q: int, pad_r: int, max_len: int, with_meta: bool = False, last_only: bool = False):
        self.sequences = sequences
        self.pad_q = pad_q
        self.pad_r = pad_r
        self.max_len = max_len
        self.with_meta = with_meta
        self.last_only = last_only

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        user_id, q, r = self.sequences[idx]
        q_in, r_in = q[:-1], r[:-1]
        qry, target = q[1:], r[1:]
        event_idx = np.arange(1, len(q), dtype=np.int64)
        n = self.max_len - 1

        q_pad = np.full((n,), self.pad_q, dtype=np.int64)
        r_pad = np.full((n,), self.pad_r, dtype=np.int64)
        qry_pad = np.full((n,), self.pad_q, dtype=np.int64)
        t_pad = np.full((n,), self.pad_r, dtype=np.float32)
        m = np.zeros((n,), dtype=np.bool_)
        e_pad = np.full((n,), -1, dtype=np.int64)

        cur = len(qry)
        q_pad[:cur] = q_in
        r_pad[:cur] = r_in
        qry_pad[:cur] = qry
        t_pad[:cur] = target
        if self.last_only:
            m[cur - 1] = True
        else:
            m[:cur] = True
        e_pad[:cur] = event_idx

        base = (
            torch.from_numpy(q_pad),
            torch.from_numpy(r_pad),
            torch.from_numpy(qry_pad),
            torch.from_numpy(t_pad),
            torch.from_numpy(m),
        )
        if not self.with_meta:
            return base
        return base + (torch.from_numpy(e_pad), user_id)


class DKVMNSeqDataset(Dataset):
    def __init__(self, sequences, pad_q: int, pad_r: int, max_len: int, with_meta: bool = False, last_only: bool = False):
        self.sequences = sequences
        self.pad_q = pad_q
        self.pad_r = pad_r
        self.max_len = max_len
        self.with_meta = with_meta
        self.last_only = last_only

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        user_id, q, r = self.sequences[idx]
        n = self.max_len
        event_idx = np.arange(len(q), dtype=np.int64)
        q_pad = np.full((n,), self.pad_q, dtype=np.int64)
        r_pad = np.full((n,), self.pad_r, dtype=np.int64)
        m = np.zeros((n,), dtype=np.bool_)
        e_pad = np.full((n,), -1, dtype=np.int64)
        cur = len(q)
        q_pad[:cur] = q
        r_pad[:cur] = r
        if self.last_only:
            m[cur - 1] = True
        else:
            m[:cur] = True
        e_pad[:cur] = event_idx
        base = (
            torch.from_numpy(q_pad),
            torch.from_numpy(r_pad),
            torch.from_numpy(m),
        )
        if not self.with_meta:
            return base
        return base + (torch.from_numpy(e_pad), user_id)


def build_loader(dataset, batch_size, shuffle, num_workers=0):
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, drop_last=False, num_workers=num_workers)


def eval_dkt(model, loader, num_q: int, device: torch.device, pred_out: str | None = None):
    model.eval()
    y_list = []
    t_list = []
    pred_rows = []
    with torch.no_grad():
        for batch in loader:
            if len(batch) == 7:
                q, r, qshft, rshft, m, event_idx, user_ids = batch
            else:
                q, r, qshft, rshft, m = batch
                event_idx, user_ids = None, None
            q = q.long().to(device)
            r = r.long().to(device)
            qshft = qshft.long().to(device)
            rshft = rshft.to(device)
            m = m.to(device)
            safe_qshft = torch.where(qshft >= 0, qshft, torch.tensor(0, device=device))
            y = model(q, r)
            y = (y * one_hot(safe_qshft, num_q)).sum(-1)
            y_masked = torch.masked_select(y, m)
            t_masked = torch.masked_select(rshft, m).float()
            if y_masked.numel() == 0:
                continue
            y_list.append(y_masked.detach().cpu())
            t_list.append(t_masked.detach().cpu())
            if pred_out and event_idx is not None:
                y_cpu = y.detach().cpu()
                t_cpu = rshft.detach().cpu()
                m_cpu = m.detach().cpu()
                e_cpu = event_idx.detach().cpu()
                for i, user_id in enumerate(user_ids):
                    valid = m_cpu[i].numpy().astype(bool)
                    for pred_val, target_val, event_val in zip(
                        y_cpu[i][valid].numpy(),
                        t_cpu[i][valid].numpy(),
                        e_cpu[i][valid].numpy(),
                    ):
                        pred_rows.append(
                            {
                                "user_id": str(user_id),
                                "event_idx": int(event_val),
                                "target": int(target_val),
                                "pred": float(pred_val),
                            }
                        )

    if not y_list:
        return {"auc": float("nan"), "rmse": float("nan"), "n_eval": 0}
    y_score = torch.cat(y_list).numpy()
    y_true = torch.cat(t_list).numpy()
    auc = metrics.roc_auc_score(y_true, y_score) if len(np.unique(y_true)) > 1 else float("nan")
    rmse = float(np.sqrt(metrics.mean_squared_error(y_true, y_score)))
    if pred_out and pred_rows:
        pd.DataFrame(pred_rows).to_csv(pred_out, index=False)
    return {"auc": float(auc), "rmse": rmse, "n_eval": int(len(y_true))}


def eval_sakt(model, loader, device: torch.device, pred_out: str | None = None):
    model.eval()
    y_list = []
    t_list = []
    pred_rows = []

    def align_with_mask(x: torch.Tensor, mask: torch.Tensor, name: str) -> torch.Tensor:
        if x.shape == mask.shape:
            return x
        if x.numel() == mask.numel():
            return x.reshape_as(mask)
        raise RuntimeError(f"Cannot align SAKT {name} shape {tuple(x.shape)} with mask shape {tuple(mask.shape)}")

    with torch.no_grad():
        for batch in loader:
            if len(batch) == 7:
                q, r, qry, t, m, event_idx, user_ids = batch
            else:
                q, r, qry, t, m = batch
                event_idx, user_ids = None, None
            q = q.long().to(device)
            r = r.long().to(device)
            qry = qry.long().to(device)
            t = t.to(device)
            m = m.to(device)
            p, _ = model(q, r, qry)
            p = align_with_mask(p, m, "prediction")
            t = align_with_mask(t, m, "target")
            if event_idx is not None:
                event_idx = align_with_mask(event_idx.to(device), m, "event_idx")
            p_masked = torch.masked_select(p, m)
            t_masked = torch.masked_select(t, m)
            if p_masked.numel() == 0:
                continue
            y_list.append(p_masked.detach().cpu())
            t_list.append(t_masked.detach().cpu())
            if pred_out and event_idx is not None:
                p_cpu = p.detach().cpu()
                t_cpu = t.detach().cpu()
                m_cpu = m.detach().cpu()
                e_cpu = event_idx.detach().cpu()
                for i, user_id in enumerate(user_ids):
                    valid = m_cpu[i].numpy().astype(bool)
                    for pred_val, target_val, event_val in zip(
                        p_cpu[i][valid].numpy(),
                        t_cpu[i][valid].numpy(),
                        e_cpu[i][valid].numpy(),
                    ):
                        pred_rows.append(
                            {
                                "user_id": str(user_id),
                                "event_idx": int(event_val),
                                "target": int(target_val),
                                "pred": float(pred_val),
                            }
                        )
    if not y_list:
        return {"auc": float("nan"), "rmse": float("nan"), "n_eval": 0}
    y_score = torch.cat(y_list).numpy()
    y_true = torch.cat(t_list).numpy()
    auc = metrics.roc_auc_score(y_true, y_score) if len(np.unique(y_true)) > 1 else float("nan")
    rmse = float(np.sqrt(metrics.mean_squared_error(y_true, y_score)))
    if pred_out and pred_rows:
        pd.DataFrame(pred_rows).to_csv(pred_out, index=False)
    return {"auc": float(auc), "rmse": rmse, "n_eval": int(len(y_true))}


def eval_dkvmn(model, loader, device: torch.device, pred_out: str | None = None):
    model.eval()
    y_list = []
    t_list = []
    pred_rows = []
    with torch.no_grad():
        for batch in loader:
            if len(batch) == 5:
                q, r, m, event_idx, user_ids = batch
            else:
                q, r, m = batch
                event_idx, user_ids = None, None
            q = q.long().to(device)
            r = r.long().to(device)
            m = m.to(device)
            p, _ = model(q, r)
            if p.dim() == 1:
                p = p.unsqueeze(0)
            # Align DKVMN evaluation with next-step KT metrics used by the other models.
            p = p[:, 1:]
            r = r[:, 1:]
            m = m[:, 1:]
            if event_idx is not None:
                event_idx = event_idx[:, 1:]
            p_masked = torch.masked_select(p, m)
            t_masked = torch.masked_select(r, m).float()
            if p_masked.numel() == 0:
                continue
            y_list.append(p_masked.detach().cpu())
            t_list.append(t_masked.detach().cpu())
            if pred_out and event_idx is not None:
                p_cpu = p.detach().cpu()
                r_cpu = r.detach().cpu()
                m_cpu = m.detach().cpu()
                e_cpu = event_idx.detach().cpu()
                for i, user_id in enumerate(user_ids):
                    valid = m_cpu[i].numpy().astype(bool)
                    for pred_val, target_val, event_val in zip(
                        p_cpu[i][valid].numpy(),
                        r_cpu[i][valid].numpy(),
                        e_cpu[i][valid].numpy(),
                    ):
                        pred_rows.append(
                            {
                                "user_id": str(user_id),
                                "event_idx": int(event_val),
                                "target": int(target_val),
                                "pred": float(pred_val),
                            }
                        )
    if not y_list:
        return {"auc": float("nan"), "rmse": float("nan"), "n_eval": 0}
    y_score = torch.cat(y_list).numpy()
    y_true = torch.cat(t_list).numpy()
    auc = metrics.roc_auc_score(y_true, y_score) if len(np.unique(y_true)) > 1 else float("nan")
    rmse = float(np.sqrt(metrics.mean_squared_error(y_true, y_score)))
    if pred_out and pred_rows:
        pd.DataFrame(pred_rows).to_csv(pred_out, index=False)
    return {"auc": float(auc), "rmse": rmse, "n_eval": int(len(y_true))}


@dataclass
class ModelDefaults:
    batch_size: int = 64
    num_epochs: int = 20
    lr: float = 1e-3
    emb_size: int = 128
    hidden_size: int = 128
    d: int = 128
    num_attn_heads: int = 4
    dropout: float = 0.2
    lambda_r: float = 0.01
    lambda_w1: float = 0.003
    lambda_w2: float = 3.0
    dim_s: int = 50
    size_m: int = 20
    pad_q: int = 0
    pad_r: int = 0


def train_and_eval(args):
    set_seed(args.seed)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    users_split = load_split_users(args.split_json)
    user_sequences, pid2idx, idx2pid = load_user_sequences(args.seq_csv_path, max_seq_len=args.max_seq_len)

    train_sequences = [x for x in user_sequences if x[0] in users_split["train"]]
    val_sequences = [x for x in user_sequences if x[0] in users_split["val"]]
    test_sequences = [x for x in user_sequences if x[0] in users_split["test"]]
    if not train_sequences or not val_sequences or not test_sequences:
        raise ValueError("Train/val/test split is empty under the provided split JSON.")

    num_q = len(pid2idx)
    max_len = max(len(q) for _, q, _ in user_sequences)
    defaults = ModelDefaults()
    if str(args.device).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(f"Requested CUDA device {args.device}, but CUDA is not available")
    device = torch.device(args.device if str(args.device).startswith("cuda") else "cpu")
    print(f"[device] {device}", flush=True)

    if args.family in {"dkt", "dkt_plus"}:
        pad_q = -1 if args.family == "dkt" else 0
        train_ds = DKTSeqDataset(train_sequences, pad_q=pad_q, pad_r=0, max_len=max_len, last_only=args.supervision_mode == "last_only")
        val_ds = DKTSeqDataset(val_sequences, pad_q=pad_q, pad_r=0, max_len=max_len, last_only=args.supervision_mode == "last_only")
        test_ds = DKTSeqDataset(test_sequences, pad_q=pad_q, pad_r=0, max_len=max_len, with_meta=True, last_only=args.supervision_mode == "last_only")
        train_loader = build_loader(train_ds, args.batch_size, True)
        val_loader = build_loader(val_ds, args.batch_size, False)
        test_loader = build_loader(test_ds, args.batch_size, False)

        if args.family == "dkt":
            model = DKT(num_q=num_q, emb_size=args.emb_size, hidden_size=args.hidden_size).to(device)
        else:
            model = DKTPlus(
                num_q=num_q,
                emb_size=args.emb_size,
                hidden_size=args.hidden_size,
                lambda_r=args.lambda_r,
                lambda_w1=args.lambda_w1,
                lambda_w2=args.lambda_w2,
            ).to(device)
        opt = Adam(model.parameters(), lr=args.lr)
        pos_weight = shifted_pos_weight(train_sequences) if args.auto_pos_weight else None
        best_auc = -1.0
        best_state = None
        for epoch in range(1, args.num_epochs + 1):
            model.train()
            train_losses = []
            for q, r, qshft, rshft, m in train_loader:
                q = q.long().to(device)
                r = r.long().to(device)
                qshft = qshft.long().to(device)
                rshft = rshft.to(device)
                m = m.to(device)
                opt.zero_grad()
                if args.family == "dkt":
                    safe_qshft = torch.where(qshft >= 0, qshft, torch.tensor(0, device=device))
                    y = model(q, r)
                    y = (y * one_hot(safe_qshft, num_q)).sum(-1)
                    y = torch.masked_select(y, m)
                    t = torch.masked_select(rshft, m)
                    if pos_weight is None:
                        loss = binary_cross_entropy(y, t)
                    else:
                        eps = 1e-7
                        loss = -(pos_weight * t * torch.log(y + eps) + (1 - t) * torch.log(1 - y + eps)).mean()
                else:
                    y = model(q.long(), r.long())
                    y_curr = (y * one_hot(q.long(), num_q)).sum(-1)
                    safe_qshft = torch.where(qshft >= 0, qshft, torch.tensor(0, device=device))
                    y_next = (y * one_hot(safe_qshft.long(), num_q)).sum(-1)
                    y_curr = torch.masked_select(y_curr, m)
                    y_next = torch.masked_select(y_next, m)
                    r_masked = torch.masked_select(r, m).float()
                    rshft_masked = torch.masked_select(rshft, m).float()
                    loss_w1 = torch.masked_select(torch.norm(y[:, 1:] - y[:, :-1], p=1, dim=-1), m[:, 1:])
                    loss_w2 = torch.masked_select((torch.norm(y[:, 1:] - y[:, :-1], p=2, dim=-1) ** 2), m[:, 1:])
                    if pos_weight is None:
                        bce_next = binary_cross_entropy(y_next, rshft_masked)
                        bce_curr = binary_cross_entropy(y_curr, r_masked)
                    else:
                        eps = 1e-7
                        bce_next = -(pos_weight * rshft_masked * torch.log(y_next + eps) + (1 - rshft_masked) * torch.log(1 - y_next + eps)).mean()
                        bce_curr = -(pos_weight * r_masked * torch.log(y_curr + eps) + (1 - r_masked) * torch.log(1 - y_curr + eps)).mean()
                    loss = (
                        bce_next
                        + model.lambda_r * bce_curr
                        + model.lambda_w1 * loss_w1.mean() / model.num_q
                        + model.lambda_w2 * loss_w2.mean() / model.num_q
                    )
                loss.backward()
                opt.step()
                train_losses.append(float(loss.item()))
            val_stats = eval_dkt(model, val_loader, num_q=num_q, device=device)
            print(
                f"Epoch {epoch} | val AUC: {val_stats['auc']:.4f} | "
                f"val RMSE: {val_stats['rmse']:.4f} | train loss: {np.mean(train_losses):.4f}"
            )
            if not math.isnan(val_stats["auc"]) and val_stats["auc"] > best_auc:
                best_auc = val_stats["auc"]
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}

        if best_state is None:
            raise RuntimeError("No valid best state found.")
        model.load_state_dict(best_state)
        torch.save(best_state, out_dir / "model.ckpt")
        val_stats_final = eval_dkt(model, val_loader, num_q=num_q, device=device, pred_out=args.val_pred_out)
        test_stats = eval_dkt(model, test_loader, num_q=num_q, device=device, pred_out=args.pred_out)

    elif args.family == "sakt":
        train_ds = SAKTSeqDataset(train_sequences, pad_q=0, pad_r=0, max_len=max_len, last_only=args.supervision_mode == "last_only")
        val_ds = SAKTSeqDataset(val_sequences, pad_q=0, pad_r=0, max_len=max_len, last_only=args.supervision_mode == "last_only")
        test_ds = SAKTSeqDataset(test_sequences, pad_q=0, pad_r=0, max_len=max_len, with_meta=True, last_only=args.supervision_mode == "last_only")
        train_loader = build_loader(train_ds, args.batch_size, True)
        val_loader = build_loader(val_ds, args.batch_size, False)
        test_loader = build_loader(test_ds, args.batch_size, False)
        model = SAKT(num_q=num_q, n=max_len - 1, d=args.d, num_attn_heads=args.num_attn_heads, dropout=args.dropout).to(device)
        opt = Adam(model.parameters(), lr=args.lr)
        best_auc = -1.0
        best_state = None
        for epoch in range(1, args.num_epochs + 1):
            model.train()
            train_losses = []
            for q, r, qry, t, m in train_loader:
                q = q.long().to(device)
                r = r.long().to(device)
                qry = qry.long().to(device)
                t = t.to(device)
                m = m.to(device)
                p, _ = model(q, r, qry)
                p = torch.masked_select(p, m)
                tgt = torch.masked_select(t, m)
                opt.zero_grad()
                loss = binary_cross_entropy(p, tgt)
                loss.backward()
                opt.step()
                train_losses.append(float(loss.item()))
            val_stats = eval_sakt(model, val_loader, device=device)
            print(
                f"Epoch {epoch} | val AUC: {val_stats['auc']:.4f} | "
                f"val RMSE: {val_stats['rmse']:.4f} | train loss: {np.mean(train_losses):.4f}"
            )
            if not math.isnan(val_stats["auc"]) and val_stats["auc"] > best_auc:
                best_auc = val_stats["auc"]
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
        if best_state is None:
            raise RuntimeError("No valid best state found.")
        model.load_state_dict(best_state)
        torch.save(best_state, out_dir / "model.ckpt")
        val_stats_final = eval_sakt(model, val_loader, device=device, pred_out=args.val_pred_out)
        test_stats = eval_sakt(model, test_loader, device=device, pred_out=args.pred_out)

    elif args.family == "dkvmn":
        train_ds = DKVMNSeqDataset(train_sequences, pad_q=0, pad_r=0, max_len=max_len, last_only=args.supervision_mode == "last_only")
        val_ds = DKVMNSeqDataset(val_sequences, pad_q=0, pad_r=0, max_len=max_len, last_only=args.supervision_mode == "last_only")
        test_ds = DKVMNSeqDataset(test_sequences, pad_q=0, pad_r=0, max_len=max_len, with_meta=True, last_only=args.supervision_mode == "last_only")
        train_loader = build_loader(train_ds, args.batch_size, True)
        val_loader = build_loader(val_ds, args.batch_size, False)
        test_loader = build_loader(test_ds, args.batch_size, False)
        model = DKVMN(num_q=num_q, dim_s=args.dim_s, size_m=args.size_m).to(device)
        opt = Adam(model.parameters(), lr=args.lr)
        pos_weight = shifted_pos_weight(train_sequences) if args.auto_pos_weight else None
        best_auc = -1.0
        best_state = None
        for epoch in range(1, args.num_epochs + 1):
            model.train()
            train_losses = []
            for q, r, m in train_loader:
                q = q.long().to(device)
                r = r.long().to(device)
                m = m.to(device)
                p, _ = model(q, r)
                if p.dim() == 1:
                    p = p.unsqueeze(0)
                p = p[:, 1:]
                r = r[:, 1:]
                m = m[:, 1:]
                p = torch.masked_select(p, m)
                tgt = torch.masked_select(r, m).float()
                opt.zero_grad()
                if pos_weight is None:
                    loss = binary_cross_entropy(p, tgt)
                else:
                    eps = 1e-7
                    loss = -(pos_weight * tgt * torch.log(p + eps) + (1 - tgt) * torch.log(1 - p + eps)).mean()
                loss.backward()
                opt.step()
                train_losses.append(float(loss.item()))
            val_stats = eval_dkvmn(model, val_loader, device=device)
            print(
                f"Epoch {epoch} | val AUC: {val_stats['auc']:.4f} | "
                f"val RMSE: {val_stats['rmse']:.4f} | train loss: {np.mean(train_losses):.4f}"
            )
            if not math.isnan(val_stats["auc"]) and val_stats["auc"] > best_auc:
                best_auc = val_stats["auc"]
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
        if best_state is None:
            raise RuntimeError("No valid best state found.")
        model.load_state_dict(best_state)
        torch.save(best_state, out_dir / "model.ckpt")
        val_stats_final = eval_dkvmn(model, val_loader, device=device, pred_out=args.val_pred_out)
        test_stats = eval_dkvmn(model, test_loader, device=device, pred_out=args.pred_out)
    else:
        raise ValueError(f"Unsupported family: {args.family}")

    with open(out_dir / "problem_id_map.json", "w", encoding="utf-8") as f:
        json.dump({"pid2idx": pid2idx, "idx2pid": idx2pid, "num_q": num_q}, f, ensure_ascii=False)
    with open(out_dir / "result.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "family": args.family,
                "seed": args.seed,
                "seq_csv_path": args.seq_csv_path,
                "split_json": args.split_json,
                "val_auc": val_stats_final["auc"],
                "val_rmse": val_stats_final["rmse"],
                "val_n_eval": val_stats_final["n_eval"],
                "test_auc": test_stats["auc"],
                "test_rmse": test_stats["rmse"],
                "n_eval": test_stats["n_eval"],
            },
            f,
            ensure_ascii=False,
            indent=2,
        )
    print(f">>> Test AUC: {test_stats['auc']:.4f}")
    print(f">>> Test RMSE: {test_stats['rmse']:.4f}")


def parse_args():
    p = argparse.ArgumentParser(description="Fixed-split KT rerun for conventional models with pred export.")
    p.add_argument("--family", choices=["dkt", "dkt_plus", "sakt", "dkvmn"], required=True)
    p.add_argument("--seq-csv-path", required=True)
    p.add_argument("--split-json", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--num-epochs", type=int, default=20)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--emb-size", type=int, default=128)
    p.add_argument("--hidden-size", type=int, default=128)
    p.add_argument("--d", type=int, default=128)
    p.add_argument("--num-attn-heads", type=int, default=4)
    p.add_argument("--dropout", type=float, default=0.2)
    p.add_argument("--lambda-r", type=float, default=0.01)
    p.add_argument("--lambda-w1", type=float, default=0.003)
    p.add_argument("--lambda-w2", type=float, default=3.0)
    p.add_argument("--dim-s", type=int, default=50)
    p.add_argument("--size-m", type=int, default=20)
    p.add_argument("--auto-pos-weight", action="store_true")
    p.add_argument("--pred-out", default=None)
    p.add_argument("--val-pred-out", default=None)
    p.add_argument("--max-seq-len", type=int, default=0)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--supervision-mode", choices=["all_steps", "last_only"], default="all_steps")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    train_and_eval(args)
