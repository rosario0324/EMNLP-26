import os

import numpy as np
import torch

from torch.nn import Module, Embedding, LSTM, Linear, Dropout
from torch.nn.functional import one_hot, binary_cross_entropy
import torch.nn.functional as F
from sklearn import metrics


class DKTPlus(Module):
    '''
        Args:
            num_q: the total number of the questions(KCs) in the given dataset
            emb_size: the dimension of the embedding vectors in this model
            hidden_size: the dimension of the hidden vectors in this model
            lambda_r: the hyperparameter of this model
            lambda_w1: the hyperparameter of this model
            lambda_w2: the hyperparameter of this model
    '''
    def __init__(
        self, num_q, emb_size, hidden_size, lambda_r, lambda_w1, lambda_w2,
        micro_emb=None, micro_mode="none"
    ):
        super().__init__()
        self.num_q = num_q
        self.emb_size = emb_size
        self.hidden_size = hidden_size
        self.lambda_r = lambda_r
        self.lambda_w1 = lambda_w1
        self.lambda_w2 = lambda_w2

        self.micro_mode = micro_mode
        self.use_micro = micro_emb is not None and micro_mode != "none"

        if self.use_micro:
            self.q_emb = Embedding(self.num_q, self.emb_size)
            self.r_emb = Embedding(2, self.emb_size)
            self.register_buffer("micro_emb", micro_emb)
            micro_dim = micro_emb.shape[1]
            self.micro_proj = Linear(micro_dim, self.emb_size, bias=False) if micro_dim != self.emb_size else None
            self.concat_proj = (
                Linear(self.emb_size * 2, self.emb_size, bias=False)
                if micro_mode in ("concat", "contrastive")
                else None
            )
            self.interaction_emb = None
        else:
            self.interaction_emb = Embedding(self.num_q * 2, self.emb_size)
            self.q_emb = None
            self.r_emb = None
            self.micro_proj = None
            self.concat_proj = None
        self.lstm_layer = LSTM(
            self.emb_size, self.hidden_size, batch_first=True
        )
        self.out_layer = Linear(self.hidden_size, self.num_q)
        self.dropout_layer = Dropout()

    def forward(self, q, r):
        '''
            Args:
                q: the question(KC) sequence with the size of [batch_size, n]
                r: the response sequence with the size of [batch_size, n]

            Returns:
                y: the knowledge level about the all questions(KCs)
        '''
        if not self.use_micro:
            x = q + self.num_q * r
            h, _ = self.lstm_layer(self.interaction_emb(x))
        else:
            q_rep = self.question_repr(q)
            r_rep = self.r_emb(r)
            h, _ = self.lstm_layer(q_rep + r_rep)
        y = self.out_layer(h)
        y = self.dropout_layer(y)
        y = torch.sigmoid(y)

        return y

    def _project_micro(self, micro_vec):
        return self.micro_proj(micro_vec) if self.micro_proj is not None else micro_vec

    def micro_repr(self, q):
        if not self.use_micro:
            raise RuntimeError("micro_repr called without micro embeddings.")
        return self._project_micro(self.micro_emb[q])

    def question_repr(self, q):
        if not self.use_micro:
            raise RuntimeError("question_repr called without micro embeddings.")
        micro = self._project_micro(self.micro_emb[q])
        if self.micro_mode == "replace":
            return micro
        base = self.q_emb(q)
        if self.concat_proj is not None:
            return self.concat_proj(torch.cat([base, micro], dim=-1))
        return base + micro

    def contrastive_loss(self, q_ids, temperature=0.1):
        if not self.use_micro:
            return None
        q_ids = torch.unique(q_ids)
        if q_ids.numel() == 0:
            return None
        q_rep = self.question_repr(q_ids)
        m_rep = self.micro_repr(q_ids)
        q_rep = F.normalize(q_rep, dim=-1)
        m_rep = F.normalize(m_rep, dim=-1)
        logits = q_rep @ m_rep.T / temperature
        labels = torch.arange(q_rep.size(0), device=q_rep.device)
        return F.cross_entropy(logits, labels)

    def train_model(
            self, train_loader, test_loader, num_epochs, opt, ckpt_path,
            contrastive_weight=0.0, contrastive_temp=0.1, pos_weight=None
        ):
        '''
            Args:
                train_loader: the PyTorch DataLoader instance for training
                test_loader: the PyTorch DataLoader instance for test
                num_epochs: the number of epochs
                opt: the optimization to train this model
                ckpt_path: the path to save this model's parameters
        '''
        aucs = []
        loss_means = []

        max_auc = 0

        for i in range(1, num_epochs + 1):
            loss_mean = []

            for data in train_loader:
                q, r, qshft, rshft, m = data

                self.train()

                y = self(q.long(), r.long())
                y_curr = (y * one_hot(q.long(), self.num_q)).sum(-1)
                y_next = (y * one_hot(qshft.long(), self.num_q)).sum(-1)

                y_curr = torch.masked_select(y_curr, m)
                y_next = torch.masked_select(y_next, m)
                r = torch.masked_select(r, m)
                rshft = torch.masked_select(rshft, m)

                loss_w1 = torch.masked_select(
                    torch.norm(y[:, 1:] - y[:, :-1], p=1, dim=-1),
                    m[:, 1:]
                )
                loss_w2 = torch.masked_select(
                    (torch.norm(y[:, 1:] - y[:, :-1], p=2, dim=-1) ** 2),
                    m[:, 1:]
                )

                opt.zero_grad()
                if pos_weight is None:
                    bce_next = binary_cross_entropy(y_next, rshft)
                    bce_curr = binary_cross_entropy(y_curr, r)
                else:
                    eps = 1e-7
                    bce_next = -(pos_weight * rshft * torch.log(y_next + eps) + (1 - rshft) * torch.log(1 - y_next + eps)).mean()
                    bce_curr = -(pos_weight * r * torch.log(y_curr + eps) + (1 - r) * torch.log(1 - y_curr + eps)).mean()
                loss = (
                    bce_next
                    + self.lambda_r * bce_curr
                    + self.lambda_w1 * loss_w1.mean() / self.num_q
                    + self.lambda_w2 * loss_w2.mean() / self.num_q
                )
                if self.micro_mode == "contrastive" and contrastive_weight > 0:
                    q_ids = torch.masked_select(qshft, m)
                    if q_ids.numel() > 0:
                        c_loss = self.contrastive_loss(q_ids, temperature=contrastive_temp)
                        if c_loss is not None:
                            loss = loss + contrastive_weight * c_loss
                loss.backward()
                opt.step()

                loss_mean.append(loss.detach().cpu().numpy())

            with torch.no_grad():
                for data in test_loader:
                    q, r, qshft, rshft, m = data

                    self.eval()

                    y = self(q.long(), r.long())
                    y_next = (y * one_hot(qshft.long(), self.num_q)).sum(-1)

                    y_next = torch.masked_select(y_next, m).detach().cpu()
                    rshft = torch.masked_select(rshft, m).detach().cpu()

                    auc = metrics.roc_auc_score(
                        y_true=rshft.numpy(), y_score=y_next.numpy()
                    )

                    loss_mean = np.mean(loss_mean)

                    print(
                        "Epoch: {},   AUC: {},   Loss Mean: {}"
                        .format(i, auc, loss_mean)
                    )

                    if auc > max_auc:
                        torch.save(
                            self.state_dict(),
                            os.path.join(
                                ckpt_path, "model.ckpt"
                            )
                        )
                        max_auc = auc

                    aucs.append(auc)
                    loss_means.append(loss_mean)

        return aucs, loss_means
