import sys
import os
import argparse

def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import json
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import torch
from sklearn import metrics
import random

from dkt_plus import DKTPlus


def load_pid2idx(map_path: str) -> Tuple[Dict[int, int], int]:
    m = json.load(open(map_path, "r", encoding="utf-8"))
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}
    num_q = int(m.get("num_q", len(pid2idx)))
    return pid2idx, num_q


def hit_at_k(rank_pos: int, k: int) -> float:
    return 1.0 if rank_pos <= k else 0.0


def ndcg_at_k(rank_pos: int, k: int) -> float:
    if rank_pos <= k:
        return 1.0 / np.log2(rank_pos + 1)
    return 0.0


@torch.no_grad()
def eval_topk_jsonl(
    model: DKTPlus,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    device: torch.device,
    ks=(1, 3, 5, 10, 20, 50, 100),
    ignore_target_result: bool = True,
    only_when_target_correct: bool = False,
):
    ks = sorted(set(ks))
    max_k = max(ks)

    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}

    target_probs = []
    target_results = []

    n_total = 0
    n_eval = 0
    n_skipped = 0

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            ex = json.loads(line)
            n_total += 1

            seq = ex["input_sequence"]
            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))

            if only_when_target_correct and target_r != 1:
                continue

            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q = []
            r = []
            ok = True
            for s in seq:
                pid = int(s["problem_id"])
                if pid not in pid2idx:
                    ok = False
                    break
                q.append(pid2idx[pid])
                r.append(int(s["result"]))
            if (not ok) or (len(q) == 0):
                n_skipped += 1
                continue

            q_t = torch.tensor(q, dtype=torch.long, device=device).unsqueeze(0)
            r_t = torch.tensor(r, dtype=torch.long, device=device).unsqueeze(0)

            y = model(q_t, r_t)[:, -1, :]
            scores = y[0].detach()

            tgt_idx = pid2idx[target_pid]
            pred_prob = scores[tgt_idx].item()

            target_probs.append(pred_prob)
            target_results.append(target_r)

            top_vals, top_idx = torch.topk(scores, k=min(max_k, scores.numel()))
            top_idx = top_idx.cpu().numpy().tolist()

            if tgt_idx in top_idx:
                rank_pos = top_idx.index(tgt_idx) + 1
            else:
                rank_pos = 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)

            n_eval += 1

    out = {
        "file": str(jsonl_path),
        "n_total": int(n_total),
        "n_eval": int(n_eval),
        "n_skipped": int(n_skipped),
        "ks": list(ks),
    }

    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out

    for k in ks:
        out[f"Hit@{k}"] = float(sums_hit[k] / n_eval)
        out[f"NDCG@{k}"] = float(sums_ndcg[k] / n_eval)

    target_results_np = np.array(target_results)
    target_probs_np = np.array(target_probs)

    try:
        auc = metrics.roc_auc_score(y_true=target_results_np, y_score=target_probs_np)
    except ValueError:
        auc = None
        print("[WARNING] AUC cannot be computed (only one class present in target_results).")

    predicted_labels = (target_probs_np >= 0.5).astype(int)
    acc_05 = (predicted_labels == target_results_np).mean() if target_results_np.size > 0 else None

    out["AUC"] = float(auc) if auc is not None else None
    out["ACC@0.5"] = float(acc_05) if acc_05 is not None else None

    return out


@torch.no_grad()
def eval_topk_candidates(
    model: DKTPlus,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    device: torch.device,
    ks=(1, 3, 5, 10, 20, 50, 100),
    only_when_target_correct: bool = False,
    max_candidates: int = 0,
):
    ks = sorted(set(ks))
    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}
    n_eval = 0
    n_skipped = 0
    rng = random.Random(42)

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            ex = json.loads(line)

            seq = ex["input_sequence"]
            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))

            if only_when_target_correct and target_r != 1:
                continue

            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q = []
            r = []
            ok = True
            for s in seq:
                pid = int(s["problem_id"])
                if pid not in pid2idx:
                    ok = False
                    break
                q.append(pid2idx[pid])
                r.append(int(s["result"]))
            if (not ok) or (len(q) == 0):
                n_skipped += 1
                continue

            cand_raw = ex.get("candidate_problems")
            if not isinstance(cand_raw, list):
                n_skipped += 1
                continue
            candidates = [pid2idx[int(pid)] for pid in cand_raw if int(pid) in pid2idx]
            tgt = pid2idx[target_pid]
            if tgt not in candidates:
                candidates.append(tgt)

            if max_candidates and len(candidates) > max_candidates:
                others = [c for c in candidates if c != tgt]
                keep = rng.sample(others, max_candidates - 1)
                candidates = keep + [tgt]

            q_t = torch.tensor(q, dtype=torch.long, device=device).unsqueeze(0)
            r_t = torch.tensor(r, dtype=torch.long, device=device).unsqueeze(0)

            y = model(q_t, r_t)[:, -1, :]
            scores = y[0][candidates].detach().cpu().numpy()

            target_pos = candidates.index(tgt)
            sorted_idx = np.argsort(-scores)
            rank_pos = int(np.where(sorted_idx == target_pos)[0][0]) + 1 if target_pos >= 0 else 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)

            n_eval += 1

    out = {"n_eval": n_eval, "n_skipped": n_skipped}
    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out

    for k in ks:
        out[f"Hit@{k}"] = sums_hit[k] / n_eval
        out[f"NDCG@{k}"] = sums_ndcg[k] / n_eval
    return out


def main():
    parser = argparse.ArgumentParser(description="Evaluate DKT+ on CSEDM.")
    parser.add_argument("--model-ckpt", type=str, default="./kt_collection/checkpoints/dktplus_csedm/model.ckpt")
    parser.add_argument("--map-path", type=str, default="./kt_collection/checkpoints/dktplus_csedm/problem_id_map.json")
    parser.add_argument("--gpu", type=str, default="0", help="사용할 GPU 인덱스 (0 또는 1)")
    parser.add_argument("--benchmark-dir", type=str, default="./CSEDM/S19_Release/benchmark")
    parser.add_argument("--k-list", type=str, default="10,20,30,40,50")
    parser.add_argument("--only-correct-target", action="store_true", help="target_result==1인 예제만 평가")
    parser.add_argument(
        "--eval-scope",
        choices=["full", "candidate"],
        default="full",
        help="추천 평가 범위 (full=전체 문제, candidate=candidate_problems)",
    )
    parser.add_argument("--use-candidate-problems", action="store_true", help="(deprecated) eval-scope=candidate")
    parser.add_argument("--max-candidates", type=int, default=0, help="후보 수 제한 (0=제한 없음)")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    if args.use_candidate_problems and args.eval_scope == "full":
        print("[Info] --use-candidate-problems is deprecated; use --eval-scope candidate")
    use_candidates = args.eval_scope == "candidate" or args.use_candidate_problems

    benchmark_dir = Path(args.benchmark_dir)
    K_LIST = [int(k.strip()) for k in args.k_list.split(",") if k.strip()]

    ks = (1, 3, 5, 10)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pid2idx, num_q = load_pid2idx(str(args.map_path))

    model = DKTPlus(
        num_q=num_q,
        emb_size=128,
        hidden_size=128,
        lambda_r=0.01,
        lambda_w1=0.003,
        lambda_w2=3.0,
    ).to(device)
    model.load_state_dict(torch.load(args.model_ckpt, map_location=device))
    model.eval()

    results = []
    fmt = lambda v: f"{v:.4f}" if v is not None else "NA"

    for K in K_LIST:
        p = benchmark_dir / f"benchmark_K{K}.jsonl"
        if not p.exists():
            print(f"[SKIP] not found: {p}")
            continue

        r = eval_topk_jsonl(
            model=model,
            pid2idx=pid2idx,
            jsonl_path=p,
            device=device,
            ks=ks,
            only_when_target_correct=args.only_correct_target,
        )
        if use_candidates:
            rec = eval_topk_candidates(
                model=model,
                pid2idx=pid2idx,
                jsonl_path=p,
                device=device,
                ks=ks,
                only_when_target_correct=args.only_correct_target,
                max_candidates=args.max_candidates,
            )
            print(f"[Rec-CAND] n_eval={rec['n_eval']} n_skipped={rec['n_skipped']}")
            for k in ks:
                print(f"  Hit@{k}={fmt(rec[f'Hit@{k}'])}  NDCG@{k}={fmt(rec[f'NDCG@{k}'])}")
        results.append(r)

        print(f"\n[K={K}] file={p.name}  n_eval={r['n_eval']}  n_skipped={r['n_skipped']}")
        print(f"  AUC={fmt(r['AUC'])}  ACC@0.5={fmt(r['ACC@0.5'])}")
        for k in ks:
            print(f"  Hit@{k}={fmt(r[f'Hit@{k}'])}  NDCG@{k}={fmt(r[f'NDCG@{k}'])}")

    out_path = benchmark_dir / "eval_topk_results_dktplus.json"
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n[OK] saved results: {out_path}")


if __name__ == "__main__":
    main()
