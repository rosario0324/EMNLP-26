import sys
import os

def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import json
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import torch
from sklearn import metrics
import random

from dkt_plus import DKTPlus


def load_pid_map(map_path: str):
    with open(map_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}
    return pid2idx, int(m["num_q"])


@torch.no_grad()
def eval_one_file(model, pid2idx, jsonl_path: Path, device: torch.device):
    y_scores = []
    y_true = []
    n_skipped = 0

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            ex = json.loads(line)

            seq = ex["input_sequence"]
            target_pid = ex["target_problem_id"]
            target_r = int(ex["target_result"])

            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q = []
            r = []
            ok = True
            for s in seq:
                pid = s["problem_id"]
                if pid not in pid2idx:
                    ok = False
                    break
                q.append(pid2idx[pid])
                r.append(int(s["result"]))
            if not ok or len(q) == 0:
                n_skipped += 1
                continue

            q_t = torch.tensor(q, dtype=torch.long, device=device).unsqueeze(0)
            r_t = torch.tensor(r, dtype=torch.long, device=device).unsqueeze(0)

            y = model(q_t, r_t)[:, -1, :]
            prob = y[0, pid2idx[target_pid]].item()

            y_scores.append(prob)
            y_true.append(target_r)

    y_scores = np.array(y_scores, dtype=np.float32)
    y_true = np.array(y_true, dtype=np.int32)

    if len(y_true) == 0:
        return {
            "file": str(jsonl_path),
            "n_eval": 0,
            "n_skipped": n_skipped,
            "auc": None,
            "acc@0.5": None,
            "logloss": None,
        }

    auc = metrics.roc_auc_score(y_true=y_true, y_score=y_scores) if len(np.unique(y_true)) > 1 else None
    acc = ((y_scores >= 0.5).astype(np.int32) == y_true).mean()
    ll = metrics.log_loss(y_true=y_true, y_pred=np.clip(y_scores, 1e-6, 1 - 1e-6))

    return {
        "file": str(jsonl_path),
        "n_eval": int(len(y_true)),
        "n_skipped": int(n_skipped),
        "auc": None if auc is None else float(auc),
        "acc@0.5": float(acc),
        "logloss": float(ll),
    }


def hit_at_k(rank_pos: int, k: int) -> float:
    return 1.0 if rank_pos <= k else 0.0


def ndcg_at_k(rank_pos: int, k: int) -> float:
    if rank_pos <= k:
        return 1.0 / np.log2(rank_pos + 1)
    return 0.0


@torch.no_grad()
def eval_bepkt_topk(
    model,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    device: torch.device,
    ks=(1, 3, 5, 10, 20, 50, 100),
    only_when_target_correct: bool = False,
):
    ks = sorted(set(ks))
    max_k = max(ks)

    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}

    n_total = 0
    n_eval = 0
    n_skipped = 0

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            ex = json.loads(line)
            n_total += 1

            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))

            if only_when_target_correct and target_r != 1:
                continue

            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q, r = [], []
            ok = True
            for s in ex["input_sequence"]:
                pid = int(s["problem_id"])
                if pid not in pid2idx:
                    ok = False
                    break
                q.append(pid2idx[pid])
                r.append(int(s["result"]))

            if not ok or len(q) == 0:
                n_skipped += 1
                continue

            q_t = torch.tensor(q, device=device).unsqueeze(0)
            r_t = torch.tensor(r, device=device).unsqueeze(0)

            y = model(q_t, r_t)[:, -1, :]
            scores = y[0]

            top_vals, top_idx = torch.topk(scores, k=min(max_k, scores.numel()))
            top_idx = top_idx.cpu().numpy().tolist()

            tgt = pid2idx[target_pid]
            if tgt in top_idx:
                rank_pos = top_idx.index(tgt) + 1
            else:
                rank_pos = 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)

            n_eval += 1

    out = {
        "file": str(jsonl_path),
        "n_total": n_total,
        "n_eval": n_eval,
        "n_skipped": n_skipped,
    }

    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out

    for k in ks:
        out[f"Hit@{k}"] = sums_hit[k] / n_eval
        out[f"NDCG@{k}"] = sums_ndcg[k] / n_eval

    return out


@torch.no_grad()
def eval_bepkt_topk_candidates(
    model,
    pid2idx: Dict[int, int],
    jsonl_path: Path,
    device: torch.device,
    ks=(1, 3, 5, 10, 20, 50, 100),
    only_when_target_correct: bool = False,
    max_candidates: int = 0,
):
    ks = sorted(set(ks))
    sums_hit = {k: 0.0 for k in ks}
    sums_ndcg = {k: 0.0 for k in ks}
    n_eval = 0
    n_skipped = 0
    rng = random.Random(42)

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            ex = json.loads(line)
            target_pid = int(ex["target_problem_id"])
            target_r = int(ex.get("target_result", 1))
            if only_when_target_correct and target_r != 1:
                continue
            if target_pid not in pid2idx:
                n_skipped += 1
                continue

            q, r = [], []
            ok = True
            for s in ex["input_sequence"]:
                pid = int(s["problem_id"])
                if pid not in pid2idx:
                    ok = False
                    break
                q.append(pid2idx[pid])
                r.append(int(s["result"]))
            if not ok or len(q) == 0:
                n_skipped += 1
                continue

            cand_raw = ex.get("candidate_problems")
            if not isinstance(cand_raw, list):
                n_skipped += 1
                continue
            candidates = [pid2idx[int(pid)] for pid in cand_raw if int(pid) in pid2idx]
            tgt = pid2idx[target_pid]
            if tgt not in candidates:
                candidates.append(tgt)

            if max_candidates and len(candidates) > max_candidates:
                others = [c for c in candidates if c != tgt]
                keep = rng.sample(others, max_candidates - 1)
                candidates = keep + [tgt]

            q_t = torch.tensor(q, device=device).unsqueeze(0)
            r_t = torch.tensor(r, device=device).unsqueeze(0)
            y = model(q_t, r_t)[:, -1, :]
            scores = y[0][candidates].detach().cpu().numpy()

            target_pos = candidates.index(tgt)
            sorted_idx = np.argsort(-scores)
            rank_pos = int(np.where(sorted_idx == target_pos)[0][0]) + 1 if target_pos >= 0 else 10**9

            for k in ks:
                sums_hit[k] += hit_at_k(rank_pos, k)
                sums_ndcg[k] += ndcg_at_k(rank_pos, k)
            n_eval += 1

    out = {"n_eval": n_eval, "n_skipped": n_skipped}
    if n_eval == 0:
        for k in ks:
            out[f"Hit@{k}"] = None
            out[f"NDCG@{k}"] = None
        return out
    for k in ks:
        out[f"Hit@{k}"] = sums_hit[k] / n_eval
        out[f"NDCG@{k}"] = sums_ndcg[k] / n_eval
    return out


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Evaluate DKT+ on BePKT.")
    parser.add_argument("--model-ckpt", type=str, default="./kt_collection/checkpoints/dktplus_bepkt/model.ckpt")
    parser.add_argument("--map-path", type=str, default="./kt_collection/checkpoints/dktplus_bepkt/problem_id_map.json")
    parser.add_argument("--gpu", type=str, default="0", help="사용할 GPU 인덱스 (0 또는 1)")
    parser.add_argument("--benchmark-dir", type=str, default="./CSEDM/BePKT/remapped_benchmark")
    parser.add_argument("--k-list", type=str, default="10,20,30,40,50")
    parser.add_argument("--only-correct-target", action="store_true", help="target_result==1인 예제만 평가")
    parser.add_argument(
        "--eval-scope",
        choices=["full", "candidate"],
        default="full",
        help="추천 평가 범위 (full=전체 문제, candidate=candidate_problems)",
    )
    parser.add_argument("--use-candidate-problems", action="store_true", help="(deprecated) eval-scope=candidate")
    parser.add_argument("--max-candidates", type=int, default=0, help="후보 수 제한 (0=제한 없음)")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    if args.use_candidate_problems and args.eval_scope == "full":
        print("[Info] --use-candidate-problems is deprecated; use --eval-scope candidate")
    use_candidates = args.eval_scope == "candidate" or args.use_candidate_problems

    benchmark_dir = Path(args.benchmark_dir)
    K_LIST = [int(k.strip()) for k in args.k_list.split(",") if k.strip()]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    pid2idx, num_q = load_pid_map(str(args.map_path))

    model = DKTPlus(
        num_q=num_q,
        emb_size=128,
        hidden_size=128,
        lambda_r=0.01,
        lambda_w1=0.003,
        lambda_w2=3.0,
    ).to(device)
    model.load_state_dict(torch.load(args.model_ckpt, map_location=device))
    model.eval()

    fmt = lambda v: f"{v:.4f}" if v is not None else "NA"
    ks = (1, 3, 5, 10, 20, 50)

    for K in K_LIST:
        path = benchmark_dir / f"benchmark_K{K}.jsonl"
        if not path.exists():
            print(f"[K={K}] 파일 없음: {path}")
            continue

        stats = eval_one_file(model, pid2idx, path, device)
        print(f"[K={K}] {stats}")

        if use_candidates:
            r = eval_bepkt_topk_candidates(
                model,
                pid2idx,
                path,
                device,
                ks=ks,
                only_when_target_correct=args.only_correct_target,
                max_candidates=args.max_candidates,
            )
        else:
            r = eval_bepkt_topk(
                model=model,
                pid2idx=pid2idx,
                jsonl_path=path,
                device=device,
                ks=ks,
                only_when_target_correct=args.only_correct_target,
            )

        print(f"\n[BePKT | K={K}]")
        print(f"  n_eval={r['n_eval']}  n_skipped={r['n_skipped']}")
        for k in ks:
            print(f"  Hit@{k}={fmt(r[f'Hit@{k}'])} NDCG@{k}={fmt(r[f'NDCG@{k}'])}")


if __name__ == "__main__":
    main()
