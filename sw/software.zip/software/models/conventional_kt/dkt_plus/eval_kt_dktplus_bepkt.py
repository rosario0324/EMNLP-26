import sys
import os
import argparse

def _maybe_set_cuda_visible_devices():
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        return
    for i, arg in enumerate(sys.argv):
        if arg == "--gpu" and i + 1 < len(sys.argv):
            os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[i + 1]
            return
        if arg.startswith("--gpu="):
            os.environ["CUDA_VISIBLE_DEVICES"] = arg.split("=", 1)[1]
            return


_maybe_set_cuda_visible_devices()

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import json
import ast
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from torch.nn.functional import one_hot, binary_cross_entropy
from sklearn import metrics

from dkt_plus import DKTPlus

DEFAULT_SEQ_CSV = "./CSEDM/BePKT/remapped_data/user_index_mapped_filteringQ4(17)_remapped.csv"
DEFAULT_OUT_DIR = "./kt_collection/checkpoints/dktplus_bepkt"


@dataclass
class EvalConfig:
    seq_csv_path: str = DEFAULT_SEQ_CSV
    out_dir: str = DEFAULT_OUT_DIR
    seed: int = 42
    val_ratio: float = 0.1

    emb_size: int = 128
    hidden_size: int = 128
    lambda_r: float = 0.01
    lambda_w1: float = 0.003
    lambda_w2: float = 3.0

    batch_size: int = 64
    pad_q: int = 0
    pad_r: int = 0


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_list_col(x):
    if isinstance(x, list):
        return x
    return ast.literal_eval(x)


class DKTDataset(Dataset):
    def __init__(self, sequences, num_q, pad_q=0, pad_r=0, max_len=None):
        self.sequences = sequences
        self.num_q = num_q
        self.pad_q = pad_q
        self.pad_r = pad_r
        self.max_len = max_len or max(len(q) for q, _ in sequences)

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        q, r = self.sequences[idx]

        q_in, r_in = q[:-1], r[:-1]
        qshft, rshft = q[1:], r[1:]
        n = self.max_len - 1

        q_pad = np.full((n,), self.pad_q, dtype=np.int64)
        r_pad = np.full((n,), self.pad_r, dtype=np.int64)
        qshft_pad = np.full((n,), self.pad_q, dtype=np.int64)
        rshft_pad = np.full((n,), self.pad_r, dtype=np.float32)
        m = np.zeros((n,), dtype=np.bool_)

        cur = len(q_in)
        q_pad[:cur] = q_in
        r_pad[:cur] = r_in
        qshft_pad[:cur] = qshft
        rshft_pad[:cur] = rshft
        m[:cur] = True

        return (
            torch.from_numpy(q_pad),
            torch.from_numpy(r_pad),
            torch.from_numpy(qshft_pad),
            torch.from_numpy(rshft_pad),
            torch.from_numpy(m),
        )


def build_loader(dataset, batch_size, shuffle, num_workers, prefetch_factor, persistent_workers, pin_memory):
    kwargs = {
        "batch_size": batch_size,
        "shuffle": shuffle,
        "drop_last": False,
        "num_workers": num_workers,
    }
    if num_workers > 0:
        kwargs["prefetch_factor"] = prefetch_factor
        kwargs["persistent_workers"] = persistent_workers
    if pin_memory:
        kwargs["pin_memory"] = True
    return DataLoader(dataset, **kwargs)


def load_pid_map(map_path):
    with open(map_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    pid2idx = {int(k): int(v) for k, v in m["pid2idx"].items()}
    num_q = int(m.get("num_q", len(pid2idx)))
    return pid2idx, num_q


def build_sequences(df, pid2idx):
    sequences = []
    skipped_unknown = 0
    skipped_short = 0
    skipped_mismatch = 0

    for _, row in df.iterrows():
        q_raw = parse_list_col(row["problem_sequence"])
        r_raw = parse_list_col(row["result_sequence"])
        if len(q_raw) != len(r_raw):
            skipped_mismatch += 1
            continue

        q = []
        ok = True
        for p in q_raw:
            pid = int(p)
            if pid not in pid2idx:
                ok = False
                break
            q.append(pid2idx[pid])
        if not ok:
            skipped_unknown += 1
            continue

        r = [int(x) for x in r_raw]
        if len(q) < 2:
            skipped_short += 1
            continue

        sequences.append((q, r))

    skipped = {
        "unknown_pid": skipped_unknown,
        "too_short": skipped_short,
        "length_mismatch": skipped_mismatch,
    }
    return sequences, skipped


def split_sequences(sequences, val_ratio, seed):
    rng = random.Random(seed)
    seqs = list(sequences)
    rng.shuffle(seqs)
    n_val = int(len(seqs) * val_ratio)
    return seqs[n_val:], seqs[:n_val]


def evaluate(model, loader, num_q, device):
    y_list = []
    t_list = []
    loss_vals = []

    with torch.no_grad():
        for q, r, qshft, rshft, m in loader:
            q = q.long().to(device)
            r = r.long().to(device)
            qshft = qshft.long().to(device)
            rshft = rshft.to(device)
            m = m.to(device)

            y = model(q, r)
            y_curr = (y * one_hot(q, num_q)).sum(-1)
            y_next = (y * one_hot(qshft, num_q)).sum(-1)

            y_curr_masked = torch.masked_select(y_curr, m).float()
            y_next_masked = torch.masked_select(y_next, m).float()
            r_masked = torch.masked_select(r, m).float()
            rshft_masked = torch.masked_select(rshft, m).float()

            if y_next_masked.numel() > 0:
                val_loss = binary_cross_entropy(y_next_masked, rshft_masked)
                if y_curr_masked.numel() > 0:
                    val_loss = val_loss + model.lambda_r * binary_cross_entropy(y_curr_masked, r_masked)

                loss_w1 = torch.masked_select(
                    torch.norm(y[:, 1:] - y[:, :-1], p=1, dim=-1), m[:, 1:]
                )
                loss_w2 = torch.masked_select(
                    torch.norm(y[:, 1:] - y[:, :-1], p=2, dim=-1) ** 2, m[:, 1:]
                )
                if loss_w1.numel() > 0:
                    val_loss = val_loss + model.lambda_w1 * loss_w1.mean() / model.num_q
                if loss_w2.numel() > 0:
                    val_loss = val_loss + model.lambda_w2 * loss_w2.mean() / model.num_q

                loss_vals.append(val_loss.detach().cpu().numpy())
                y_list.append(y_next_masked.detach().cpu())
                t_list.append(rshft_masked.detach().cpu())

    if not y_list:
        return {
            "auc": None,
            "acc@0.5": None,
            "logloss": None,
            "rmse": None,
            "loss": None,
            "n_eval": 0,
        }

    y_scores = torch.cat(y_list).numpy()
    y_true = torch.cat(t_list).numpy()
    n_eval = len(y_true)

    auc = metrics.roc_auc_score(y_true=y_true, y_score=y_scores) if len(np.unique(y_true)) > 1 else None
    acc = ((y_scores >= 0.5).astype(np.int32) == y_true.astype(np.int32)).mean()
    try:
        logloss = metrics.log_loss(y_true=y_true, y_pred=np.clip(y_scores, 1e-6, 1 - 1e-6))
    except ValueError:
        logloss = None

    rmse = float(np.sqrt(metrics.mean_squared_error(y_true, y_scores)))

    loss_mean = float(np.mean(loss_vals)) if loss_vals else None

    return {
        "auc": None if auc is None else float(auc),
        "acc@0.5": float(acc),
        "logloss": None if logloss is None else float(logloss),
        "rmse": float(rmse),
        "loss": None if loss_mean is None else float(loss_mean),
        "n_eval": int(n_eval),
    }


def main():
    parser = argparse.ArgumentParser(description="Evaluate DKT+ (KT) on BePKT sequences.")
    parser.add_argument("--model-ckpt", type=str, default=None, help="model checkpoint path")
    parser.add_argument("--map-path", type=str, default=None, help="problem_id map path")
    parser.add_argument("--seq-csv-path", type=str, default=None, help="sequence CSV path")
    parser.add_argument("--eval-split", choices=["val", "full"], default="val", help="eval split (val or full)")
    parser.add_argument("--val-ratio", type=float, default=None, help="validation ratio for val split")
    parser.add_argument("--seed", type=int, default=None, help="random seed")
    parser.add_argument("--emb-size", type=int, default=None, help="embedding size")
    parser.add_argument("--hidden-size", type=int, default=None, help="hidden size")
    parser.add_argument("--lambda-r", type=float, default=None, help="lambda_r")
    parser.add_argument("--lambda-w1", type=float, default=None, help="lambda_w1")
    parser.add_argument("--lambda-w2", type=float, default=None, help="lambda_w2")
    parser.add_argument("--batch-size", type=int, default=None, help="batch size")
    parser.add_argument("--num-workers", type=int, default=None, help="DataLoader workers")
    parser.add_argument("--prefetch-factor", type=int, default=2, help="DataLoader prefetch factor")
    parser.add_argument("--persistent-workers", action="store_true", help="use DataLoader persistent workers")
    parser.add_argument("--pin-memory", action="store_true", help="use DataLoader pin_memory")
    parser.add_argument("--gpu", type=str, default="0", help="GPU index")
    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    cfg = EvalConfig()
    if args.seq_csv_path:
        cfg.seq_csv_path = args.seq_csv_path
    if args.val_ratio is not None:
        cfg.val_ratio = args.val_ratio
    if args.seed is not None:
        cfg.seed = args.seed
    if args.emb_size is not None:
        cfg.emb_size = args.emb_size
    if args.hidden_size is not None:
        cfg.hidden_size = args.hidden_size
    if args.lambda_r is not None:
        cfg.lambda_r = args.lambda_r
    if args.lambda_w1 is not None:
        cfg.lambda_w1 = args.lambda_w1
    if args.lambda_w2 is not None:
        cfg.lambda_w2 = args.lambda_w2
    if args.batch_size is not None:
        cfg.batch_size = args.batch_size

    model_ckpt = args.model_ckpt or str(Path(cfg.out_dir) / "model.ckpt")
    map_path = args.map_path or str(Path(cfg.out_dir) / "problem_id_map.json")

    if not Path(model_ckpt).exists():
        raise FileNotFoundError(f"Checkpoint not found: {model_ckpt}")
    if not Path(map_path).exists():
        raise FileNotFoundError(f"Problem id map not found: {map_path}")

    set_seed(cfg.seed)

    df = pd.read_csv(cfg.seq_csv_path)
    df.columns = [c.strip().lstrip("\ufeff") for c in df.columns]

    pid2idx, num_q = load_pid_map(map_path)
    sequences, skipped = build_sequences(df, pid2idx)
    if not sequences:
        raise ValueError("No usable sequences after filtering.")

    max_len = max(len(q) for q, _ in sequences)

    if args.eval_split == "full":
        eval_sequences = sequences
    else:
        _, eval_sequences = split_sequences(sequences, cfg.val_ratio, cfg.seed)

    if not eval_sequences:
        raise ValueError("Eval split is empty. Adjust val_ratio or check data.")

    num_workers = args.num_workers if args.num_workers is not None else 4
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pin_memory = args.pin_memory or device.type == "cuda"

    eval_ds = DKTDataset(eval_sequences, num_q=num_q, pad_q=cfg.pad_q, pad_r=cfg.pad_r, max_len=max_len)
    eval_loader = build_loader(
        eval_ds, cfg.batch_size, False, num_workers, args.prefetch_factor, args.persistent_workers, pin_memory
    )

    model = DKTPlus(
        num_q=num_q,
        emb_size=cfg.emb_size,
        hidden_size=cfg.hidden_size,
        lambda_r=cfg.lambda_r,
        lambda_w1=cfg.lambda_w1,
        lambda_w2=cfg.lambda_w2,
    ).to(device)
    model.load_state_dict(torch.load(model_ckpt, map_location=device))
    model.eval()

    stats = evaluate(model, eval_loader, num_q=num_q, device=device)

    skipped_total = sum(skipped.values())
    fmt = lambda v: f"{v:.4f}" if v is not None else "NA"

    print(f"[Data] total_sequences={len(sequences)} eval_sequences={len(eval_sequences)} skipped={skipped_total}")
    print(f"  skipped_unknown_pid={skipped['unknown_pid']} skipped_too_short={skipped['too_short']} skipped_mismatch={skipped['length_mismatch']}")
    print(f"[Eval] n_eval={stats['n_eval']} loss={fmt(stats['loss'])}")
    print(f"  AUC={fmt(stats['auc'])} ACC@0.5={fmt(stats['acc@0.5'])} LOGLOSS={fmt(stats['logloss'])} RMSE={fmt(stats['rmse'])}")


if __name__ == "__main__":
    main()
