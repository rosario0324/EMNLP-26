import argparse
from pathlib import Path

import torch
from torch.utils.data import Dataset, DataLoader
from torch import nn, optim
from tqdm import tqdm

from data_utils import load_csedm_maintable, load_problem_embeddings, score_to_class
from model import IICECodeModel


class FeedbackDataset(Dataset):
    def __init__(self, df, problem_emb):
        self.df = df.reset_index(drop=True)
        self.problem_emb = problem_emb

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        p_idx = int(row["problem_idx"])
        p_emb = self.problem_emb[p_idx]
        return {
            "code": row["code"],
            "problem_text": row["problem_text"],
            "p_emb": p_emb,
            "label": score_to_class(float(row["score"])),
        }


def collate_fn(batch):
    codes = [b["code"] for b in batch]
    texts = [b["problem_text"] for b in batch]
    p_emb = torch.stack([b["p_emb"] for b in batch], dim=0)
    labels = torch.tensor([b["label"] for b in batch], dtype=torch.long)
    return codes, texts, p_emb, labels


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--main-csv", required=True)
    parser.add_argument("--code-states-csv", required=True)
    parser.add_argument("--problem-text-csv", required=True)
    parser.add_argument("--pro-id-dict", required=True)
    parser.add_argument("--problem-emb", required=True)
    parser.add_argument("--code-ckpt", required=True)
    parser.add_argument("--out-ckpt", required=True)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--lr", type=float, default=1e-5)
    parser.add_argument("--fuse-dim", type=int, default=256)
    parser.add_argument("--num-classes", type=int, default=3)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--freeze-gpt2", action="store_true")
    parser.add_argument("--freeze-codebert", action="store_true")
    args = parser.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    df = load_csedm_maintable(
        Path(args.main_csv),
        Path(args.code_states_csv),
        Path(args.problem_text_csv),
        Path(args.pro_id_dict),
    )
    problem_emb = load_problem_embeddings(Path(args.problem_emb))
    ds = FeedbackDataset(df, problem_emb)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, collate_fn=collate_fn)

    model = IICECodeModel(
        args.code_ckpt,
        problem_emb.size(1),
        fuse_dim=args.fuse_dim,
        num_classes=args.num_classes,
    )
    if args.freeze_gpt2:
        for p in model.text_encoder.parameters():
            p.requires_grad = False
    if args.freeze_codebert:
        for p in model.code_encoder.parameters():
            p.requires_grad = False
    model.to(device)

    opt = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr)
    loss_fn = nn.CrossEntropyLoss()

    model.train()
    for epoch in range(1, args.epochs + 1):
        total = 0.0
        count = 0
        for codes, texts, p_emb, labels in tqdm(loader, desc=f"epoch {epoch}"):
            p_emb = p_emb.to(device)
            labels = labels.to(device)
            opt.zero_grad()
            _, logits = model(p_emb, codes, texts)
            loss = loss_fn(logits, labels)
            loss.backward()
            opt.step()
            total += loss.item() * labels.size(0)
            count += labels.size(0)
        avg = total / max(1, count)
        print(f"epoch {epoch} loss {avg:.4f}")

    ckpt = {
        "model": model.state_dict(),
        "fuse_dim": args.fuse_dim,
        "problem_emb_dim": problem_emb.size(1),
        "code_ckpt": args.code_ckpt,
        "num_classes": args.num_classes,
    }
    Path(args.out_ckpt).parent.mkdir(parents=True, exist_ok=True)
    torch.save(ckpt, args.out_ckpt)
    print(f"saved {args.out_ckpt}")


if __name__ == "__main__":
    main()
