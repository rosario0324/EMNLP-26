import json
from pathlib import Path
from typing import Dict, Tuple

import pandas as pd
import torch


def load_pro_id_dict(path: Path) -> Dict[str, int]:
    text = path.read_text().strip()
    if not text:
        return {}
    data = eval(text)
    return {str(k): int(v) for k, v in data.items()}


def load_problem_text(problem_text_csv: Path) -> Dict[str, str]:
    df = pd.read_csv(problem_text_csv)
    text_col = None
    for cand in ["problem_text", "problem_text_en", "problem_text_kr", "requirement"]:
        if cand in df.columns:
            text_col = cand
            break
    if text_col is None:
        raise ValueError("problem_text csv must include a problem_text column")
    # prefer problem_id if exists, else problem_key
    if "problem_id" in df.columns:
        return {str(pid): str(txt) for pid, txt in df[["problem_id", text_col]].itertuples(index=False)}
    return {str(k): str(txt) for k, txt in df[["problem_key", text_col]].itertuples(index=False)}


def load_codestates(code_states_csv: Path) -> Dict[str, str]:
    df = pd.read_csv(code_states_csv)
    # columns: CodeStateID, Code
    if "CodeStateID" not in df.columns or "Code" not in df.columns:
        raise ValueError("CodeStates.csv must include CodeStateID and Code")
    return {str(cid): (code if isinstance(code, str) else "") for cid, code in df[["CodeStateID", "Code"]].itertuples(index=False)}


def load_csedm_maintable(
    main_csv: Path,
    code_states_csv: Path,
    problem_text_csv: Path,
    pro_id_dict: Path,
    event_type: str = "Run.Program",
):
    """
    Returns a filtered dataframe with columns:
      user_id, problem_id_raw, problem_idx, code, score, order, problem_text
    """
    df = pd.read_csv(main_csv)
    # filter run.program
    df = df[df["EventType"] == event_type].copy()
    # keep only rows with score
    df = df[df["Score"].notna()].copy()

    code_map = load_codestates(code_states_csv)
    text_map = load_problem_text(problem_text_csv)
    pro_map = load_pro_id_dict(pro_id_dict)

    df["code"] = df["CodeStateID"].astype(str).map(code_map).fillna("")
    df["problem_id_raw"] = df["ProblemID"].astype(str)
    df["problem_text"] = df["problem_id_raw"].map(text_map).fillna("")
    df["problem_idx"] = df["problem_id_raw"].map(pro_map)
    df = df[df["problem_idx"].notna()].copy()
    df["problem_idx"] = df["problem_idx"].astype(int)

    df = df.rename(columns={"SubjectID": "user_id", "Order": "order", "Score": "score"})
    df = df[["user_id", "problem_id_raw", "problem_idx", "code", "score", "order", "problem_text"]]
    return df


def score_to_class(score: float) -> int:
    # Error: 0, Buggy: (0,1), Accepted: 1
    if score <= 0:
        return 0
    if score >= 1:
        return 2
    return 1


def load_problem_embeddings(path: Path) -> torch.Tensor:
    return torch.load(path, map_location="cpu").float()
