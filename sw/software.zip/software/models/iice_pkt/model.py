import torch
import torch.nn as nn
from transformers import AutoTokenizer, AutoModel


def _load_plcodebert_weights(roberta, ckpt_path):
    if not ckpt_path:
        return
    checkpoint = torch.load(ckpt_path, map_location="cpu")
    state_dict = checkpoint.get("state_dict", checkpoint)
    new_state_dict = {
        k.replace("model.", "").replace("roberta.", ""): v
        for k, v in state_dict.items()
        if not k.startswith("classifier") and not k.startswith("Prediction")
    }
    roberta.load_state_dict(new_state_dict, strict=False)


class CodeTextEncoder(nn.Module):
    def __init__(self, ckpt_path, model_name="microsoft/codebert-base"):
        super().__init__()
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.roberta = AutoModel.from_pretrained(model_name)
        _load_plcodebert_weights(self.roberta, ckpt_path)

    def forward(self, texts):
        inputs = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors="pt",
        )
        inputs = {k: v.to(self.roberta.device) for k, v in inputs.items()}
        outputs = self.roberta(**inputs)
        return outputs.last_hidden_state[:, 0, :]


class ProblemTextEncoder(nn.Module):
    def __init__(self, model_name="gpt2"):
        super().__init__()
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.gpt2 = AutoModel.from_pretrained(model_name)

    def forward(self, texts):
        inputs = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=256,
            return_tensors="pt",
        )
        inputs = {k: v.to(self.gpt2.device) for k, v in inputs.items()}
        outputs = self.gpt2(**inputs)
        h = outputs.last_hidden_state
        mask = inputs["attention_mask"].unsqueeze(-1).float()
        denom = mask.sum(dim=1).clamp(min=1.0)
        return (h * mask).sum(dim=1) / denom


class FusionNetwork(nn.Module):
    def __init__(self, p_dim, c_dim, t_dim, fuse_dim=256, dropout=0.1, num_classes=3):
        super().__init__()
        self.p_proj = nn.Linear(p_dim, fuse_dim)
        self.c_proj = nn.Linear(c_dim, fuse_dim)
        self.t_proj = nn.Linear(t_dim, fuse_dim)
        self.fc = nn.Sequential(
            nn.Linear(fuse_dim * 3 + 3, fuse_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.cls = nn.Linear(fuse_dim, num_classes)

    def forward(self, p_emb, c_emb, t_emb):
        zp = self.p_proj(p_emb)
        zc = self.c_proj(c_emb)
        zt = self.t_proj(t_emb)
        spc = (zp * zc).sum(dim=-1, keepdim=True)
        spt = (zp * zt).sum(dim=-1, keepdim=True)
        sct = (zc * zt).sum(dim=-1, keepdim=True)
        lp = torch.cat([spc, spt, sct], dim=-1)
        z = torch.cat([zp, zc, zt, lp], dim=-1)
        fused = self.fc(z)
        logits = self.cls(fused)
        return fused, logits


class IICECodeModel(nn.Module):
    def __init__(
        self,
        code_ckpt,
        p_dim,
        fuse_dim=256,
        code_model_name="microsoft/codebert-base",
        gpt2_model_name="gpt2",
        num_classes=3,
    ):
        super().__init__()
        self.code_encoder = CodeTextEncoder(code_ckpt, code_model_name)
        self.text_encoder = ProblemTextEncoder(gpt2_model_name)
        c_dim = self.code_encoder.roberta.config.hidden_size
        t_dim = self.text_encoder.gpt2.config.hidden_size
        self.fusion = FusionNetwork(p_dim, c_dim, t_dim, fuse_dim, num_classes=num_classes)

    def forward(self, p_emb, code_texts, problem_texts):
        c_emb = self.code_encoder(code_texts)
        t_emb = self.text_encoder(problem_texts)
        fused, logits = self.fusion(p_emb, c_emb, t_emb)
        return fused, logits
