import argparse
import os
from pathlib import Path

for _thread_key in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "BLIS_NUM_THREADS",
    "RAYON_NUM_THREADS",
):
    os.environ.setdefault(_thread_key, os.environ.get("PKT_CPU_THREADS", "1"))
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("HF_ENABLE_PARALLEL_LOADING", "false")

import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm

from data_utils import load_problem_text, load_pro_id_dict, load_problem_embeddings
from model import IICECodeModel


def configure_cpu_threads() -> None:
    threads = int(os.environ.get("TORCH_NUM_THREADS", os.environ.get("OMP_NUM_THREADS", "1")))
    interop = int(os.environ.get("TORCH_NUM_INTEROP_THREADS", "1"))
    torch.set_num_threads(threads)
    try:
        torch.set_num_interop_threads(interop)
    except RuntimeError:
        pass


configure_cpu_threads()


class FusedDataset(Dataset):
    def __init__(self, df, problem_emb, problem_text_map, pro_id_map):
        self.df = df.reset_index(drop=True)
        self.problem_emb = problem_emb
        self.problem_text_map = problem_text_map
        self.pro_id_map = pro_id_map

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        pid = str(row["problem_id"])
        if pid in self.pro_id_map:
            p_idx = int(self.pro_id_map[pid])
        else:
            p_idx = int(row.get("problem_idx", -1))
        if p_idx < 0:
            raise ValueError(f"problem id missing in pro_id_dict: {pid}")
        p_emb = self.problem_emb[p_idx]
        p_text = self.problem_text_map.get(pid, "")
        return {
            "code": row["code"],
            "problem_text": p_text,
            "p_emb": p_emb,
        }


def collate_fn(batch):
    codes = [b["code"] for b in batch]
    texts = [b["problem_text"] for b in batch]
    p_emb = torch.stack([b["p_emb"] for b in batch], dim=0)
    return codes, texts, p_emb


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-csv", required=True)
    parser.add_argument("--problem-text-csv", required=True)
    parser.add_argument("--pro-id-dict", required=True)
    parser.add_argument("--problem-emb", required=True)
    parser.add_argument("--code-ckpt", required=True)
    parser.add_argument("--feedback-ckpt", required=True)
    parser.add_argument("--out-pt", required=True)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    df = pd.read_csv(args.data_csv)
    if "problem_id" not in df.columns:
        if "problem_idx" in df.columns:
            df = df.rename(columns={"problem_idx": "problem_id"})
        else:
            raise ValueError("CSV must include problem_id or problem_idx")

    problem_text_map = load_problem_text(Path(args.problem_text_csv))
    pro_id_map = load_pro_id_dict(Path(args.pro_id_dict))
    problem_emb = load_problem_embeddings(Path(args.problem_emb))

    ds = FusedDataset(df, problem_emb, problem_text_map, pro_id_map)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=False, collate_fn=collate_fn)

    ckpt = torch.load(args.feedback_ckpt, map_location="cpu")
    num_classes = ckpt.get("num_classes", 3)
    model = IICECodeModel(args.code_ckpt, problem_emb.size(1), num_classes=num_classes)
    model.load_state_dict(ckpt["model"], strict=False)
    model.to(device)
    model.eval()

    outputs = []
    with torch.no_grad():
        for codes, texts, p_emb in tqdm(loader, desc="fuse"):
            p_emb = p_emb.to(device)
            fused, _ = model(p_emb, codes, texts)
            outputs.append(fused.cpu())

    out = torch.cat(outputs, dim=0)
    Path(args.out_pt).parent.mkdir(parents=True, exist_ok=True)
    torch.save(out, args.out_pt)
    print(f"saved {args.out_pt} shape={tuple(out.shape)}")


if __name__ == "__main__":
    main()
