#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import DataLoader

import sys
sys.path.append("../PDKT")
from run_experiment import PDKTDataset, PDKTModel, _evaluate, _load_split_json, collate_fn


def _load_state_dict(path: str, device: torch.device):
    obj = torch.load(path, map_location=device)
    if isinstance(obj, dict) and "model_state_dict" in obj:
        return obj["model_state_dict"]
    return obj


def main():
    p = argparse.ArgumentParser(description="Eval-only fixed-split export for original PDKT.")
    p.add_argument("--data-csv", required=True)
    p.add_argument("--problem-feat", required=True)
    p.add_argument("--code-emb", required=True)
    p.add_argument("--split-json", required=True)
    p.add_argument("--model-ckpt", required=True)
    p.add_argument("--eval-split", choices=["train", "val", "test"], required=True)
    p.add_argument("--out-json", required=True)
    p.add_argument("--pred-out", required=True)
    p.add_argument("--hidden-dim", type=int, default=256)
    p.add_argument("--lambda-decay", type=float, default=0.6)
    p.add_argument("--max-seq-len", type=int, default=200)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--device", default="cuda:0")
    args = p.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    df = pd.read_csv(args.data_csv)
    prob_feats = torch.load(args.problem_feat, map_location="cpu").to("cpu")
    code_feats = torch.load(args.code_emb, map_location="cpu").to("cpu")
    max_pid = prob_feats.size(0) - 1
    df = df[df["problem_id"] <= max_pid]
    sort_cols = ["user_id"]
    if "Order" in df.columns:
        sort_cols.append("Order")
    elif "create_time" in df.columns:
        sort_cols.append("create_time")
    df = df.sort_values(sort_cols, kind="stable")

    split = _load_split_json(args.split_json)
    split_users = split[args.eval_split]
    user_to_idx = {str(uid): i for i, (uid, _) in enumerate(df.groupby("user_id", sort=False))}
    split_idx = [user_to_idx[u] for u in split_users if u in user_to_idx]

    ds = PDKTDataset(df, prob_feats, code_feats, split_idx)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=False, collate_fn=collate_fn)

    model = PDKTModel(prob_feats, hidden_dim=args.hidden_dim, lambda_decay=args.lambda_decay).to(device)
    model.load_state_dict(_load_state_dict(args.model_ckpt, device))

    auc, rmse, records = _evaluate(model, loader, collect_predictions=True)
    Path(args.out_json).write_text(
        json.dumps(
            {
                "eval_split": args.eval_split,
                "split_json": args.split_json,
                "model_ckpt": args.model_ckpt,
                "auc": auc,
                "rmse": rmse,
                "n_eval": len(records),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    pd.DataFrame.from_records(records).to_csv(args.pred_out, index=False)
    print(json.dumps({"auc": auc, "rmse": rmse, "n_eval": len(records)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
