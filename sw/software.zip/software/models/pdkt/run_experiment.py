import os

for _thread_key in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "BLIS_NUM_THREADS",
):
    os.environ.setdefault(_thread_key, "1")

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import json
import copy
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence
from sklearn.model_selection import KFold
from sklearn.metrics import roc_auc_score
from tqdm import tqdm


def configure_cpu_threads() -> None:
    threads = int(os.environ.get("TORCH_NUM_THREADS", os.environ.get("OMP_NUM_THREADS", "1")))
    interop = int(os.environ.get("TORCH_NUM_INTEROP_THREADS", "1"))
    torch.set_num_threads(threads)
    try:
        torch.set_num_interop_threads(interop)
    except RuntimeError:
        pass


configure_cpu_threads()

# --- loss helpers ---
def focal_loss(preds, targets, alpha=0.25, gamma=2.0, eps=1e-7):
    # preds, targets: shape [N], values in [0,1]
    p = preds.clamp(eps, 1 - eps)
    loss_pos = -alpha * (1 - p) ** gamma * targets * torch.log(p)
    loss_neg = -(1 - alpha) * p ** gamma * (1 - targets) * torch.log(1 - p)
    return (loss_pos + loss_neg).mean()

# --- 설정 ---
PROBLEM_FEAT_PATH = "./model/problem_features.pt"
CODE_EMB_PATH = "./model/code_embeddings.pt"
USER_SEQ_PATH = "./used_in_pdkt/user_sequence.csv"
MAX_SEQ_LEN = 200
BATCH_SIZE = 8
HIDDEN_DIM = 256
LAMBDA_DECAY = 0.6  # 논문 최적값 (Ablation 실험 시 변경 가능)
N_FOLDS = 5
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# --- 데이터셋 클래스 ---
class PDKTDataset(Dataset):
    def __init__(self, df, problem_features, code_embeddings, indices):
        self.df = df
        self.problem_features = problem_features # Tensor: [max_prob_id+1, dim]
        self.code_embeddings = code_embeddings   # Tensor: [total_rows, dim]
        
        # User별 그룹화
        self.user_groups = list(df.groupby('user_id', sort=False))
        self.selected_users = [self.user_groups[i] for i in indices] # Train/Test split 적용

    def __len__(self):
        return len(self.selected_users)

    def __getitem__(self, idx):
        user_id, group = self.selected_users[idx]
        
        # 원본 데이터프레임의 인덱스를 사용하여 미리 추출된 code embedding을 가져옴
        row_indices = group.index.values
        
        problem_ids = group['problem_id'].values
        results = group['result'].values
        event_idx = np.arange(len(group), dtype=np.int64)
        code_vecs = self.code_embeddings[row_indices] # [seq_len, 768]

        # 최대 길이 제한 (최근 데이터 유지)
        if len(problem_ids) > MAX_SEQ_LEN:
            problem_ids = problem_ids[-MAX_SEQ_LEN:]
            results = results[-MAX_SEQ_LEN:]
            event_idx = event_idx[-MAX_SEQ_LEN:]
            code_vecs = code_vecs[-MAX_SEQ_LEN:]

        return {
            'user_id': str(user_id),
            'p_ids': torch.tensor(problem_ids, dtype=torch.long),
            'r_ids': torch.tensor(results, dtype=torch.long),
            'event_idx': torch.tensor(event_idx, dtype=torch.long),
            'c_vecs': code_vecs,
            'labels': torch.tensor(results, dtype=torch.float)
        }

class PDKTSampleDataset(Dataset):
    def __init__(self, sample_df, problem_features, code_embeddings):
        self.sample_df = sample_df.reset_index(drop=True)
        self.problem_features = problem_features
        self.code_embeddings = code_embeddings

    def __len__(self):
        return len(self.sample_df)

    def __getitem__(self, idx):
        row = self.sample_df.iloc[idx]
        problem_ids = np.array(json.loads(row["problem_sequence"]), dtype=np.int64)
        results = np.array(json.loads(row["result_sequence"]), dtype=np.int64)
        row_indices = np.array(json.loads(row["row_index_sequence"]), dtype=np.int64)
        event_idx = row_indices.copy()
        code_vecs = self.code_embeddings[row_indices]

        if len(problem_ids) > MAX_SEQ_LEN:
            problem_ids = problem_ids[-MAX_SEQ_LEN:]
            results = results[-MAX_SEQ_LEN:]
            event_idx = event_idx[-MAX_SEQ_LEN:]
            code_vecs = code_vecs[-MAX_SEQ_LEN:]

        return {
            'user_id': str(row["sample_id"]),
            'p_ids': torch.tensor(problem_ids, dtype=torch.long),
            'r_ids': torch.tensor(results, dtype=torch.long),
            'event_idx': torch.tensor(event_idx, dtype=torch.long),
            'c_vecs': code_vecs,
            'labels': torch.tensor(results, dtype=torch.float)
        }

def collate_fn(batch):
    p_ids = pad_sequence([b['p_ids'] for b in batch], batch_first=True, padding_value=0)
    r_ids = pad_sequence([b['r_ids'] for b in batch], batch_first=True, padding_value=-1)
    event_idx = pad_sequence([b['event_idx'] for b in batch], batch_first=True, padding_value=-1)
    c_vecs = pad_sequence([b['c_vecs'] for b in batch], batch_first=True, padding_value=0)
    labels = pad_sequence([b['labels'] for b in batch], batch_first=True, padding_value=-1)
    user_ids = [b['user_id'] for b in batch]
    return p_ids, r_ids, c_vecs, labels, event_idx, user_ids

# --- PDKT 모델 ---
class PDKTModel(nn.Module):
    def __init__(self, pretrained_prob_emb, hidden_dim=256, code_dim=768, lambda_decay=0.6):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.lambda_decay = lambda_decay
        
        # 문제 임베딩 로드 (Freeze)
        self.prob_emb = nn.Embedding.from_pretrained(pretrained_prob_emb, freeze=True)
        p_dim = pretrained_prob_emb.size(1)
        self.res_emb = nn.Embedding(3, p_dim)
        self.p2h = nn.Linear(p_dim, hidden_dim)
        
        self.rnn_p = nn.RNN(p_dim, hidden_dim, batch_first=True)
        self.rnn_c = nn.RNN(code_dim, hidden_dim, batch_first=True)
        
        self.fc_g = nn.Linear(hidden_dim + p_dim, hidden_dim)
        self.fc_h = nn.Linear(hidden_dim + p_dim, hidden_dim)
        self.out = nn.Linear(hidden_dim * 2, 1)

    def exponential_decay_attention(self, history, target):
        # history: [B, T, H], target: [B, 1, H]
        scores = torch.bmm(history, target.transpose(1, 2)).squeeze(-1) # [B, T]
        
        seq_len = history.size(1)
        steps = torch.arange(seq_len, 0, -1).float().to(history.device)
        decay = torch.exp(-self.lambda_decay * steps)
        
        attn = F.softmax(scores * decay, dim=-1)
        context = torch.bmm(attn.unsqueeze(1), history).squeeze(1) # [B, H]
        return context

    def all_step_exponential_decay_attention(self, history, targets):
        # history: [B, L, H], targets: [B, L-1, H].
        # For prediction step t, attend only to history positions <= t.
        bsz, seq_len, _ = history.shape
        out_len = targets.size(1)
        scores = torch.bmm(history, targets.transpose(1, 2))  # [B, L, L-1]
        hist_pos = torch.arange(seq_len, device=history.device).view(seq_len, 1)
        pred_pos = torch.arange(out_len, device=history.device).view(1, out_len)
        valid = hist_pos <= pred_pos
        distance = (pred_pos + 1 - hist_pos).clamp_min(1).to(history.dtype)
        decay = torch.exp(-self.lambda_decay * distance)
        scores = scores * decay.unsqueeze(0)
        scores = scores.masked_fill(~valid.unsqueeze(0), torch.finfo(scores.dtype).min)
        attn = F.softmax(scores, dim=1)
        return torch.einsum("blt,blh->bth", attn, history)

    def forward(self, p_ids, r_ids, c_vecs):
        p_emb = self.prob_emb(p_ids) # [B, L, p_dim]
        r_ids = r_ids.clamp(min=-1, max=1) + 1
        r_emb = self.res_emb(r_ids)
        
        # RNN
        g_out, _ = self.rnn_p(p_emb + r_emb) 
        h_out, _ = self.rnn_c(c_vecs)

        if p_emb.size(1) < 2:
            return torch.zeros((p_emb.size(0), 0), device=p_emb.device)

        # 표준 KT: 시점 t까지의 기록(q_t, r_t)으로 모든 r_{t+1}을 한 번에 예측한다.
        curr_p = p_emb[:, 1:, :]
        curr_p_h = self.p2h(curr_p)
        ctx_g = self.all_step_exponential_decay_attention(g_out, curr_p_h)
        ctx_h = self.all_step_exponential_decay_attention(h_out, curr_p_h)
        logit_g = F.relu(self.fc_g(torch.cat([ctx_g, curr_p], -1)))
        logit_h = F.relu(self.fc_h(torch.cat([ctx_h, curr_p], -1)))
        final = torch.cat([logit_g, logit_h], -1)
        return torch.sigmoid(self.out(final)).squeeze(-1)

# --- 실험 실행 함수 ---
def _evaluate(model, loader, collect_predictions=False):
    model.eval()
    all_preds, all_targets = [], []
    records = []
    with torch.no_grad():
        for p_ids, r_ids, c_vecs, labels, event_idx, user_ids in loader:
            p_ids, r_ids, c_vecs, labels = p_ids.to(DEVICE), r_ids.to(DEVICE), c_vecs.to(DEVICE), labels.to(DEVICE)
            preds = model(p_ids, r_ids, c_vecs)
            targets = labels[:, 1:]
            mask = targets != -1
            all_preds.extend(preds[mask].cpu().numpy())
            all_targets.extend(targets[mask].cpu().numpy())
            if collect_predictions:
                preds_cpu = preds.detach().cpu()
                targets_cpu = targets.detach().cpu()
                events_cpu = event_idx[:, 1:].detach().cpu()
                mask_cpu = mask.detach().cpu()
                for i, user_id in enumerate(user_ids):
                    valid = mask_cpu[i]
                    pred_vals = preds_cpu[i][valid].tolist()
                    target_vals = targets_cpu[i][valid].tolist()
                    event_vals = events_cpu[i][valid].tolist()
                    for event_val, target_val, pred_val in zip(event_vals, target_vals, pred_vals):
                        records.append(
                            {
                                "user_id": str(user_id),
                                "event_idx": int(event_val),
                                "target": float(target_val),
                                "pred": float(pred_val),
                            }
                        )
    if not all_targets:
        return None, None, records
    auc = roc_auc_score(all_targets, all_preds)
    rmse = float(np.sqrt(np.mean((np.array(all_preds) - np.array(all_targets)) ** 2)))
    return auc, rmse, records


def _evaluate_last_only(model, loader, collect_predictions=False):
    model.eval()
    all_preds, all_targets = [], []
    records = []
    with torch.no_grad():
        for p_ids, r_ids, c_vecs, labels, event_idx, user_ids in loader:
            p_ids, r_ids, c_vecs, labels = p_ids.to(DEVICE), r_ids.to(DEVICE), c_vecs.to(DEVICE), labels.to(DEVICE)
            preds = model(p_ids, r_ids, c_vecs)
            if preds.numel() == 0:
                continue
            seq_lengths = (labels != -1).sum(dim=1)
            pred_pos = seq_lengths - 2
            valid = pred_pos >= 0
            if valid.sum() == 0:
                continue
            batch_idx = torch.arange(labels.size(0), device=labels.device)[valid]
            pred_pos = pred_pos[valid]
            pred_vals = preds[batch_idx, pred_pos]
            target_vals = labels[batch_idx, pred_pos + 1]
            all_preds.extend(pred_vals.detach().cpu().numpy())
            all_targets.extend(target_vals.detach().cpu().numpy())
            if collect_predictions:
                event_cpu = event_idx.detach().cpu()
                for out_i, b_idx in enumerate(batch_idx.detach().cpu().tolist()):
                    pos = int(pred_pos.detach().cpu().tolist()[out_i])
                    records.append(
                        {
                            "user_id": str(user_ids[b_idx]),
                            "event_idx": int(event_cpu[b_idx, pos + 1]),
                            "target": float(target_vals.detach().cpu().tolist()[out_i]),
                            "pred": float(pred_vals.detach().cpu().tolist()[out_i]),
                        }
                    )
    if not all_targets:
        return None, None, records
    auc = roc_auc_score(all_targets, all_preds) if len(np.unique(all_targets)) > 1 else float("nan")
    rmse = float(np.sqrt(np.mean((np.array(all_preds) - np.array(all_targets)) ** 2)))
    return auc, rmse, records


def _load_split_json(path):
    payload = json.loads(open(path, "r", encoding="utf-8").read())
    return {
        "train": {str(u) for u in payload["train_user_ids"]},
        "val": {str(u) for u in payload["val_user_ids"]},
        "test": {str(u) for u in payload["test_user_ids"]},
    }


def run_experiment(args):
    global MAX_SEQ_LEN, BATCH_SIZE, HIDDEN_DIM, LAMBDA_DECAY, DEVICE
    MAX_SEQ_LEN = args.max_seq_len
    BATCH_SIZE = args.batch_size
    HIDDEN_DIM = args.hidden_dim
    LAMBDA_DECAY = args.lambda_decay
    DEVICE = args.device
    if str(DEVICE).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(f"Requested CUDA device {DEVICE}, but CUDA is not available")
    print(f"[device] {DEVICE}", flush=True)

    print("Loading Data...")
    df = pd.read_csv(args.data_csv)
    prob_feats = torch.load(args.problem_feat, map_location="cpu").to("cpu")
    code_feats = torch.load(args.code_emb, map_location="cpu").to("cpu")

    max_pid = prob_feats.size(0) - 1
    df = df[df["problem_id"] <= max_pid]
    sort_cols = ["user_id"]
    if "Order" in df.columns:
        sort_cols.append("Order")
    elif "create_time" in df.columns:
        sort_cols.append("create_time")
    # Preserve original row indices for code embedding lookup while forcing
    # a stable chronological order inside each user sequence.
    df = df.sort_values(sort_cols, kind="stable")

    unique_users = df["user_id"].astype(str).unique()
    sample_df = pd.read_csv(args.seq_sample_csv) if args.seq_sample_csv else None

    if args.kfold > 1:
        kf = KFold(n_splits=args.kfold, shuffle=True, random_state=args.seed)
        fold_aucs, fold_rmses = [], []
        for fold, (train_idx, test_idx) in enumerate(kf.split(unique_users)):
            print(f"\n=== Fold {fold+1}/{args.kfold} ===")
            train_ds = PDKTDataset(df, prob_feats, code_feats, train_idx)
            test_ds = PDKTDataset(df, prob_feats, code_feats, test_idx)
            train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_fn)
            test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)

            model = PDKTModel(prob_feats, hidden_dim=HIDDEN_DIM, lambda_decay=LAMBDA_DECAY).to(DEVICE)
            optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
            use_focal = args.focal_gamma is not None and args.focal_alpha is not None
            if use_focal:
                def compute_loss(preds, targets):
                    return focal_loss(preds, targets, alpha=args.focal_alpha, gamma=args.focal_gamma)
            else:
                criterion = nn.BCELoss()
                def compute_loss(preds, targets):
                    return criterion(preds, targets)

            for epoch in range(args.epochs):
                model.train()
                epoch_loss = 0
                for p_ids, r_ids, c_vecs, labels, event_idx, user_ids in train_loader:
                    p_ids, r_ids, c_vecs, labels = p_ids.to(DEVICE), r_ids.to(DEVICE), c_vecs.to(DEVICE), labels.to(DEVICE)
                    optimizer.zero_grad()
                    preds = model(p_ids, r_ids, c_vecs)
                    targets = labels[:, 1:]
                    mask = targets != -1
                    if mask.sum() == 0:
                        continue
                    loss = compute_loss(preds[mask], targets[mask])
                    loss.backward()
                    optimizer.step()
                    epoch_loss += loss.item()

            auc, rmse, _ = _evaluate(model, test_loader)
            if auc is not None:
                print(f"Fold {fold+1} AUC: {auc:.4f}, RMSE: {rmse:.4f}")
                fold_aucs.append(auc)
                fold_rmses.append(rmse)

        if fold_aucs:
            print(f">>> Final Average AUC: {np.mean(fold_aucs):.4f} (std: {np.std(fold_aucs):.4f})")
            print(f">>> Final Average RMSE: {np.mean(fold_rmses):.4f} (std: {np.std(fold_rmses):.4f})")
        return

    # Holdout split (8:1:1 by default)
    if args.split_json:
        split = _load_split_json(args.split_json)
        train_users = split["train"]
        val_users = split["val"]
        test_users = split["test"]
    else:
        rng = np.random.default_rng(args.seed)
        user_ids = unique_users.copy()
        rng.shuffle(user_ids)
        n = len(user_ids)
        n_train = int(n * args.train_ratio)
        n_val = int(n * args.val_ratio)
        train_users = set(user_ids[:n_train])
        val_users = set(user_ids[n_train:n_train + n_val])
        test_users = set(user_ids[n_train + n_val:])

    if sample_df is not None:
        train_ds = PDKTSampleDataset(sample_df[sample_df["user"].astype(str).isin(train_users)], prob_feats, code_feats)
        val_ds = PDKTSampleDataset(sample_df[sample_df["user"].astype(str).isin(val_users)], prob_feats, code_feats)
        test_ds = PDKTSampleDataset(sample_df[sample_df["user"].astype(str).isin(test_users)], prob_feats, code_feats)
    else:
        user_to_idx = {str(uid): i for i, (uid, _) in enumerate(df.groupby('user_id', sort=False))}
        train_idx = [user_to_idx[u] for u in train_users if u in user_to_idx]
        val_idx = [user_to_idx[u] for u in val_users if u in user_to_idx]
        test_idx = [user_to_idx[u] for u in test_users if u in user_to_idx]

        train_ds = PDKTDataset(df, prob_feats, code_feats, train_idx)
        val_ds = PDKTDataset(df, prob_feats, code_feats, val_idx)
        test_ds = PDKTDataset(df, prob_feats, code_feats, test_idx)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)
    test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)

    model = PDKTModel(prob_feats, hidden_dim=HIDDEN_DIM, lambda_decay=LAMBDA_DECAY).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    best_val_auc = -1.0
    best_val_rmse = None
    best_state = None
    patience_cnt = 0
    use_focal = args.focal_gamma is not None and args.focal_alpha is not None
    if use_focal:
        def compute_loss(preds, targets):
            return focal_loss(preds, targets, alpha=args.focal_alpha, gamma=args.focal_gamma)
    else:
        criterion = nn.BCELoss()
        def compute_loss(preds, targets):
            return criterion(preds, targets)

    for epoch in range(args.epochs):
        model.train()
        epoch_loss = 0
        for p_ids, r_ids, c_vecs, labels, event_idx, user_ids in train_loader:
            p_ids, r_ids, c_vecs, labels = p_ids.to(DEVICE), r_ids.to(DEVICE), c_vecs.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            preds = model(p_ids, r_ids, c_vecs)
            if sample_df is not None:
                seq_lengths = (labels != -1).sum(dim=1)
                pred_pos = seq_lengths - 2
                valid = pred_pos >= 0
                if valid.sum() == 0:
                    continue
                batch_idx = torch.arange(labels.size(0), device=labels.device)[valid]
                pred_vals = preds[batch_idx, pred_pos[valid]]
                target_vals = labels[batch_idx, pred_pos[valid] + 1]
                loss = compute_loss(pred_vals, target_vals)
            else:
                targets = labels[:, 1:]
                mask = targets != -1
                if mask.sum() == 0:
                    continue
                loss = compute_loss(preds[mask], targets[mask])
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()

        eval_fn = _evaluate_last_only if sample_df is not None else _evaluate
        val_auc, val_rmse, _ = eval_fn(model, val_loader)
        if val_auc is not None:
            print(f"Epoch {epoch+1} | val AUC: {val_auc:.4f} | val RMSE: {val_rmse:.4f}")
            if val_auc > best_val_auc + args.min_delta:
                best_val_auc = val_auc
                best_val_rmse = val_rmse
                best_state = copy.deepcopy(model.state_dict())
                patience_cnt = 0
            else:
                patience_cnt += 1
                if args.patience > 0 and patience_cnt >= args.patience:
                    print(f"[EarlyStop] stopped at epoch {epoch+1}")
                    break

    if best_state is not None:
        model.load_state_dict(best_state)

    eval_fn = _evaluate_last_only if sample_df is not None else _evaluate
    test_auc, test_rmse, records = eval_fn(model, test_loader, collect_predictions=bool(args.pred_out))
    val_auc, val_rmse, val_records = eval_fn(model, val_loader, collect_predictions=bool(args.val_pred_out))
    if test_auc is not None:
        print(f">>> Test AUC: {test_auc:.4f}")
        print(f">>> Test RMSE: {test_rmse:.4f}")
    if args.pred_out:
        pd.DataFrame.from_records(records).to_csv(args.pred_out, index=False)
    if args.val_pred_out:
        pd.DataFrame.from_records(val_records).to_csv(args.val_pred_out, index=False)
    if args.ckpt_out:
        torch.save(
            {
                "model_state_dict": model.state_dict(),
                "args": vars(args),
                "best_val_auc": best_val_auc,
                "best_val_rmse": best_val_rmse,
                "val_auc": val_auc,
                "val_rmse": val_rmse,
                "test_auc": test_auc,
                "test_rmse": test_rmse,
            },
            args.ckpt_out,
        )
        print(f"Saved checkpoint to: {args.ckpt_out}")
    result_path = args.result_out if args.result_out else None
    if result_path:
        with open(result_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "best_val_auc": best_val_auc,
                    "best_val_rmse": best_val_rmse,
                    "val_auc": val_auc,
                    "val_rmse": val_rmse,
                    "test_auc": test_auc,
                    "test_rmse": test_rmse,
                    "seq_sample_csv": args.seq_sample_csv,
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Run original PDKT baseline.")
    parser.add_argument("--data-csv", default=USER_SEQ_PATH)
    parser.add_argument("--seq-sample-csv", type=str, default=None)
    parser.add_argument("--problem-feat", default=PROBLEM_FEAT_PATH)
    parser.add_argument("--code-emb", default=CODE_EMB_PATH)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    parser.add_argument("--hidden-dim", type=int, default=HIDDEN_DIM)
    parser.add_argument("--lambda-decay", type=float, default=LAMBDA_DECAY)
    parser.add_argument("--max-seq-len", type=int, default=MAX_SEQ_LEN)
    parser.add_argument("--lr", type=float, default=1e-5)
    parser.add_argument("--device", default=DEVICE)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--train-ratio", type=float, default=0.8)
    parser.add_argument("--val-ratio", type=float, default=0.1)
    parser.add_argument("--kfold", type=int, default=0)
    parser.add_argument("--focal-gamma", type=float, default=None)
    parser.add_argument("--focal-alpha", type=float, default=None)
    parser.add_argument("--split-json", type=str, default=None)
    parser.add_argument("--pred-out", type=str, default=None)
    parser.add_argument("--val-pred-out", type=str, default=None)
    parser.add_argument("--ckpt-out", type=str, default=None)
    parser.add_argument("--result-out", type=str, default=None)
    parser.add_argument("--patience", type=int, default=0)
    parser.add_argument("--min-delta", type=float, default=0.0)
    args = parser.parse_args()

    if args.train_ratio + args.val_ratio >= 1.0:
        raise ValueError("train_ratio + val_ratio must be < 1.0")

    run_experiment(args)
