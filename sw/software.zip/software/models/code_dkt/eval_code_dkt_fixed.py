#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
from torch.utils.data import DataLoader

CODE_DKT_DIR = Path("../kt_collection/experiments/code_dkt")
sys.path.append(str(CODE_DKT_DIR))

from train_eval_code_dkt_raw import (
    CodeDKT,
    SeqDataset,
    build_sequences,
    build_user_sequences,
    collate_batch,
    eval_model,
)


def load_split_users(path: str) -> dict[str, set[str]]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return {
        "train": {str(u) for u in payload["train_user_ids"]},
        "val": {str(u) for u in payload["val_user_ids"]},
        "test": {str(u) for u in payload["test_user_ids"]},
    }


def main():
    p = argparse.ArgumentParser(description="Eval-only fixed-split export for Code-DKT.")
    p.add_argument("--dataset", choices=["csedm", "bepkt"], required=True)
    p.add_argument("--data-csv", required=True)
    p.add_argument("--code-emb", required=True)
    p.add_argument("--split-json", required=True)
    p.add_argument("--model-ckpt", required=True)
    p.add_argument("--eval-split", choices=["train", "val", "test"], required=True)
    p.add_argument("--hidden-dim", type=int, required=True)
    p.add_argument("--q-emb-dim", type=int, default=128)
    p.add_argument("--code-proj-dim", type=int, default=256)
    p.add_argument("--out-json", required=True)
    p.add_argument("--pred-out", required=True)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--device", default="cuda:0")
    args = p.parse_args()

    split = load_split_users(args.split_json)
    df = __import__("pandas").read_csv(args.data_csv)
    by_user = build_user_sequences(df, args.dataset)
    code_emb = torch.load(args.code_emb, map_location="cpu")
    if code_emb.size(0) != len(df):
        raise ValueError(f"Row-aligned code_emb size mismatch: {code_emb.size(0)} vs {len(df)}")

    all_probs = sorted({p for u in by_user for (p, _, _) in by_user[u]})
    pid2idx = {int(p): i for i, p in enumerate(all_probs)}
    seqs = build_sequences({u: by_user[u] for u in split[args.eval_split]}, pid2idx, code_emb)
    loader = DataLoader(SeqDataset(seqs), batch_size=args.batch_size, shuffle=False, collate_fn=collate_batch)

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model = CodeDKT(
        num_q=len(pid2idx),
        q_emb_dim=args.q_emb_dim,
        code_dim=code_emb.shape[1],
        code_proj_dim=args.code_proj_dim,
        hidden_dim=args.hidden_dim,
    ).to(device)
    model.load_state_dict(torch.load(args.model_ckpt, map_location=device))

    stats, records = eval_model(model, loader, device, collect_predictions=True)
    Path(args.out_json).write_text(
        json.dumps(
            {
                "dataset": args.dataset,
                "eval_split": args.eval_split,
                "split_json": args.split_json,
                "model_ckpt": args.model_ckpt,
                "auc": stats["auc"],
                "rmse": stats["rmse"],
                "loss": stats["loss"],
                "n_eval": stats["n_eval"],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    __import__("pandas").DataFrame.from_records(records).to_csv(args.pred_out, index=False)
    print(json.dumps(stats, ensure_ascii=False))


if __name__ == "__main__":
    main()
