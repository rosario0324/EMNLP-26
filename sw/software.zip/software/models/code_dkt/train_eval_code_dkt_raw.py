import argparse
import json
import math
import os
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

for _thread_key in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "BLIS_NUM_THREADS",
):
    os.environ.setdefault(_thread_key, "1")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn import metrics
from torch.utils.data import DataLoader, Dataset


def configure_cpu_threads() -> None:
    threads = int(os.environ.get("TORCH_NUM_THREADS", os.environ.get("OMP_NUM_THREADS", "1")))
    interop = int(os.environ.get("TORCH_NUM_INTEROP_THREADS", "1"))
    torch.set_num_threads(threads)
    try:
        torch.set_num_interop_threads(interop)
    except RuntimeError:
        pass


configure_cpu_threads()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def build_user_sequences(df: pd.DataFrame, dataset: str) -> Dict[str, List[Tuple[int, int, int]]]:
    if dataset == "csedm":
        user_col = "user_id"
        prob_col = "problem_id"
        result_col = "result"
        order_cols = ["user_id", "Order"]
    else:
        user_col = "user_id"
        prob_col = "problem_id"
        result_col = "result"
        order_cols = ["user_id", "create_time"]

    use_cols = [user_col, prob_col, result_col] + [c for c in order_cols if c != user_col]
    work = df[use_cols].copy()
    # Keep row-aligned embedding index from original CSV order.
    work["__row_idx"] = np.arange(len(work), dtype=np.int64)
    work = work.sort_values(order_cols).reset_index(drop=True)
    work[user_col] = work[user_col].astype(str)
    work[prob_col] = work[prob_col].astype(int)
    work[result_col] = work[result_col].astype(int)

    by_user: Dict[str, List[Tuple[int, int, int]]] = {}
    for _, row in work.iterrows():
        u = row[user_col]
        p = int(row[prob_col])
        r = int(row[result_col])
        ridx = int(row["__row_idx"])
        by_user.setdefault(u, []).append((p, r, ridx))
    return by_user


class SeqDataset(Dataset):
    def __init__(self, seqs: List[Tuple[str, np.ndarray, np.ndarray, np.ndarray, np.ndarray]]):
        self.seqs = seqs

    def __len__(self):
        return len(self.seqs)

    def __getitem__(self, idx):
        return self.seqs[idx]


def collate_batch(batch):
    lengths = [len(x[1]) for x in batch]
    max_len = max(lengths)
    bs = len(batch)
    code_dim = batch[0][5].shape[1]

    q_in = torch.zeros((bs, max_len), dtype=torch.long)
    r_in = torch.zeros((bs, max_len), dtype=torch.long)
    q_next = torch.zeros((bs, max_len), dtype=torch.long)
    r_next = torch.zeros((bs, max_len), dtype=torch.float32)
    c_in = torch.zeros((bs, max_len, code_dim), dtype=torch.float32)
    event_idx = torch.full((bs, max_len), -1, dtype=torch.long)
    mask = torch.zeros((bs, max_len), dtype=torch.bool)
    user_ids = []

    for i, (user_id, q, r, qn, ev, c) in enumerate(batch):
        L = len(q)
        user_ids.append(user_id)
        q_in[i, :L] = torch.from_numpy(q)
        r_in[i, :L] = torch.from_numpy(r[:-1])
        q_next[i, :L] = torch.from_numpy(qn)
        r_next[i, :L] = torch.from_numpy(r[1:].astype(np.float32))
        event_idx[i, :L] = torch.from_numpy(ev)
        c_in[i, :L] = torch.from_numpy(c)
        mask[i, :L] = True

    return user_ids, q_in, r_in, q_next, r_next, c_in, event_idx, mask


def collate_sample_batch(batch):
    user_ids, q_in, r_in, q_next, r_next, c_in, event_idx, mask = collate_batch(batch)
    target_mask = torch.zeros_like(mask)
    for i in range(mask.size(0)):
        valid_idx = torch.where(mask[i])[0]
        if len(valid_idx):
            target_mask[i, valid_idx[-1]] = True
    return user_ids, q_in, r_in, q_next, r_next, c_in, event_idx, target_mask


class CodeDKT(nn.Module):
    def __init__(self, num_q: int, q_emb_dim: int, code_dim: int, code_proj_dim: int, hidden_dim: int):
        super().__init__()
        self.num_q = num_q
        self.q_emb = nn.Embedding(num_q, q_emb_dim)
        self.r_emb = nn.Embedding(2, q_emb_dim)
        self.code_proj = nn.Linear(code_dim, code_proj_dim)
        self.in_proj = nn.Linear(q_emb_dim + q_emb_dim + code_proj_dim, hidden_dim)
        self.lstm = nn.LSTM(hidden_dim, hidden_dim, num_layers=1, batch_first=True)
        self.out = nn.Linear(hidden_dim, num_q)

    def forward(self, q_in, r_in, c_in):
        qv = self.q_emb(q_in)
        rv = self.r_emb(r_in)
        cv = torch.tanh(self.code_proj(c_in))
        x = torch.cat([qv, rv, cv], dim=-1)
        x = torch.tanh(self.in_proj(x))
        h, _ = self.lstm(x)
        y = torch.sigmoid(self.out(h))
        return y


def eval_model(model, loader, device, collect_predictions: bool = False):
    model.eval()
    preds = []
    trues = []
    losses = []
    records = []
    with torch.no_grad():
        for user_ids, q_in, r_in, q_next, r_next, c_in, event_idx, mask in loader:
            q_in = q_in.to(device)
            r_in = r_in.to(device)
            q_next = q_next.to(device)
            r_next = r_next.to(device)
            c_in = c_in.to(device)
            mask = mask.to(device)

            y = model(q_in, r_in, c_in)
            p_full = y.gather(2, q_next.unsqueeze(-1)).squeeze(-1)
            p = p_full[mask]
            t = r_next[mask]
            if p.numel() == 0:
                continue
            loss = F.binary_cross_entropy(p, t)
            losses.append(float(loss.item()))
            preds.append(p.detach().cpu())
            trues.append(t.detach().cpu())
            if collect_predictions:
                p_cpu = p_full.detach().cpu()
                t_cpu = r_next.detach().cpu()
                ev_cpu = event_idx.detach().cpu()
                mask_cpu = mask.detach().cpu()
                for i, user_id in enumerate(user_ids):
                    valid = mask_cpu[i]
                    pred_vals = p_cpu[i][valid].tolist()
                    target_vals = t_cpu[i][valid].tolist()
                    event_vals = ev_cpu[i][valid].tolist()
                    for event_val, target_val, pred_val in zip(event_vals, target_vals, pred_vals):
                        records.append(
                            {
                                "user_id": str(user_id),
                                "event_idx": int(event_val),
                                "target": float(target_val),
                                "pred": float(pred_val),
                            }
                        )

    if not preds:
        return {"auc": float("nan"), "rmse": float("nan"), "loss": float("nan"), "n_eval": 0}, records

    y_score = torch.cat(preds).numpy()
    y_true = torch.cat(trues).numpy()
    auc = metrics.roc_auc_score(y_true, y_score) if len(np.unique(y_true)) > 1 else float("nan")
    rmse = math.sqrt(float(np.mean((y_score - y_true) ** 2)))
    loss_mean = float(np.mean(losses)) if losses else float("nan")
    return {"auc": auc, "rmse": rmse, "loss": loss_mean, "n_eval": int(len(y_true))}, records


@dataclass
class ExpConfig:
    dataset: str
    split_name: str
    data_csv: str
    code_emb: str
    out_dir: str
    seed: int = 42
    val_ratio: float = 0.1
    test_ratio: float = 0.1
    q_emb_dim: int = 128
    code_proj_dim: int = 256
    hidden_dim: int = 256
    batch_size: int = 64
    num_epochs: int = 20
    lr: float = 1e-3
    patience: int = 5
    min_delta: float = 0.0005
    device: str = "cuda:0"
    stratify_users: bool = False
    stratify_bins: int = 5
    auto_pos_weight: bool = False
    split_json: str | None = None
    max_seq_len: int = 0
    seq_sample_csv: str | None = None


def build_sequences(by_user, pid2idx, code_emb_tensor, max_seq_len: int = 0):
    seqs = []
    for user_id, items in by_user.items():
        if max_seq_len and len(items) > max_seq_len:
            items = items[-max_seq_len:]
        if len(items) < 2:
            continue
        p = np.array([pid2idx[x[0]] for x in items], dtype=np.int64)
        r = np.array([x[1] for x in items], dtype=np.int64)
        event_idx = np.arange(1, len(items), dtype=np.int64)
        ridx = np.array([x[2] for x in items], dtype=np.int64)
        c = code_emb_tensor[ridx]
        q_in = p[:-1]
        q_next = p[1:]
        c_in = c[:-1].numpy().astype(np.float32)
        seqs.append((str(user_id), q_in, r, q_next, event_idx, c_in))
    return seqs


def _loads_int_list(text: str) -> list[int]:
    return [int(x) for x in json.loads(text)]


def build_sample_sequences(sample_df: pd.DataFrame, pid2idx, code_emb_tensor, max_seq_len: int = 0):
    seqs = []
    for _, row in sample_df.iterrows():
        probs = _loads_int_list(row["problem_sequence"])
        results = _loads_int_list(row["result_sequence"])
        row_idxs = _loads_int_list(row["row_index_sequence"])
        if max_seq_len and len(probs) > max_seq_len:
            probs = probs[-max_seq_len:]
            results = results[-max_seq_len:]
            row_idxs = row_idxs[-max_seq_len:]
        if len(probs) < 2:
            continue
        p = np.array([pid2idx[int(x)] for x in probs], dtype=np.int64)
        r = np.array(results, dtype=np.int64)
        ridx = np.array(row_idxs, dtype=np.int64)
        c = code_emb_tensor[ridx]
        q_in = p[:-1]
        q_next = p[1:]
        c_in = c[:-1].numpy().astype(np.float32)
        event_idx = np.array(row_idxs[1:], dtype=np.int64)
        seqs.append((str(row["sample_id"]), q_in, r, q_next, event_idx, c_in))
    return seqs


def split_users(
    by_user: Dict[str, List[Tuple[int, int, int]]],
    val_ratio: float,
    test_ratio: float,
    seed: int,
    stratify_users: bool,
    stratify_bins: int,
):
    users = list(by_user.keys())
    n = len(users)
    n_test = int(n * test_ratio)
    n_val = int(n * val_ratio)

    if (not stratify_users) or n == 0:
        rng = np.random.default_rng(seed)
        rng.shuffle(users)
        test_users = set(users[:n_test])
        val_users = set(users[n_test:n_test + n_val])
        train_users = set(users[n_test + n_val:])
        return train_users, val_users, test_users

    stats = []
    for u in users:
        rows = by_user[u]
        correct = float(sum(x[1] for x in rows))
        total = float(len(rows))
        stats.append((u, correct / total if total > 0 else 0.0))
    sdf = pd.DataFrame(stats, columns=["user", "rate"])
    bins = min(stratify_bins, max(2, sdf["user"].nunique() // 2))
    try:
        sdf["bin"] = pd.qcut(sdf["rate"], q=bins, duplicates="drop")
    except Exception:
        sdf["bin"] = 0

    rng = np.random.default_rng(seed)
    train_users = set()
    val_users = set()
    test_users = set()
    for _, g in sdf.groupby("bin", observed=False):
        arr = g["user"].tolist()
        rng.shuffle(arr)
        nn = len(arr)
        nt = int(nn * test_ratio)
        nv = int(nn * val_ratio)
        test_users.update(arr[:nt])
        val_users.update(arr[nt:nt + nv])
        train_users.update(arr[nt + nv:])

    # adjust for exact target sizes if necessary
    all_users = set(users)
    assigned = train_users | val_users | test_users
    remain = list(all_users - assigned)
    rng.shuffle(remain)
    train_users.update(remain)
    return train_users, val_users, test_users


def split_users_from_json(by_user: Dict[str, List[Tuple[int, int, int]]], split_json_path: str):
    payload = json.loads(Path(split_json_path).read_text(encoding="utf-8"))
    all_users = set(by_user.keys())
    train_users = {str(u) for u in payload["train_user_ids"]} & all_users
    val_users = {str(u) for u in payload["val_user_ids"]} & all_users
    test_users = {str(u) for u in payload["test_user_ids"]} & all_users
    return train_users, val_users, test_users


def split_users_with_fixed_test(
    by_user: Dict[str, List[Tuple[int, int, int]]],
    fixed_test_users: set[str],
    val_ratio: float,
    seed: int,
    stratify_users: bool,
    stratify_bins: int,
):
    all_users = set(by_user.keys())
    test_users = set(str(u) for u in fixed_test_users) & all_users
    remain_users = list(all_users - test_users)

    if not remain_users:
        return set(), set(), test_users

    n = len(remain_users)
    n_val = int(n * val_ratio)

    if (not stratify_users) or n == 0:
        rng = np.random.default_rng(seed)
        rng.shuffle(remain_users)
        val_users = set(remain_users[:n_val])
        train_users = set(remain_users[n_val:])
        return train_users, val_users, test_users

    stats = []
    for u in remain_users:
        rows = by_user[u]
        correct = float(sum(x[1] for x in rows))
        total = float(len(rows))
        stats.append((u, correct / total if total > 0 else 0.0))
    sdf = pd.DataFrame(stats, columns=["user", "rate"])
    bins = min(stratify_bins, max(2, sdf["user"].nunique() // 2))
    try:
        sdf["bin"] = pd.qcut(sdf["rate"], q=bins, duplicates="drop")
    except Exception:
        sdf["bin"] = 0

    rng = np.random.default_rng(seed)
    train_users = set()
    val_users = set()
    for _, g in sdf.groupby("bin", observed=False):
        arr = g["user"].tolist()
        rng.shuffle(arr)
        nn = len(arr)
        nv = int(nn * val_ratio)
        val_users.update(arr[:nv])
        train_users.update(arr[nv:])

    assigned = train_users | val_users
    for u in remain_users:
        if u not in assigned:
            train_users.add(u)
    return train_users, val_users, test_users


def shifted_pos_rate(seqs: List[Tuple[str, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]]) -> float:
    num = 0.0
    den = 0.0
    for _, _, r, _, _, _ in seqs:
        if len(r) <= 1:
            continue
        num += float(np.sum(r[1:]))
        den += float(len(r) - 1)
    return (num / den) if den > 0 else 0.0


def run_experiment(cfg: ExpConfig):
    set_seed(cfg.seed)
    os.makedirs(cfg.out_dir, exist_ok=True)

    df = pd.read_csv(cfg.data_csv)
    by_user = build_user_sequences(df, cfg.dataset)
    fixed_test_users = None
    if hasattr(cfg, "fixed_test_users_csv") and cfg.fixed_test_users_csv:
        u_df = pd.read_csv(cfg.fixed_test_users_csv)
        col = getattr(cfg, "fixed_test_user_col", None)
        if not col:
            col = "user" if "user" in u_df.columns else ("user_id" if "user_id" in u_df.columns else None)
        if col is None or col not in u_df.columns:
            raise ValueError(
                f"Cannot infer fixed test user column from {cfg.fixed_test_users_csv}. "
                "Use --fixed-test-user-col."
            )
        fixed_test_users = set(u_df[col].astype(str).tolist())

    if cfg.split_json:
        train_users, val_users, test_users = split_users_from_json(by_user, cfg.split_json)
    elif fixed_test_users is None:
        train_users, val_users, test_users = split_users(
            by_user,
            cfg.val_ratio,
            cfg.test_ratio,
            cfg.seed,
            cfg.stratify_users,
            cfg.stratify_bins,
        )
    else:
        train_users, val_users, test_users = split_users_with_fixed_test(
            by_user,
            fixed_test_users,
            cfg.val_ratio,
            cfg.seed,
            cfg.stratify_users,
            cfg.stratify_bins,
        )
    users = list(by_user.keys())

    if cfg.seq_sample_csv:
        sample_df = pd.read_csv(cfg.seq_sample_csv)
        sample_users = set(sample_df["user"].astype(str))
        train_users = train_users & sample_users
        val_users = val_users & sample_users
        test_users = test_users & sample_users
        all_probs = sorted(
            {
                int(p)
                for seq_text in sample_df["problem_sequence"].astype(str)
                for p in json.loads(seq_text)
            }
        )
    else:
        sample_df = None
        all_probs = sorted({p for u in users for (p, _, _) in by_user[u]})
    pid2idx = {int(p): i for i, p in enumerate(all_probs)}

    code_emb = torch.load(cfg.code_emb, map_location="cpu")
    if code_emb.size(0) != len(df):
        raise ValueError(f"Row-aligned code_emb size mismatch: {code_emb.size(0)} vs df {len(df)}")

    if sample_df is not None:
        train_seqs = build_sample_sequences(sample_df[sample_df["user"].astype(str).isin(train_users)], pid2idx, code_emb, cfg.max_seq_len)
        val_seqs = build_sample_sequences(sample_df[sample_df["user"].astype(str).isin(val_users)], pid2idx, code_emb, cfg.max_seq_len)
        test_seqs = build_sample_sequences(sample_df[sample_df["user"].astype(str).isin(test_users)], pid2idx, code_emb, cfg.max_seq_len)
        collate_fn = collate_sample_batch
    else:
        train_seqs = build_sequences({u: by_user[u] for u in train_users}, pid2idx, code_emb, cfg.max_seq_len)
        val_seqs = build_sequences({u: by_user[u] for u in val_users}, pid2idx, code_emb, cfg.max_seq_len)
        test_seqs = build_sequences({u: by_user[u] for u in test_users}, pid2idx, code_emb, cfg.max_seq_len)
        collate_fn = collate_batch

    train_loader = DataLoader(SeqDataset(train_seqs), batch_size=cfg.batch_size, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(SeqDataset(val_seqs), batch_size=cfg.batch_size, shuffle=False, collate_fn=collate_fn)
    test_loader = DataLoader(SeqDataset(test_seqs), batch_size=cfg.batch_size, shuffle=False, collate_fn=collate_fn)

    if str(cfg.device).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(f"Requested CUDA device {cfg.device}, but CUDA is not available")
    device = torch.device(cfg.device if str(cfg.device).startswith("cuda") else "cpu")
    print(f"[device] {device}", flush=True)
    model = CodeDKT(
        num_q=len(pid2idx),
        q_emb_dim=cfg.q_emb_dim,
        code_dim=code_emb.shape[1],
        code_proj_dim=cfg.code_proj_dim,
        hidden_dim=cfg.hidden_dim,
    ).to(device)

    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    best_auc = -1.0
    best_val_rmse = float("nan")
    best_path = os.path.join(cfg.out_dir, "model.ckpt")
    patience_cnt = 0

    print(f"[Data] users train/val/test = {len(train_users)}/{len(val_users)}/{len(test_users)}")
    print(f"[Data] seqs  train/val/test = {len(train_seqs)}/{len(val_seqs)}/{len(test_seqs)}")
    print(f"[Data] num_q={len(pid2idx)}")
    print(
        "[Data] shifted_pos_rate train/val/test = "
        f"{shifted_pos_rate(train_seqs):.4f}/{shifted_pos_rate(val_seqs):.4f}/{shifted_pos_rate(test_seqs):.4f}"
    )

    pos_weight = None
    if cfg.auto_pos_weight:
        p = shifted_pos_rate(train_seqs)
        if p > 0 and p < 1:
            pos_weight = torch.tensor((1.0 - p) / p, dtype=torch.float32, device=device)
            print(f"[Train] auto pos_weight = {float(pos_weight.item()):.4f}")

    for epoch in range(1, cfg.num_epochs + 1):
        model.train()
        train_losses = []
        for _user_ids, q_in, r_in, q_next, r_next, c_in, _event_idx, mask in train_loader:
            q_in = q_in.to(device)
            r_in = r_in.to(device)
            q_next = q_next.to(device)
            r_next = r_next.to(device)
            c_in = c_in.to(device)
            mask = mask.to(device)

            y = model(q_in, r_in, c_in)
            p = y.gather(2, q_next.unsqueeze(-1)).squeeze(-1)
            p = p[mask]
            t = r_next[mask]

            if pos_weight is None:
                loss = F.binary_cross_entropy(p, t)
            else:
                w = torch.where(t > 0.5, pos_weight, torch.ones_like(t))
                loss = F.binary_cross_entropy(p, t, weight=w)
            opt.zero_grad()
            loss.backward()
            opt.step()
            train_losses.append(float(loss.item()))

        val_stats, _ = eval_model(model, val_loader, device)
        train_loss = float(np.mean(train_losses)) if train_losses else float("nan")
        print(
            f"Epoch {epoch} | val AUC: {val_stats['auc']:.4f} | val RMSE: {val_stats['rmse']:.4f} | "
            f"train loss: {train_loss:.4f} | val loss: {val_stats['loss']:.4f}"
        )

        auc = val_stats["auc"]
        if np.isnan(auc):
            continue
        if auc > best_auc + cfg.min_delta:
            best_auc = auc
            best_val_rmse = val_stats["rmse"]
            patience_cnt = 0
            torch.save(model.state_dict(), best_path)
        else:
            patience_cnt += 1
            if patience_cnt >= cfg.patience:
                print(f"[EarlyStop] stopped at epoch {epoch}")
                break

    model.load_state_dict(torch.load(best_path, map_location=device))
    val_stats_final, val_records = eval_model(
        model, val_loader, device, collect_predictions=bool(getattr(cfg, "val_pred_out", None))
    )
    test_stats, records = eval_model(model, test_loader, device, collect_predictions=bool(getattr(cfg, "pred_out", None)))
    print(f">>> Test AUC: {test_stats['auc']:.4f}")
    print(f">>> Test RMSE: {test_stats['rmse']:.4f}")

    with open(os.path.join(cfg.out_dir, "problem_id_map.json"), "w", encoding="utf-8") as f:
        json.dump({"pid2idx": pid2idx, "num_q": len(pid2idx)}, f, ensure_ascii=False)
    with open(os.path.join(cfg.out_dir, "result.json"), "w", encoding="utf-8") as f:
        json.dump(
            {
                "dataset": cfg.dataset,
                "split": cfg.split_name,
                "seed": cfg.seed,
                "max_seq_len": cfg.max_seq_len,
                "seq_sample_csv": cfg.seq_sample_csv,
                "split_json": cfg.split_json,
                "best_val_auc": best_auc,
                "best_val_rmse": best_val_rmse,
                "val_auc": val_stats_final["auc"],
                "val_rmse": val_stats_final["rmse"],
                "val_n_eval": val_stats_final["n_eval"],
                "test_auc": test_stats["auc"],
                "test_rmse": test_stats["rmse"],
                "n_eval": test_stats["n_eval"],
            },
            f,
            ensure_ascii=False,
            indent=2,
        )
    if getattr(cfg, "pred_out", None):
        pred_out = os.path.abspath(cfg.pred_out)
        os.makedirs(os.path.dirname(pred_out), exist_ok=True)
        pd.DataFrame.from_records(records).to_csv(pred_out, index=False)
    if getattr(cfg, "val_pred_out", None):
        val_pred_out = os.path.abspath(cfg.val_pred_out)
        os.makedirs(os.path.dirname(val_pred_out), exist_ok=True)
        pd.DataFrame.from_records(val_records).to_csv(val_pred_out, index=False)


def parse_args():
    p = argparse.ArgumentParser(description="Train/Eval Code-DKT on raw CSEDM/BePKT.")
    p.add_argument("--dataset", choices=["csedm", "bepkt"], required=True)
    p.add_argument("--split-name", choices=["all", "first"], required=True)
    p.add_argument("--data-csv", type=str, required=True)
    p.add_argument("--seq-sample-csv", type=str, default=None)
    p.add_argument("--code-emb", type=str, required=True)
    p.add_argument("--out-dir", type=str, required=True)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--val-ratio", type=float, default=0.1)
    p.add_argument("--test-ratio", type=float, default=0.1)
    p.add_argument("--q-emb-dim", type=int, default=128)
    p.add_argument("--code-proj-dim", type=int, default=256)
    p.add_argument("--hidden-dim", type=int, default=256)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--num-epochs", type=int, default=20)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--patience", type=int, default=5)
    p.add_argument("--min-delta", type=float, default=0.0005)
    p.add_argument("--device", type=str, default="cuda:0")
    p.add_argument("--stratify-users", action="store_true")
    p.add_argument("--stratify-bins", type=int, default=5)
    p.add_argument("--auto-pos-weight", action="store_true")
    p.add_argument("--fixed-test-users-csv", type=str, default=None)
    p.add_argument("--fixed-test-user-col", type=str, default=None)
    p.add_argument("--split-json", type=str, default=None)
    p.add_argument("--pred-out", type=str, default=None)
    p.add_argument("--val-pred-out", type=str, default=None)
    p.add_argument("--max-seq-len", type=int, default=0)
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = ExpConfig(
        dataset=args.dataset,
        split_name=args.split_name,
        data_csv=args.data_csv,
        code_emb=args.code_emb,
        out_dir=args.out_dir,
        seed=args.seed,
        val_ratio=args.val_ratio,
        test_ratio=args.test_ratio,
        q_emb_dim=args.q_emb_dim,
        code_proj_dim=args.code_proj_dim,
        hidden_dim=args.hidden_dim,
        batch_size=args.batch_size,
        num_epochs=args.num_epochs,
        lr=args.lr,
        patience=args.patience,
        min_delta=args.min_delta,
        device=args.device,
        stratify_users=args.stratify_users,
        stratify_bins=args.stratify_bins,
        auto_pos_weight=args.auto_pos_weight,
        split_json=args.split_json,
        max_seq_len=args.max_seq_len,
        seq_sample_csv=args.seq_sample_csv,
    )
    cfg.fixed_test_users_csv = args.fixed_test_users_csv
    cfg.fixed_test_user_col = args.fixed_test_user_col
    cfg.pred_out = args.pred_out
    cfg.val_pred_out = args.val_pred_out
    run_experiment(cfg)
