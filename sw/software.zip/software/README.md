# Software Package

This software snapshot contains preprocessing code for the reported `all` and
`first` tasks, model sources used in the experimental comparison, evaluation
utilities, and the curated implementation-skill resources used by the
proposed model.

## Included Code

| Folder | Scope |
| --- | --- |
| `preprocessing/` | CSEDM preprocessing, reported-task construction, and cross-validation fold assembly |
| `models/conventional_kt/` | DKT, DKT+, DKVMN, SAKT, and AKT model sources |
| `models/code_dkt/` | Code-DKT sources |
| `models/pdkt/` | PDKT sources |
| `models/iice_pkt/` | IICE-PKT code representation and model sources |
| `models/ours_full/` | Proposed-model trainer, problem-representation code, and implementation-skill construction sources |
| `runners/` | Experiment launch entrypoints |
| `evaluation/` | Result summarization and paired significance-test utilities |
| `resources/` | CSEDM problem-KC mapping and curated implementation-skill tables |

## Ours (Full)

`Ours (full)` combines:

- a KC-guided problem representation refined by contrastive learning;
- an IICE-based code representation;
- a curated implementation-skill representation; and
- a target-aware skill state derived from the student's preceding interactions.

The implementation-skill resource is retained using the following criteria:

```text
minimum distinct connected problems per skill = 2
minimum observed extractions per skill        = 7
minimum observed extractions per edge         = 1
```

The resulting public resource contains:

| Item | Value |
| --- | ---: |
| Retained implementation skills | 36 |
| Retained problem-skill edges | 294 |
| Covered problems | 50 / 50 |
| Signed evidence dimensions before learned projection | 72 |

The defining tables are in `resources/ours_full/implementation_skill/`.
Tensor embeddings and trained checkpoints are generated artifacts and are not
included in this source package.

## Task Protocol

The reported tasks use the following naming:

- `all`: retain the AST-valid history after removing the final submission for
  each `(student, problem)`.
- `first`: retain the first submission for each `(student, problem)` from the
  reported `all` history.

`runners/run_ours_full_cv.sh` is the proposed-model entrypoint. It accepts
relative or user-provided locations for processed fold data and generated base
assets; no local workspace path is assumed.

## Exclusions

The delivery intentionally excludes trained model checkpoints, cached
embeddings, generated folds, experiment logs, metric outputs, credentials, and
environment files.
